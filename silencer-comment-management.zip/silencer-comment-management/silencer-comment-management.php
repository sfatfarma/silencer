<?php
/** 
Plugin Name: Silencer Comment Management System
Plugin URI: http://codecanyon.net/user/coderevolution/portfolio
Description: This plugin will give you the ability to manage the way how comments are handled in WordPress.
Author: CodeRevolution
Version: 1.2
Author URI: https://codecanyon.net/user/coderevolution
*/
defined( 'ABSPATH' ) or die();
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/silencer/master/info.json", __FILE__, "silencer-comment-management");
add_action('admin_menu', 'silencer_register_my_custom_menu_page');
add_action('network_admin_menu', 'silencer_register_my_custom_menu_page');
function silencer_register_my_custom_menu_page()
{
    add_menu_page('Silencer Comment Management', 'Silencer Comment Management', 'manage_options', 'silencer_admin_settings', 'silencer_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('silencer_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'silencer_admin_settings');
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    if (isset($silencer_Main_Settings['silencer_enabled']) && $silencer_Main_Settings['silencer_enabled'] == 'on')
    {
        add_submenu_page('silencer_admin_settings', 'Bulk Delete Comments', 'Bulk Delete Comments', 'manage_options', 'silencer_delete_comments', 'silencer_delete_comments');
    }
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'silencer_add_settings_link');
function silencer_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=silencer_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

function silencer_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
register_activation_hook(__FILE__, 'silencer_activation_callback');
function silencer_activation_callback($default = FALSE)
{
    if (!get_option('silencer_Main_Settings') || $default) {    
        $silencer_Main_Settings = array(
            'silencer_enabled' => 'on',
            'enabled_types' => array(),
            'enabled_existing_types' => array(),
            'enabled_ping_types' => array(),
            'enabled_track_types' => array(),
            'disable_xmlrpc' => '',
            'remove_url' => '',
            'disable_comments_sidebar' => '',
            'disable_admin_bar' => '',
            'admin_remove_metabox' => '',
            'admin_redirect' => '',
            'admin_disable_comments' => '',
            'disable_comment_feed' => '',
            'google_plus' => '',
            'rsd_link' => '',
            'force_comments_overwrite' => '',
            'hide_feed_link' => '',
            'enable_metabox' => 'on',
            'enable_box_comments' => 'on',
            'enable_box_hiding' => 'on',
            'enable_box_pingback' => 'on',
            'enable_box_trackback' => 'on',
            'enable_box_button' => 'on',
            'trackback_users' => 'no',
            'pingback_users' => 'no',
            'hide_users' => 'no',
            'comment_users' => 'no',
            'trackback_cats' => array(),
            'pingback_cats' => array(),
            'hide_cats' => array(),
            'comment_cats' => array(),
            'trackback_tags' => '',
            'pingback_tags' => '',
            'hide_tags' => '',
            'comment_tags' => '',
            'trackback_authors' => array(),
            'pingback_authors' => array(),
            'hide_authors' => array(),
            'comment_authors' => array(),
            'trackback_login' => array(),
            'pingback_login' => array(),
            'hide_login' => array(),
            'comment_login' => array(),
            'trackback_country' => 'NONE',
            'pingback_country' => 'NONE',
            'hide_country' => 'NONE',
            'comment_country' => 'NONE',
            'comment_language' => 'NONE',
            'hide_language' => 'NONE',
            'pingback_language' => 'NONE',
            'trackback_language' => 'NONE',
            'trackback_refs' => '',
            'pingback_refs' => '',
            'hide_refs' => '',
            'comment_refs' => '',
            'trackback_ips' => '',
            'pingback_ips' => '',
            'hide_ips' => '',
            'comment_ips' => '',
            'trackback_devices' => 'NONE',
            'pingback_devices' => 'NONE',
            'hide_devices' => 'NONE',
            'comment_devices' => 'NONE',
            'comment_oses' => 'NONE',
            'hide_oses' => 'NONE',
            'pingback_oses' => 'NONE',
            'trackback_oses' => 'NONE',
            'comment_browsers' => 'NONE',
            'hide_browsers' => 'NONE',
            'pingback_browsers' => 'NONE',
            'trackback_browsers' => 'NONE',
            'trackback_url' => '',
            'pingback_url' => '',
            'hide_url' => '',
            'comment_url' => '',
            'comment_url_wildcard' => '',
            'hide_url_wildcard' => '',
            'pingback_url_wildcard' => '',
            'trackback_url_wildcard' => '',
            'comments_maximum_length_value' => '',
            'comments_maximum_length' => '',
            'comments_minimum_length_value' => '',
            'disable_html' => ''
        );
        if($default)
        {
            update_option('silencer_Main_Settings', $silencer_Main_Settings);
        }
        else
        {
            add_option('silencer_Main_Settings', $silencer_Main_Settings);
        }
    }
}

function silencer_disable_comment_url($fields) { 
    unset($fields['url']);
    return $fields;
}
function silencer_filter_pingback_url($output, $show)
{
    $output = '';
    return $output;
}
function silencer_filter_trackback_rewrites($rewrite_rules)
{
    foreach ($rewrite_rules as $rule => $rewrite) {
        if (preg_match('/trackback\/\?\$$/i', $rule)) {
            unset($rewrite_rules[$rule]);
        }
    }
    return $rewrite_rules;
}
function silencer_disable_default_comment_status($default)
{
    return "closed";
}
function silencer_disable_default_ping_status($default)
{
    return "closed";
}
function silencer_disable_comments_post_types_support() {
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    if (isset($silencer_Main_Settings['silencer_enabled']) && $silencer_Main_Settings['silencer_enabled'] == 'on')
    {
        if(isset($silencer_Main_Settings['comments_maximum_length']) && $silencer_Main_Settings['comments_maximum_length'] == 'on')
        {
            add_filter( 'preprocess_comment', 'silencer_preprocess_comment' );
        }
        if(isset($silencer_Main_Settings['disable_html']) && $silencer_Main_Settings['disable_html'] == 'on')
        {
            add_filter( 'preprocess_comment', 'silencer_comment_post', '', 1);
            add_filter( 'comment_text', 'silencer_comment_display', '', 1);
            add_filter( 'comment_text_rss', 'silencer_comment_display', '', 1);
            add_filter( 'comment_excerpt', 'silencer_comment_display', '', 1);
            remove_filter( 'comment_text', 'make_clickable', 9 );
        }
            
        add_filter('comments_array', 'silencer_existing_comments', 20, 2);
        add_filter('comments_open', 'silencer_comment_status', 20, 2);
        add_filter('pings_open', 'silencer_pingback_status', 20, 2);
        if (isset($silencer_Main_Settings['remove_url']) && $silencer_Main_Settings['remove_url'] == 'on')
        {
            add_filter('comment_form_default_fields','silencer_disable_comment_url');
        }
        if (isset($silencer_Main_Settings['admin_disable_comments']) && $silencer_Main_Settings['admin_disable_comments'] == 'on')
        {
            add_action('admin_menu', 'silencer_disable_comments_admin_menu');
        }
        if (isset($silencer_Main_Settings['admin_redirect']) && $silencer_Main_Settings['admin_redirect'] == 'on')
        {
            add_action('admin_init', 'silencer_disable_comments_admin_menu_redirect');
        }
        if (isset($silencer_Main_Settings['admin_remove_metabox']) && $silencer_Main_Settings['admin_remove_metabox'] == 'on')
        {
            add_action( 'wp_dashboard_setup', function()
            {
                // Remove the Activity widget
                remove_meta_box( 'dashboard_activity', 'dashboard', 'normal' );
                remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );

                // Add the modified Activity widget
                if ( is_blog_admin() ) 
                   wp_add_dashboard_widget( 
                       'wpse_dashboard_activity', 
                       __( 'Activity' ), 
                       'silencer_dashboard_site_activity' 
                   );

            } );
            
                add_action( 'wp_dashboard_setup', function()
                {
                    if (isset($silencer_Main_Settings['enabled_types'])) {
                        $post_types = $silencer_Main_Settings['enabled_types'];
                    }
                    else
                    {
                        $post_types = array();
                    }
                    foreach ($post_types as $post_type) {
                        remove_meta_box('commentstatusdiv', $post_type, 'normal');
                        remove_meta_box('commentsdiv', $post_type, 'normal');
                    }
                });
            
            
                add_action( 'wp_dashboard_setup', function()
                {
                    if (isset($silencer_Main_Settings['enabled_track_types'])) {
                        $post_types = $silencer_Main_Settings['enabled_track_types'];
                    }
                    else
                    {
                        $post_types = array();
                    }
                    foreach ($post_types as $post_type) {
                        remove_meta_box('trackbacksdiv', $post_type, 'normal');
                    }
                });
            
        }
        if (isset($silencer_Main_Settings['disable_admin_bar']) && $silencer_Main_Settings['disable_admin_bar'] == 'on')
        {
            add_action('wp_before_admin_bar_render', 'silencer_disable_comments_admin_bar');
        }
        if (isset($silencer_Main_Settings['disable_comments_sidebar']) && $silencer_Main_Settings['disable_comments_sidebar'] == 'on')
        {
            add_action('widgets_init', 'silencer_disable_comments_side_bar');
        }
        if (isset($silencer_Main_Settings['disable_xmlrpc']) && $silencer_Main_Settings['disable_xmlrpc'] == 'on')
        {
            add_filter('wp_headers', 'silencer_filter_wp_headers');
            add_action('xmlrpc_methods', 'silencer_filter_xmlrpc_methods');
        }
        if (isset($silencer_Main_Settings['disable_comment_feed']) && $silencer_Main_Settings['disable_comment_feed'] == 'on')
        {
            add_action( 'template_redirect', 'silencer_filter_query');
        }
        if (isset($silencer_Main_Settings['google_plus']) && $silencer_Main_Settings['google_plus'] == 'on')
        {
            add_filter('preprocess_comment', 'disable_google_plus_ownership');
        }
        if (isset($silencer_Main_Settings['rsd_link']) && $silencer_Main_Settings['rsd_link'] == 'on')
        {
            remove_action('wp_head', 'rsd_link');
        }
        if (isset($silencer_Main_Settings['hide_feed_link']) && $silencer_Main_Settings['hide_feed_link'] == 'on')
        {
            add_action( 'wp_footer', 'silencer_hide_meta_widget_link');
            add_filter( 'feed_links_show_comments_feed', '__return_false' );
        }
    }
}

function silencer_ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array(
        "name",
        "\n",
        "\t",
        " ",
        "-",
        "_"
    ), NULL, strtolower(trim($purpose)));
    $support    = array(
        "country",
        "countrycode",
        "state",
        "region",
        "city",
        "location",
        "address"
    );
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array(
                        $ipdat->geoplugin_countryName
                    );
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}

function silencer_preprocess_comment($comment) {
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    if(isset($silencer_Main_Settings['comments_maximum_length_value']) && $silencer_Main_Settings['comments_maximum_length_value'] !== '')
    {
        if ( strlen( $comment['comment_content'] ) > intval($silencer_Main_Settings['comments_maximum_length_value']) ) {
            wp_die('Comment is too long. Please keep your comment under '. $silencer_Main_Settings['comments_maximum_length_value'] . ' characters.');
        }
    }
    if(isset($silencer_Main_Settings['comments_minimum_length_value']) && $silencer_Main_Settings['comments_minimum_length_value'] !== '')
    {
        if ( strlen( $comment['comment_content'] ) < intval($silencer_Main_Settings['comments_minimum_length_value']) ) {
            wp_die('Comment is too short. Please use at least '. $silencer_Main_Settings['comments_minimum_length_value'] . ' characters.');
        }
    }
    return $comment;
}

function silencer_comment_post( $incoming_comment )
{
	$incoming_comment['comment_content'] = htmlspecialchars( $incoming_comment['comment_content'] );
	$incoming_comment['comment_content'] = str_replace( "'", '&apos;', $incoming_comment['comment_content'] );
	return( $incoming_comment );
}

function silencer_comment_display( $comment_to_display )
{
	$comment_to_display = str_replace( '&apos;', "&#039;", $comment_to_display );
    $comment_to_display = html_entity_decode($comment_to_display);
    $comment_to_display = wp_trim_words($comment_to_display, 999999);
    $comment_to_display = strip_tags($comment_to_display);
	return $comment_to_display;
}

function silencer_wp_loaded() {
    global $post;
    if(isset($post))
    {
        $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
        if (isset($silencer_Main_Settings['silencer_enabled']) && $silencer_Main_Settings['silencer_enabled'] == 'on')
        {
            $trackback_disabled = 0;
            if(isset($silencer_Main_Settings['enabled_track_types']))
            {
                if(in_array($post->post_type, $silencer_Main_Settings['enabled_track_types']))
                {
                    add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                    remove_post_type_support($post->post_type, 'trackbacks');
                    add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                    $trackback_disabled = 1;
                }
            }
            if($trackback_disabled == 0)
            {
                if(isset($silencer_Main_Settings['trackback_users']))
                {
                    if($silencer_Main_Settings['trackback_users'] == 'notloggedin' && !is_user_logged_in())
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                    elseif($silencer_Main_Settings['trackback_users'] == 'loggedin' && is_user_logged_in())
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                    elseif($silencer_Main_Settings['trackback_users'] == 'notadmin' && !current_user_can('administrator'))
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                    elseif($silencer_Main_Settings['trackback_users'] == 'admin' && current_user_can('administrator'))
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_cats']) && ! empty( $silencer_Main_Settings['trackback_cats'] ))
                {
                    $match = 0;
                    $categories = get_the_category();
                    if ( ! empty( $categories ) ) {
                        foreach( $categories as $category ) {
                            foreach ($silencer_Main_Settings['trackback_cats'] as $cat) {
                                if($category->term_id == $cat)
                                {
                                    $match = 1;
                                }
                            }
                        }
                    }
                    if($match == 1)
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_tags']) && $silencer_Main_Settings['trackback_tags'] != '')
                {
                    $match = 0;
                    $id = get_the_ID();
                    if($id !== false)
                    {
                        $tags = wp_get_post_tags($id);
                        if(!empty($tags))
                        {
                            foreach( $tags as $tag_id ) 
                            {
                                $tag = get_tag($tag_id);
                                $def_tags = explode(',',$silencer_Main_Settings['trackback_tags']);
                                foreach ($def_tags as $def_tag) 
                                {
                                    if(trim($def_tag) == $tag->name)
                                    {
                                        $match = 1;
                                    }
                                }
                            }                
                        }
                    }
                    if($match == 1)
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_url']) && $silencer_Main_Settings['trackback_url'] != '')
                {
                    if (isset($silencer_Main_Settings['trackback_url_wildcard']) && $silencer_Main_Settings['trackback_url_wildcard'] == 'on')
                    {
                        $wildcard = '1';
                    }
                    else
                    {
                        $wildcard = '0';
                    }
                    $storedrequests = $silencer_Main_Settings['trackback_url'];
                    $storedrequests = explode(",", $storedrequests);
                    foreach($storedrequests as $storedrequest)
                    {
                        $actual_link = 'http' . ((silencer_isSecure()) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
                        $short_url = str_ireplace(get_home_url(),'',$actual_link);
                        if ($wildcard === '1') {
                            if (fnmatch($storedrequest, $short_url)) {
                                add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                                remove_post_type_support($post->post_type, 'trackbacks');
                                add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                                $trackback_disabled = 1;
                            }
                        }
                        else
                        {
                            if(rtrim($short_url,'/') === rtrim($storedrequest,'/'))
                            {
                                add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                                remove_post_type_support($post->post_type, 'trackbacks');
                                add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                                $trackback_disabled = 1;
                            }
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_refs']) && $silencer_Main_Settings['trackback_refs'] != '')
                {
                    $match = 0;
                    if(isset($_SERVER['HTTP_REFERER'])) 
                    {
                        $referrer = $_SERVER['HTTP_REFERER'];
                    }
                    else
                    {
                        $referrer = '';
                    }
                    $def_refs = explode(',', $silencer_Main_Settings['trackback_refs']);
                    foreach ($def_refs as $def_ref) 
                    {
                        if(trim($def_ref) == $referrer)
                        {
                            $match = 1;
                        }
                    }
                    if($match == 1)
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_ips']) && $silencer_Main_Settings['trackback_ips'] != '')
                {
                    $ips = explode(",", $silencer_Main_Settings['trackback_ips']);
                    $userIp = silencer_get_the_user_ip();
                    foreach($ips as $ip)
                    {
                        if($userIp == trim($ip))
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_browsers']) && $silencer_Main_Settings['trackback_browsers'] != '' && $silencer_Main_Settings['trackback_browsers'] != 'NONE')
                {
                    if ($silencer_Main_Settings['trackback_browsers'] == 'ALL')
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                    }
                    $user_agent = $_SERVER['HTTP_USER_AGENT'];
                    $browserName = $silencer_Main_Settings['trackback_browsers'];
                    $bd = new silencerBrowserDetection();
                        $browser =  $bd->silencer_detect()->silencer_getBrowser();
                        if(stripos($browser, 'explorer') !== false) {
                            $browser = 'IE';
                        } 
                        elseif(stripos($browser, 'chrome') !== false) {
                            if( stripos($user_agent,'edge/') !== false ) 
                            {
                                $aresult = explode('/', stristr($user_agent, 'edge'));
                                if (isset($aresult[1])) 
                                {
                                    $browser = 'Edge';
                                }
                                else
                                {
                                    $browser = 'Chrome';
                                }
                            }
                            else
                            {
                                $browser = 'Chrome';
                            }
                        }
                        elseif(stripos($browser, 'edge') !== false) {
                            $browser = 'Edge';
                        } 
                        elseif(stripos($browser, 'safari') !== false) {
                            $browser = 'Safari';
                        } 
                        elseif(stripos($browser, 'opera') !== false) {
                            $browser = 'Opera';
                        } 
                        elseif(stripos($browser, 'firefox') !== false) {
                            $browser = 'Firefox';
                        }
                        else
                        {
                            $browser = 'Other';
                        }
                        if($browserName === $browser)
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_oses']) && $silencer_Main_Settings['trackback_oses'] != '' && $silencer_Main_Settings['trackback_oses'] != 'NONE')
                {
                    if ($silencer_Main_Settings['trackback_oses'] == 'ALL')
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                    }
                    $os = $silencer_Main_Settings['trackback_oses'];
                    $userOs = silencer_getOS();
                    if($os === "All Windows")
                    {
                        if (stripos($userOs, 'Windows') !== false) 
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                    elseif($os === "All Apple")
                    {
                        if($userOs === "iOs" || $userOs === "iPhone" || $userOs === "iPod" || $userOs === "iPad")
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                    elseif($os === "All Mac")
                    {
                        if($userOs === "Mac OS X" || $userOs === "Mac OS 9")
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                    elseif($os === "All Linux")
                    {
                        if($userOs === "Linux" && $userOs === "Ubuntu")
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                    else
                    {
                        if($os === $userOs)
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_devices']) && $silencer_Main_Settings['trackback_devices'] != '')
                {
                    $device = $silencer_Main_Settings['trackback_devices'];
                    if($device == 'ALL')
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                    }
                    elseif($device != 'NONE')
                    {
                        $user_agent = $_SERVER['HTTP_USER_AGENT'];
                        $mobile = false;
                        $tablet = false;
                        $bot = false;
                        preg_match( '/Altavista|ia_archiver|facebookexternalhit|googlebot|adsbot|Yahoo!|Baiduspider|Yandex|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/i', $user_agent, $goodbot);
                        preg_match( '#bot|SiteLockSpider|crawler|archiver|transcoder|spider|uptime|validator|fetcher|MJ12bot|Ezooms|AhrefsBot|FHscan|Acunetix|Zyborg|ZmEu|Zeus|Xenu|Xaldon|WWW-Collector-E|WWWOFFLE|WISENutbot|Widow|Whacker|WebZIP|WebWhacker|WebStripper|Webster|Website\ Quester|Website\ eXtractor|WebSauger|WebReaper|WebmasterWorldForumBot|WebLeacher|Web.Image.Collector|WebGo\ IS|WebFetch|WebEnhancer|WebEMailExtrac|WebCopier|Webclipping.com|WebBandit|WebAuto|Web\ Sucker|Web\ Image\ Collector|VoidEYE|VCI|Vacuum|URLy.Warning|TurnitinBot|turingos|True_Robot|Titan|TightTwatBot|TheNomad|The.Intraformant|TurnitinBot/1.5|Telesoft|Teleport|tAkeOut|Szukacz/1.4|suzuran|Surfbot|SuperHTTP|SuperBot|Sucker|Stripper|Sqworm|spanner|SpankBot|SpaceBison|Snoopy|Snapbot|Snake|SmartDownload|SlySearch|SiteSnagger|Siphon|RMA|RepoMonkey|ReGet|Recorder|Reaper|RealDownload|QueryN.Metasearch|Pump|psbot|ProWebWalker|ProPowerBot/2.14|Pockey|PHP\ version\ tracker|pcBrowser|pavuk|Papa\ Foto|PageGrabber|OutfoxBot|Openfind|Offline\ Navigator|Offline\ Explorer|Octopus|NPbot|Ninja|NimbleCrawler|niki-bot|NICErsPRO|NG|NextGenSearchBot|NetZIP|Net\ Vampire|NetSpider|NetMechanic|Netcraft|NetAnts|NearSite|Navroad|NAMEPROTECT|Mozilla.*NEWT|Mozilla/3.Mozilla/2.01|moget|Mister\ PiX|Missigua\ Locator|Mirror|MIIxpc|MIDown\ tool|Microsoft\ URL\ Control|Microsoft.URL|Memo|Mata.Hari|Mass\ Downloader|MarkWatch|Mag-Net|Magnet|LWP::Simple|lwp-trivial|LinkWalker|LNSpiderguy|LinkScan/8.1a.Unix|LinkextractorPro|likse|libWeb/clsHTTP|lftp|LexiBot|larbin|Keyword.Density|Kenjin.Spider|Jyxobot|JustView|JOC|JetCar|JennyBot|Jakarta|Iria|Internet\ Ninja|InterGET|Intelliseek|InfoTekies|InfoNaviRobot|Indy\ Library|Image\ Sucker|Image\ Stripper|IlseBot|humanlinks|HTTrack|HMView|hloader|Harvest|Grafula|GrabNet|gotit|Go-Ahead-Got-It|FrontPage|flunky|Foobot|EyeNetIE|Extractor|Express\ WebPictures|Exabot|EroCrawler|EmailWolf|EmailSiphon|EmailCollector|EirGrabber|ebingbong|EasyDL|eCatch|Drip|dragonfly|Download\ Wonder|Download\ Devil|Download\ Demon|DittoSpyder|DIIbot|DISCo|AIBOT|Aboundex|Custo|Crescent|cosmos|CopyRightCheck|Copier|Collector|ChinaClaw|CherryPicker|CheeseBot|Cegbfeieh|BunnySlippers|Bullseye|BuiltBotTough|Buddy|BotALot|BlowFish|BlackWidow|Black.Hole|Bigfoot|BatchFTP|Bandit|BackWeb|BackDoorBot|80legs|360Spider|Java|Cogentbot|Alexibot|asterias|attach|eStyle|WebCrawler|Dumbot|CrocCrawler|ASPSeek|AcoiRobot|DuckDuckBot|BLEXBot|Ips Agent|bot|crawl|slurp|spider|outbrain|008|192.comAgent|2ip\.ru|404checker|^bluefish |^FDM |^git|^Goose|^HTTPClient|^Java|^Jetty|^Mget|^Microsoft URL Control|^NG\/[0-9\.]|^NING|^PHP\/[0-9]|^RMA|^Ruby|Ruby\/[0-9]|^scrutiny|^VSE\/[0-9]|^WordPress\.com|^XRL\/[0-9]|a3logics\.in|A6-Indexer|a\.pr-cy\.ru|Aboundex|aboutthedomain|Accoona|acoon|acrylicapps\.com\/pulp|adbeat|AddThis|ADmantX|adressendeutschland|Advanced Email Extractor v|agentslug|AHC|aihit|aiohttp|Airmail|akula|alertra|alexa site audit|Alibaba\.Security\.Heimdall|alyze\.info|amagit|AndroidDownloadManager|Anemone|Ant\.com|Anturis Agent|AnyEvent-HTTP|Apache-HttpClient|AportWorm\/[0-9]|AppEngine-Google|Arachmo|arachnode|Arachnophilia|archive-com|aria2|asafaweb.com|AskQuickly|Astute|asynchttp|autocite|Autonomy|B-l-i-t-z-B-O-T|Backlink-Ceck\.de|Bad-Neighborhood|baidu\.com|baypup\/[0-9]|baypup\/colbert|BazQux|BCKLINKS|BDFetch|BegunAdvertising|bibnum\.bnf|BigBozz|biglotron|BingLocalSearch|BingPreview|binlar|biz_Directory|Blackboard Safeassign|Bloglovin|BlogPulseLive|BlogSearch|Blogtrottr|boitho\.com-dc|BPImageWalker|Braintree-Webhooks|Branch Metrics API|Branch-Passthrough|Browsershots|BUbiNG|Butterfly|BuzzSumo|CakePHP|CapsuleChecker|CaretNail|cb crawl|CC Metadata Scaper|Cerberian Drtrs|CERT\.at-Statistics-Survey|cg-eye|changedetection|Charlotte|CheckHost|chkme\.com|CirrusExplorer|CISPA Vulnerability Notification|CJNetworkQuality|clips\.ua\.ac\.be|Cloud mapping experiment|CloudFlare-AlwaysOnline|Cloudinary\/[0-9]|cmcm\.com|coccoc|CommaFeed|Commons-HttpClient|Comodo SSL Checker|contactbigdatafr|convera|copyright sheriff|cosmos\/[0-9]|Covario-IDS|CrawlForMe\/[0-9]|cron-job\.org|Crowsnest|curb|Curious George|curl|cuwhois\/[0-9]|CyberPatrol|cybo\.com|DareBoost|DataparkSearch|dataprovider|Daum(oa)?[ \/][0-9]|DeuSu|developers\.google\.com\/\+\/web\/snippet|Digg|Dispatch|dlvr|DNS-Tools Header-Analyzer|DNSPod-reporting|docoloc|DomainAppender|dotSemantic|downforeveryoneorjustme|downnotifier\.com|DowntimeDetector|Dragonfly File Reader|drupact|Drupal (\+http:\/\/drupal\.org\/)|dubaiindex|EARTHCOM|Easy-Thumb|ec2linkfinder|eCairn-Grabber|ECCP|ElectricMonk|elefent|EMail Exractor|EmailWolf|Embed PHP Library|Embedly|europarchive\.org|evc-batch\/[0-9]|EventMachine HttpClient|Evidon|Evrinid|ExactSearch|ExaleadCloudview|Excel|Exploratodo|ezooms|facebookexternalhit|facebookplatform|fairshare|Faraday v|Faveeo|Favicon downloader|FavOrg|Feed Wrangler|Feedbin|FeedBooster|FeedBucket|FeedBurner|FeedChecker|Feedly|Feedspot|feeltiptop|Fetch API|Fetch\/[0-9]|Fever\/[0-9]|findlink|findthatfile|Flamingo_SearchEngine|FlipboardBrowserProxy|FlipboardProxy|FlipboardRSS|fluffy|flynxapp|forensiq|FoundSeoTool\/[0-9]|free thumbnails|FreeWebMonitoring SiteChecker|Funnelback|g00g1e\.net|GAChecker|geek-tools|Genderanalyzer|Genieo|GentleSource|GetLinkInfo|getprismatic\.com|GetURLInfo\/[0-9]|GigablastOpenSource|Go [\d\.]* package http|Go-http-client|GomezAgent|gooblog|Goodzer\/[0-9]|Google favicon|Google Keyword Suggestion|Google Keyword Tool|Google Page Speed Insights|Google PP Default|Google Search Console|Google Web Preview|Google-Adwords|Google-Apps-Script|Google-Calendar-Importer|Google-HTTP-Java-Client|Google-Publisher-Plugin|Google-SearchByImage|Google-Site-Verification|Google-Structured-Data-Testing-Tool|google_partner_monitoring|GoogleDocs|GoogleHC|GoogleProducer|GoScraper|GoSpotCheck|GoSquared-Status-Checker|gosquared-thumbnailer|GotSiteMonitor|Grammarly|grouphigh|grub-client|GTmetrix|gvfs|HAA(A)?RTLAND http client|Hatena|hawkReader|HEADMasterSEO|HeartRails_Capture|heritrix|hledejLevne\.cz\/[0-9]|Holmes|HootSuite Image proxy|Hootsuite-WebFeed\/[0-9]|HostTracker|ht:\/\/check|htdig|HTMLParser|HTTP-Header-Abfrage|http-kit|HTTP-Tiny|HTTP_Compression_Test|http_request2|http_requester|HttpComponents|httphr|HTTPMon|httpscheck|httpssites_power|httpunit|HttpUrlConnection|httrack|hosterstats|huaweisymantec|HubPages.*crawlingpolicy|HubSpot Connect|HubSpot Marketing Grader|HyperZbozi.cz Feeder|ichiro|IdeelaborPlagiaat|IDG Twitter Links Resolver|IDwhois\/[0-9]|Iframely|igdeSpyder|IlTrovatore|ImageEngine|Imagga|InAGist|inbound\.li parser|InDesign|infegy|infohelfer|InfoWizards Reciprocal Link System PRO|inpwrd\.com|Integrity|integromedb|internet_archive|InternetSeer|internetVista monitor|IODC|IOI|ips-agent|iqdb|Irokez|isitup\.org|iskanie|iZSearch|janforman|Jigsaw|Jobboerse|jobo|Jobrapido|KeepRight OpenStreetMap Checker|KickFire|KimonoLabs|knows\.is|kouio|KrOWLer|kulturarw3|KumKie|L\.webis|Larbin|LayeredExtractor|LibVLC|libwww|Liferea|link checker|Link Valet|link_thumbnailer|linkCheck|linkdex|LinkExaminer|linkfluence|linkpeek|LinkTiger|LinkWalker|Lipperhey|livedoor ScreenShot|LoadImpactPageAnalyzer|LoadImpactRload|LongURL API|looksystems\.net|ltx71|lwp-trivial|lycos|LYT\.SR|mabontland|MagpieRSS|Mail.Ru|MailChimp\.com|Mandrill|marketinggrader|Mediapartners-Google|MegaIndex\.ru|Melvil Rawi|MergeFlow-PageReader|MetaInspector|Metaspinner|MetaURI|Microsearch|Microsoft Office |Microsoft Windows Network Diagnostics|Mindjet|Miniflux|Mnogosearch|mogimogi|Mojolicious (Perl)|monitis|Monitority\/[0-9]|montastic|MonTools|Moreover|Morning Paper|mowser|Mrcgiguy|mShots|MVAClient|nagios|Najdi\.si|NETCRAFT|NetLyzer FastProbe|netresearch|NetShelter ContentScan|NetTrack|Netvibes|Neustar WPM|NeutrinoAPI|NewsBlur .*Finder|NewsGator|newsme|newspaper|NG-Search|nineconnections\.com|NLNZ_IAHarvester|Nmap Scripting Engine|node-superagent|node\.io|nominet\.org\.uk|Norton-Safeweb|Notifixious|notifyninja|nuhk|nutch|Nuzzel|nWormFeedFinder|Nymesis|Ocelli\/[0-9]|oegp|okhttp|Omea Reader|omgili|Online Domain Tools|OpenCalaisSemanticProxy|Openstat|OpenVAS|Optimizer|Orbiter|OrgProbe\/[0-9]|ow\.ly|ownCloud News|Page Analyzer|Page Valet|page2rss|page_verifier|PagePeeker|Pagespeed\/[0-9]|Panopta|panscient|parsijoo|PayPal IPN|Pcore-HTTP|Pearltrees|peerindex|Peew|PhantomJS|Photon|phpcrawl|phpservermon|Pi-Monster|Pingdom\.com|Pingoscope|PingSpot|Pinterest|Pizilla|Ploetz \+ Zeller|Plukkie|PocketParser|Pompos|Porkbun|Port Monitor|postano|PostPost|postrank|PowerPoint|Priceonomics Analysis Engine|Prlog|probethenet|Project 25499|Promotion_Tools_www.searchenginepromotionhelp.com|prospectb2b|Protopage|proximic|PTST |PTST\/[0-9]+|Pulsepoint XT3 web scraper|Python-httplib2|python-requests|Python-urllib|Qirina Hurdler|Qseero|Qualidator.com SiteAnalyzer|Quora Link Preview|Qwantify|Radian6|RankSonicSiteAuditor|Readability|RealPlayer%20Downloader|RebelMouse|redback|Redirect Checker Tool|ReederForMac|request\.js|ResponseCodeTest\/[0-9]|RestSharp|RetrevoPageAnalyzer|Riddler|Rival IQ|Robosourcer|Robozilla\/[0-9]|ROI Hunter|SalesIntelligent|SauceNAO|SBIder|Scoop|scooter|ScoutJet|ScoutURLMonitor|Scrapy|Scrubby|SearchSight|semanticdiscovery|semanticjuice|SEO Browser|Seo Servis|seo-nastroj.cz|Seobility|SEOCentro|SeoCheck|SeopultContentAnalyzer|SEOstats|Server Density Service Monitoring|servernfo\.com|Seznam screenshot-generator|Shelob|Shoppimon Analyzer|ShoppimonAgent\/[0-9]|ShopWiki|ShortLinkTranslate|shrinktheweb|SilverReader|SimplePie|SimplyFast|Site-Shot|Site24x7|SiteBar|SiteCondor|siteexplorer\.info|SiteGuardian|Siteimprove\.com|Sitemap(s)? Generator|Siteshooter B0t|SiteTruth|sitexy\.com|SkypeUriPreview|slider\.com|slurp|SMRF URL Expander|SMUrlExpander|Snappy|SniffRSS|sniptracker|Snoopy|sogou|SortSite|spaziodati|Specificfeeds|speedy|SPEng|Spinn3r|spray-can|Sprinklr |spyonweb|Sqworm|SSL Labs|Rambler|Statastico|StatusCake|Stratagems Kumo|Stroke.cz|StudioFACA|suchen|summify|Super Monitoring|Surphace Scout|SwiteScraper|Symfony2 BrowserKit|SynHttpClient-Built|Sysomos|T0PHackTeam|Tarantula|teoma|terrainformatica\.com|The Expert HTML Source Viewer|theinternetrules|theoldreader\.com|Thumbshots|ThumbSniper|TinEye|Tiny Tiny RSS|topster|touche.com|Traackr.com|truwoGPS|tweetedtimes\.com|Tweetminster|Twikle|Twingly|Typhoeus|ubermetrics-technologies|uclassify|UdmSearch|UnwindFetchor|updated|Upflow|URLChecker|URLitor.com|urlresolver|Urlstat|UrlTrends Ranking Updater|Vagabondo|via ggpht\.com GoogleImageProxy|visionutils|vkShare|voltron|Vortex\/[0-9]|voyager|VSAgent\/[0-9]|VSB-TUO\/[0-9]|VYU2|w3af\.org|W3C-checklink|W3C-mobileOK|W3C_I18n-Checker|W3C_Unicorn|wangling|Wappalyzer|WatchMouse|WbSrch|web-capture\.net|Web-Monitoring|Web-sniffer|Webauskunft|WebCapture|webcollage|WebCookies|WebCorp|WebDoc|WebFetch|WebImages|WebIndex|webkit2png|webmastercoffee|webmon |webscreenie|Webshot|Website Analyzer|websitepulse[+ ]checker|Websnapr|Websquash\.com|Webthumb\/[0-9]|WebThumbnail|WeCrawlForThePeace|WeLikeLinks|WEPA|WeSEE|wf84|wget|WhatsApp|WhatsMyIP|WhatWeb|Whibse|Whynder Magnet|Windows-RSS-Platform|WinHttpRequest|wkhtmlto|wmtips|Woko|WomlpeFactory|Word|WordPress|wotbox|WP Engine Install Performance API|WPScan|wscheck|WWW-Mechanize|www\.monitor\.us|XaxisSemanticsClassifier|Xenu Link Sleuth|XING-contenttabreceiver\/[0-9]|XmlSitemapGenerator|xpymep([0-9]?)\.exe|Y!J-(ASR|BSC)|Yaanb|yacy|Yahoo Ad monitoring|Yahoo Link Preview|YahooCacheSystem|YahooSeeker|YahooYSMcm|YandeG|yandex|yanga|yeti|Yo-yo|Yoleo Consumer|yoogliFetchAgent|YottaaMonitor|yourls\.org|Zao|Zemanta Aggregator|Zend\\\\Http\\\\Client|Zend_Http_Client|zgrab|ZnajdzFoto|ZyBorg#i', $user_agent, $badbot);
                        if($goodbot || $badbot)
                        {
                            $bot = true;
                        }
                        preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
                        preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($user_agent,0,4), $matches2);
                        if($matches || $matches2)
                        {
                            $mobile = true;
                        }
                        preg_match('/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle|NRD90M|SGP771|SHIELD|SM-T550|KFTHWI|LG-V410|nexus/i', $user_agent, $matches3);
                        if($matches3)
                        {
                            $tablet = true;
                        }
                        if($device === 'Bot')
                        {
                            if($bot === true)
                            {
                                add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                            }
                        }
                        if($device === 'Mobile')
                        {
                            if($mobile === true)
                            {
                                add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                            }
                        }
                        if($device === 'Tablet')
                        {
                            if($tablet === true)
                            {
                                add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                            }
                        }
                        if($device === 'Desktop')
                        {
                            if($tablet === false && $mobile === false && $bot === false)
                            {
                                add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                            }
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_authors']) && !empty($silencer_Main_Settings['trackback_authors']))
                {
                    $id = get_the_author_meta( 'ID' );
                    if($id != '')
                    {
                        if(in_array($id, $silencer_Main_Settings['trackback_authors']))
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_login']) && !empty($silencer_Main_Settings['trackback_login']))
                {
                    $id = get_current_user_id();
                    if($id != 0)
                    {
                        if(in_array($id, $silencer_Main_Settings['trackback_login']))
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_country']) && $silencer_Main_Settings['trackback_country'] != '')
                {
                    $country = $silencer_Main_Settings['trackback_country'];
                    if($country === 'ALL')
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                    elseif($country !== 'NONE')
                    {
                        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
                            $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
                        } else {
                            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                                $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                            } else {
                                $real_ip_adress = $_SERVER['REMOTE_ADDR'];
                            }
                        }
                        $country_code = silencer_ip_info($real_ip_adress, "Country Code");
                        if(strcasecmp($country, $country_code) == 0)
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                if (isset($silencer_Main_Settings['trackback_language']) && $silencer_Main_Settings['trackback_language'] != '')
                {
                    $language = $silencer_Main_Settings['trackback_language'];
                    if($language == 'ALL')
                    {
                        add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                        remove_post_type_support($post->post_type, 'trackbacks');
                        add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                        $trackback_disabled = 1;
                    }
                    elseif($language != 'NONE')          
                    {
                        $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
                        if(strcasecmp($language, $lang) == 0)
                        {
                            add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                            remove_post_type_support($post->post_type, 'trackbacks');
                            add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                            $trackback_disabled = 1;
                        }
                    }
                }
            }
            if($trackback_disabled == 0)
            {
                $silencer_stored_meta = get_post_meta( $post->ID );
                if ( isset ( $silencer_stored_meta["disable_trackbacks"]) && $silencer_stored_meta["disable_trackbacks"][0] == "on" ) 
                {
                    add_filter('pre_option_default_ping_status', 'silencer_disable_default_ping_status');
                    remove_post_type_support($post->post_type, 'trackbacks');
                    add_filter('rewrite_rules_array', 'silencer_filter_trackback_rewrites');
                }
            }
        }
    }
}
function silencer_getOS() { 
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
                            '/windows nt 10/i'      =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );
    foreach ($os_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }
    }   
    return $os_platform;
}
function silencer_hide_meta_widget_link(){
		if ( is_active_widget( false, false, 'meta', true ) && wp_script_is( 'jquery', 'enqueued' ) ) {
			echo '<script> jQuery(function(jQuery){ jQuery(".widget_meta a[href=\'' . esc_url( get_bloginfo( 'comments_rss2_url' ) ) . '\']").parent().remove();jQuery("#recent-comments-2").hide(); }); </script>';
		}
	}
function silencer_override_comment_template()
{
    if (is_singular()) {
        add_filter('comments_template', 'silencer_empty_comments_template');
        wp_deregister_script('comment-reply');
        remove_action( 'wp_head', 'feed_links_extra', 3 );
    }
}
function silencer_empty_comments_template()
{
    return '';
}
function disable_google_plus_ownership($commentdata)
{
    if (preg_match('/http(s)?:\/\/plus\.google\.com(.*)$/', $commentdata['comment_author_url'])) {
        unset($commentdata['comment_author_url']);
    }
    return $commentdata;
}
function silencer_filter_query() {
	if( is_comment_feed() ) {
		wp_die( __( 'Commenting is closed.' ), '', array( 'response' => 403 ) );
	}
}
function silencer_filter_wp_headers( $headers ) {
	unset( $headers['X-Pingback'] );
	return $headers;
}
function silencer_filter_xmlrpc_methods($methods)
{
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    unset($methods['pingback.ping']);
    unset($methods['pingback.extensions.getPingbacks']);
    unset($methods['mt.getTrackbackPings']);
    return $methods;
}
function silencer_disable_comments_side_bar() {
    global $wp_widget_factory;
    if ( has_filter('wp_head', 'wp_widget_recent_comments_style') ) {
      remove_filter('wp_head', 'wp_widget_recent_comments_style' );
    }
	remove_action('wp_head', array($wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style'));
    unregister_widget( 'WP_Widget_Recent_Comments' );
}
function silencer_dashboard_site_activity() {
        
        echo '<div id="activity-widget">';

        $future_posts = wp_dashboard_recent_posts( array(
                'max'     => 5,
                'status'  => 'future',
                'order'   => 'ASC',
                'title'   => __( 'Publishing Soon' ),
                'id'      => 'future-posts',
        ) );
        $recent_posts = wp_dashboard_recent_posts( array(
                'max'     => 5,
                'status'  => 'publish',
                'order'   => 'DESC',
                'title'   => __( 'Recently Published' ),
                'id'      => 'published-posts',
        ) );
   
        $recent_comments = false;

        if ( !$future_posts && !$recent_posts && !$recent_comments ) {
                echo '<div class="no-activity">';
                echo '<p class="smiley"></p>';
                echo '<p>' . __( 'No activity yet!' ) . '</p>';
                echo '</div>';
        }

        echo '</div>';
}

add_action('init', 'silencer_disable_comments_post_types_support');
add_action('wp', 'silencer_wp_loaded');
function silencer_existing_comments($comments, $post_id) {
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
	$post = get_post( $post_id );
    if(isset($silencer_Main_Settings['enabled_existing_types']))
    {
        if(in_array($post->post_type, $silencer_Main_Settings['enabled_existing_types']))
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_users']))
    {
        if($silencer_Main_Settings['hide_users'] == 'notloggedin' && !is_user_logged_in())
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_users']))
    {
        if($silencer_Main_Settings['hide_users'] == 'loggedin' && is_user_logged_in())
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_users']))
    {
        if($silencer_Main_Settings['hide_users'] == 'notadmin' && !current_user_can('administrator'))
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_users']))
    {
        if($silencer_Main_Settings['hide_users'] == 'admin' && current_user_can('administrator'))
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_cats']) && ! empty( $silencer_Main_Settings['hide_cats'] ))
    {
        $match = 0;
        $categories = get_the_category();
        if ( ! empty( $categories ) ) {
            foreach( $categories as $category ) {
                foreach ($silencer_Main_Settings['hide_cats'] as $cat) {
                    if($category->term_id == $cat)
                    {
                        $match = 1;
                    }
                }
            }
        }
        if($match == 1)
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_url']) && $silencer_Main_Settings['hide_url'] != '')
    {
        if (isset($silencer_Main_Settings['hide_url_wildcard']) && $silencer_Main_Settings['hide_url_wildcard'] == 'on')
        {
            $wildcard = '1';
        }
        else
        {
            $wildcard = '0';
        }
        $storedrequests = $silencer_Main_Settings['hide_url'];
        $storedrequests = explode(",", $storedrequests);
        foreach($storedrequests as $storedrequest)
        {
            $actual_link = 'http' . ((silencer_isSecure()) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
            $short_url = str_ireplace(get_home_url(),'',$actual_link);
            if ($wildcard === '1') {
                if (fnmatch($storedrequest, $short_url)) {
                    return array();
                }
            }
            else
            {
                if(rtrim($short_url,'/') === rtrim($storedrequest,'/'))
                {
                    return array();
                }
            }
        }
    }
    if (isset($silencer_Main_Settings['hide_tags']) && $silencer_Main_Settings['hide_tags'] != '')
    {
        $match = 0;
        $id = get_the_ID();
        if($id !== false)
        {
            $tags = wp_get_post_tags($id);
            if(!empty($tags))
            {
                foreach( $tags as $tag_id ) 
                {
                    $tag = get_tag($tag_id);
                    $def_tags = explode(',',$silencer_Main_Settings['hide_tags']);
                    foreach ($def_tags as $def_tag) 
                    {
                        if(trim($def_tag) == $tag->name)
                        {
                            $match = 1;
                        }
                    }
                }                
            }
        }
        if($match == 1)
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_refs']) && $silencer_Main_Settings['hide_refs'] != '')
    {
        $match = 0;
        if(isset($_SERVER['HTTP_REFERER'])) 
        {
            $referrer = $_SERVER['HTTP_REFERER'];
        }
        else
        {
            $referrer = '';
        }
        $def_refs = explode(',', $silencer_Main_Settings['hide_refs']);
        foreach ($def_refs as $def_ref) 
        {
            if(trim($def_ref) == $referrer)
            {
                $match = 1;
            }
        }
        if($match == 1)
        {
            return array();
        }
    }
    if (isset($silencer_Main_Settings['hide_ips']) && $silencer_Main_Settings['hide_ips'] != '')
    {
        $ips = explode(",", $silencer_Main_Settings['hide_ips']);
        $userIp = silencer_get_the_user_ip();
        foreach($ips as $ip)
        {
            if($userIp == trim($ip))
            {
                return array();
            }
        }
    }
    if (isset($silencer_Main_Settings['hide_browsers']) && $silencer_Main_Settings['hide_browsers'] != '' && $silencer_Main_Settings['hide_browsers'] != 'NONE')
    {
        if ($silencer_Main_Settings['hide_browsers'] == 'ALL')
        {
            return array();
        }
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $browserName = $silencer_Main_Settings['hide_browsers'];
        $bd = new silencerBrowserDetection();
            $browser =  $bd->silencer_detect()->silencer_getBrowser();
            if(stripos($browser, 'explorer') !== false) {
	    		$browser = 'IE';
	    	} 
	    	elseif(stripos($browser, 'chrome') !== false) {
                if( stripos($user_agent,'edge/') !== false ) 
                {
                    $aresult = explode('/', stristr($user_agent, 'edge'));
                    if (isset($aresult[1])) 
                    {
                        $browser = 'Edge';
                    }
                    else
                    {
                        $browser = 'Chrome';
                    }
                }
                else
                {
                    $browser = 'Chrome';
                }
	    	}
            elseif(stripos($browser, 'edge') !== false) {
				$browser = 'Edge';
	    	} 
	    	elseif(stripos($browser, 'safari') !== false) {
				$browser = 'Safari';
			} 
			elseif(stripos($browser, 'opera') !== false) {
				$browser = 'Opera';
			} 
			elseif(stripos($browser, 'firefox') !== false) {
				$browser = 'Firefox';
			}
            else
            {
                $browser = 'Other';
            }
            if($browserName === $browser)
            {
                return array();
            }
    }
    if (isset($silencer_Main_Settings['hide_oses']) && $silencer_Main_Settings['hide_oses'] != '' && $silencer_Main_Settings['hide_oses'] != 'NONE')
                {
                    if ($silencer_Main_Settings['hide_oses'] == 'ALL')
                    {
                       return array();
                    }
                    $os = $silencer_Main_Settings['hide_oses'];
                    $userOs = silencer_getOS();
                    if($os === "All Windows")
                    {
                        if (stripos($userOs, 'Windows') !== false) 
                        {
                            return array();
                        }
                    }
                    elseif($os === "All Apple")
                    {
                        if($userOs === "iOs" || $userOs === "iPhone" || $userOs === "iPod" || $userOs === "iPad")
                        {
                            return array();
                        }
                    }
                    elseif($os === "All Mac")
                    {
                        if($userOs === "Mac OS X" || $userOs === "Mac OS 9")
                        {
                            return array();
                        }
                    }
                    elseif($os === "All Linux")
                    {
                        if($userOs === "Linux" && $userOs === "Ubuntu")
                        {
                            return array();
                        }
                    }
                    else
                    {
                        if($os === $userOs)
                        {
                            return array();
                        }
                    }
                }
    if (isset($silencer_Main_Settings['hide_devices']) && $silencer_Main_Settings['hide_devices'] != '')
    {
        $device = $silencer_Main_Settings['hide_devices'];
        if($device == 'ALL')
        {
            return array();
        }
        elseif($device != 'NONE')
        {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
            $mobile = false;
            $tablet = false;
            $bot = false;
            preg_match( '/Altavista|ia_archiver|facebookexternalhit|googlebot|adsbot|Yahoo!|Baiduspider|Yandex|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/i', $user_agent, $goodbot);
            preg_match( '#bot|SiteLockSpider|crawler|archiver|transcoder|spider|uptime|validator|fetcher|MJ12bot|Ezooms|AhrefsBot|FHscan|Acunetix|Zyborg|ZmEu|Zeus|Xenu|Xaldon|WWW-Collector-E|WWWOFFLE|WISENutbot|Widow|Whacker|WebZIP|WebWhacker|WebStripper|Webster|Website\ Quester|Website\ eXtractor|WebSauger|WebReaper|WebmasterWorldForumBot|WebLeacher|Web.Image.Collector|WebGo\ IS|WebFetch|WebEnhancer|WebEMailExtrac|WebCopier|Webclipping.com|WebBandit|WebAuto|Web\ Sucker|Web\ Image\ Collector|VoidEYE|VCI|Vacuum|URLy.Warning|TurnitinBot|turingos|True_Robot|Titan|TightTwatBot|TheNomad|The.Intraformant|TurnitinBot/1.5|Telesoft|Teleport|tAkeOut|Szukacz/1.4|suzuran|Surfbot|SuperHTTP|SuperBot|Sucker|Stripper|Sqworm|spanner|SpankBot|SpaceBison|Snoopy|Snapbot|Snake|SmartDownload|SlySearch|SiteSnagger|Siphon|RMA|RepoMonkey|ReGet|Recorder|Reaper|RealDownload|QueryN.Metasearch|Pump|psbot|ProWebWalker|ProPowerBot/2.14|Pockey|PHP\ version\ tracker|pcBrowser|pavuk|Papa\ Foto|PageGrabber|OutfoxBot|Openfind|Offline\ Navigator|Offline\ Explorer|Octopus|NPbot|Ninja|NimbleCrawler|niki-bot|NICErsPRO|NG|NextGenSearchBot|NetZIP|Net\ Vampire|NetSpider|NetMechanic|Netcraft|NetAnts|NearSite|Navroad|NAMEPROTECT|Mozilla.*NEWT|Mozilla/3.Mozilla/2.01|moget|Mister\ PiX|Missigua\ Locator|Mirror|MIIxpc|MIDown\ tool|Microsoft\ URL\ Control|Microsoft.URL|Memo|Mata.Hari|Mass\ Downloader|MarkWatch|Mag-Net|Magnet|LWP::Simple|lwp-trivial|LinkWalker|LNSpiderguy|LinkScan/8.1a.Unix|LinkextractorPro|likse|libWeb/clsHTTP|lftp|LexiBot|larbin|Keyword.Density|Kenjin.Spider|Jyxobot|JustView|JOC|JetCar|JennyBot|Jakarta|Iria|Internet\ Ninja|InterGET|Intelliseek|InfoTekies|InfoNaviRobot|Indy\ Library|Image\ Sucker|Image\ Stripper|IlseBot|humanlinks|HTTrack|HMView|hloader|Harvest|Grafula|GrabNet|gotit|Go-Ahead-Got-It|FrontPage|flunky|Foobot|EyeNetIE|Extractor|Express\ WebPictures|Exabot|EroCrawler|EmailWolf|EmailSiphon|EmailCollector|EirGrabber|ebingbong|EasyDL|eCatch|Drip|dragonfly|Download\ Wonder|Download\ Devil|Download\ Demon|DittoSpyder|DIIbot|DISCo|AIBOT|Aboundex|Custo|Crescent|cosmos|CopyRightCheck|Copier|Collector|ChinaClaw|CherryPicker|CheeseBot|Cegbfeieh|BunnySlippers|Bullseye|BuiltBotTough|Buddy|BotALot|BlowFish|BlackWidow|Black.Hole|Bigfoot|BatchFTP|Bandit|BackWeb|BackDoorBot|80legs|360Spider|Java|Cogentbot|Alexibot|asterias|attach|eStyle|WebCrawler|Dumbot|CrocCrawler|ASPSeek|AcoiRobot|DuckDuckBot|BLEXBot|Ips Agent|bot|crawl|slurp|spider|outbrain|008|192.comAgent|2ip\.ru|404checker|^bluefish |^FDM |^git|^Goose|^HTTPClient|^Java|^Jetty|^Mget|^Microsoft URL Control|^NG\/[0-9\.]|^NING|^PHP\/[0-9]|^RMA|^Ruby|Ruby\/[0-9]|^scrutiny|^VSE\/[0-9]|^WordPress\.com|^XRL\/[0-9]|a3logics\.in|A6-Indexer|a\.pr-cy\.ru|Aboundex|aboutthedomain|Accoona|acoon|acrylicapps\.com\/pulp|adbeat|AddThis|ADmantX|adressendeutschland|Advanced Email Extractor v|agentslug|AHC|aihit|aiohttp|Airmail|akula|alertra|alexa site audit|Alibaba\.Security\.Heimdall|alyze\.info|amagit|AndroidDownloadManager|Anemone|Ant\.com|Anturis Agent|AnyEvent-HTTP|Apache-HttpClient|AportWorm\/[0-9]|AppEngine-Google|Arachmo|arachnode|Arachnophilia|archive-com|aria2|asafaweb.com|AskQuickly|Astute|asynchttp|autocite|Autonomy|B-l-i-t-z-B-O-T|Backlink-Ceck\.de|Bad-Neighborhood|baidu\.com|baypup\/[0-9]|baypup\/colbert|BazQux|BCKLINKS|BDFetch|BegunAdvertising|bibnum\.bnf|BigBozz|biglotron|BingLocalSearch|BingPreview|binlar|biz_Directory|Blackboard Safeassign|Bloglovin|BlogPulseLive|BlogSearch|Blogtrottr|boitho\.com-dc|BPImageWalker|Braintree-Webhooks|Branch Metrics API|Branch-Passthrough|Browsershots|BUbiNG|Butterfly|BuzzSumo|CakePHP|CapsuleChecker|CaretNail|cb crawl|CC Metadata Scaper|Cerberian Drtrs|CERT\.at-Statistics-Survey|cg-eye|changedetection|Charlotte|CheckHost|chkme\.com|CirrusExplorer|CISPA Vulnerability Notification|CJNetworkQuality|clips\.ua\.ac\.be|Cloud mapping experiment|CloudFlare-AlwaysOnline|Cloudinary\/[0-9]|cmcm\.com|coccoc|CommaFeed|Commons-HttpClient|Comodo SSL Checker|contactbigdatafr|convera|copyright sheriff|cosmos\/[0-9]|Covario-IDS|CrawlForMe\/[0-9]|cron-job\.org|Crowsnest|curb|Curious George|curl|cuwhois\/[0-9]|CyberPatrol|cybo\.com|DareBoost|DataparkSearch|dataprovider|Daum(oa)?[ \/][0-9]|DeuSu|developers\.google\.com\/\+\/web\/snippet|Digg|Dispatch|dlvr|DNS-Tools Header-Analyzer|DNSPod-reporting|docoloc|DomainAppender|dotSemantic|downforeveryoneorjustme|downnotifier\.com|DowntimeDetector|Dragonfly File Reader|drupact|Drupal (\+http:\/\/drupal\.org\/)|dubaiindex|EARTHCOM|Easy-Thumb|ec2linkfinder|eCairn-Grabber|ECCP|ElectricMonk|elefent|EMail Exractor|EmailWolf|Embed PHP Library|Embedly|europarchive\.org|evc-batch\/[0-9]|EventMachine HttpClient|Evidon|Evrinid|ExactSearch|ExaleadCloudview|Excel|Exploratodo|ezooms|facebookexternalhit|facebookplatform|fairshare|Faraday v|Faveeo|Favicon downloader|FavOrg|Feed Wrangler|Feedbin|FeedBooster|FeedBucket|FeedBurner|FeedChecker|Feedly|Feedspot|feeltiptop|Fetch API|Fetch\/[0-9]|Fever\/[0-9]|findlink|findthatfile|Flamingo_SearchEngine|FlipboardBrowserProxy|FlipboardProxy|FlipboardRSS|fluffy|flynxapp|forensiq|FoundSeoTool\/[0-9]|free thumbnails|FreeWebMonitoring SiteChecker|Funnelback|g00g1e\.net|GAChecker|geek-tools|Genderanalyzer|Genieo|GentleSource|GetLinkInfo|getprismatic\.com|GetURLInfo\/[0-9]|GigablastOpenSource|Go [\d\.]* package http|Go-http-client|GomezAgent|gooblog|Goodzer\/[0-9]|Google favicon|Google Keyword Suggestion|Google Keyword Tool|Google Page Speed Insights|Google PP Default|Google Search Console|Google Web Preview|Google-Adwords|Google-Apps-Script|Google-Calendar-Importer|Google-HTTP-Java-Client|Google-Publisher-Plugin|Google-SearchByImage|Google-Site-Verification|Google-Structured-Data-Testing-Tool|google_partner_monitoring|GoogleDocs|GoogleHC|GoogleProducer|GoScraper|GoSpotCheck|GoSquared-Status-Checker|gosquared-thumbnailer|GotSiteMonitor|Grammarly|grouphigh|grub-client|GTmetrix|gvfs|HAA(A)?RTLAND http client|Hatena|hawkReader|HEADMasterSEO|HeartRails_Capture|heritrix|hledejLevne\.cz\/[0-9]|Holmes|HootSuite Image proxy|Hootsuite-WebFeed\/[0-9]|HostTracker|ht:\/\/check|htdig|HTMLParser|HTTP-Header-Abfrage|http-kit|HTTP-Tiny|HTTP_Compression_Test|http_request2|http_requester|HttpComponents|httphr|HTTPMon|httpscheck|httpssites_power|httpunit|HttpUrlConnection|httrack|hosterstats|huaweisymantec|HubPages.*crawlingpolicy|HubSpot Connect|HubSpot Marketing Grader|HyperZbozi.cz Feeder|ichiro|IdeelaborPlagiaat|IDG Twitter Links Resolver|IDwhois\/[0-9]|Iframely|igdeSpyder|IlTrovatore|ImageEngine|Imagga|InAGist|inbound\.li parser|InDesign|infegy|infohelfer|InfoWizards Reciprocal Link System PRO|inpwrd\.com|Integrity|integromedb|internet_archive|InternetSeer|internetVista monitor|IODC|IOI|ips-agent|iqdb|Irokez|isitup\.org|iskanie|iZSearch|janforman|Jigsaw|Jobboerse|jobo|Jobrapido|KeepRight OpenStreetMap Checker|KickFire|KimonoLabs|knows\.is|kouio|KrOWLer|kulturarw3|KumKie|L\.webis|Larbin|LayeredExtractor|LibVLC|libwww|Liferea|link checker|Link Valet|link_thumbnailer|linkCheck|linkdex|LinkExaminer|linkfluence|linkpeek|LinkTiger|LinkWalker|Lipperhey|livedoor ScreenShot|LoadImpactPageAnalyzer|LoadImpactRload|LongURL API|looksystems\.net|ltx71|lwp-trivial|lycos|LYT\.SR|mabontland|MagpieRSS|Mail.Ru|MailChimp\.com|Mandrill|marketinggrader|Mediapartners-Google|MegaIndex\.ru|Melvil Rawi|MergeFlow-PageReader|MetaInspector|Metaspinner|MetaURI|Microsearch|Microsoft Office |Microsoft Windows Network Diagnostics|Mindjet|Miniflux|Mnogosearch|mogimogi|Mojolicious (Perl)|monitis|Monitority\/[0-9]|montastic|MonTools|Moreover|Morning Paper|mowser|Mrcgiguy|mShots|MVAClient|nagios|Najdi\.si|NETCRAFT|NetLyzer FastProbe|netresearch|NetShelter ContentScan|NetTrack|Netvibes|Neustar WPM|NeutrinoAPI|NewsBlur .*Finder|NewsGator|newsme|newspaper|NG-Search|nineconnections\.com|NLNZ_IAHarvester|Nmap Scripting Engine|node-superagent|node\.io|nominet\.org\.uk|Norton-Safeweb|Notifixious|notifyninja|nuhk|nutch|Nuzzel|nWormFeedFinder|Nymesis|Ocelli\/[0-9]|oegp|okhttp|Omea Reader|omgili|Online Domain Tools|OpenCalaisSemanticProxy|Openstat|OpenVAS|Optimizer|Orbiter|OrgProbe\/[0-9]|ow\.ly|ownCloud News|Page Analyzer|Page Valet|page2rss|page_verifier|PagePeeker|Pagespeed\/[0-9]|Panopta|panscient|parsijoo|PayPal IPN|Pcore-HTTP|Pearltrees|peerindex|Peew|PhantomJS|Photon|phpcrawl|phpservermon|Pi-Monster|Pingdom\.com|Pingoscope|PingSpot|Pinterest|Pizilla|Ploetz \+ Zeller|Plukkie|PocketParser|Pompos|Porkbun|Port Monitor|postano|PostPost|postrank|PowerPoint|Priceonomics Analysis Engine|Prlog|probethenet|Project 25499|Promotion_Tools_www.searchenginepromotionhelp.com|prospectb2b|Protopage|proximic|PTST |PTST\/[0-9]+|Pulsepoint XT3 web scraper|Python-httplib2|python-requests|Python-urllib|Qirina Hurdler|Qseero|Qualidator.com SiteAnalyzer|Quora Link Preview|Qwantify|Radian6|RankSonicSiteAuditor|Readability|RealPlayer%20Downloader|RebelMouse|redback|Redirect Checker Tool|ReederForMac|request\.js|ResponseCodeTest\/[0-9]|RestSharp|RetrevoPageAnalyzer|Riddler|Rival IQ|Robosourcer|Robozilla\/[0-9]|ROI Hunter|SalesIntelligent|SauceNAO|SBIder|Scoop|scooter|ScoutJet|ScoutURLMonitor|Scrapy|Scrubby|SearchSight|semanticdiscovery|semanticjuice|SEO Browser|Seo Servis|seo-nastroj.cz|Seobility|SEOCentro|SeoCheck|SeopultContentAnalyzer|SEOstats|Server Density Service Monitoring|servernfo\.com|Seznam screenshot-generator|Shelob|Shoppimon Analyzer|ShoppimonAgent\/[0-9]|ShopWiki|ShortLinkTranslate|shrinktheweb|SilverReader|SimplePie|SimplyFast|Site-Shot|Site24x7|SiteBar|SiteCondor|siteexplorer\.info|SiteGuardian|Siteimprove\.com|Sitemap(s)? Generator|Siteshooter B0t|SiteTruth|sitexy\.com|SkypeUriPreview|slider\.com|slurp|SMRF URL Expander|SMUrlExpander|Snappy|SniffRSS|sniptracker|Snoopy|sogou|SortSite|spaziodati|Specificfeeds|speedy|SPEng|Spinn3r|spray-can|Sprinklr |spyonweb|Sqworm|SSL Labs|Rambler|Statastico|StatusCake|Stratagems Kumo|Stroke.cz|StudioFACA|suchen|summify|Super Monitoring|Surphace Scout|SwiteScraper|Symfony2 BrowserKit|SynHttpClient-Built|Sysomos|T0PHackTeam|Tarantula|teoma|terrainformatica\.com|The Expert HTML Source Viewer|theinternetrules|theoldreader\.com|Thumbshots|ThumbSniper|TinEye|Tiny Tiny RSS|topster|touche.com|Traackr.com|truwoGPS|tweetedtimes\.com|Tweetminster|Twikle|Twingly|Typhoeus|ubermetrics-technologies|uclassify|UdmSearch|UnwindFetchor|updated|Upflow|URLChecker|URLitor.com|urlresolver|Urlstat|UrlTrends Ranking Updater|Vagabondo|via ggpht\.com GoogleImageProxy|visionutils|vkShare|voltron|Vortex\/[0-9]|voyager|VSAgent\/[0-9]|VSB-TUO\/[0-9]|VYU2|w3af\.org|W3C-checklink|W3C-mobileOK|W3C_I18n-Checker|W3C_Unicorn|wangling|Wappalyzer|WatchMouse|WbSrch|web-capture\.net|Web-Monitoring|Web-sniffer|Webauskunft|WebCapture|webcollage|WebCookies|WebCorp|WebDoc|WebFetch|WebImages|WebIndex|webkit2png|webmastercoffee|webmon |webscreenie|Webshot|Website Analyzer|websitepulse[+ ]checker|Websnapr|Websquash\.com|Webthumb\/[0-9]|WebThumbnail|WeCrawlForThePeace|WeLikeLinks|WEPA|WeSEE|wf84|wget|WhatsApp|WhatsMyIP|WhatWeb|Whibse|Whynder Magnet|Windows-RSS-Platform|WinHttpRequest|wkhtmlto|wmtips|Woko|WomlpeFactory|Word|WordPress|wotbox|WP Engine Install Performance API|WPScan|wscheck|WWW-Mechanize|www\.monitor\.us|XaxisSemanticsClassifier|Xenu Link Sleuth|XING-contenttabreceiver\/[0-9]|XmlSitemapGenerator|xpymep([0-9]?)\.exe|Y!J-(ASR|BSC)|Yaanb|yacy|Yahoo Ad monitoring|Yahoo Link Preview|YahooCacheSystem|YahooSeeker|YahooYSMcm|YandeG|yandex|yanga|yeti|Yo-yo|Yoleo Consumer|yoogliFetchAgent|YottaaMonitor|yourls\.org|Zao|Zemanta Aggregator|Zend\\\\Http\\\\Client|Zend_Http_Client|zgrab|ZnajdzFoto|ZyBorg#i', $user_agent, $badbot);
            if($goodbot || $badbot)
            {
                $bot = true;
            }
            preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
            preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($user_agent,0,4), $matches2);
            if($matches || $matches2)
            {
                $mobile = true;
            }
            preg_match('/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle|NRD90M|SGP771|SHIELD|SM-T550|KFTHWI|LG-V410|nexus/i', $user_agent, $matches3);
            if($matches3)
            {
                $tablet = true;
            }
            if($device === 'Bot')
            {
                if($bot === true)
                {
                    return array();
                }
            }
            if($device === 'Mobile')
            {
                if($mobile === true)
                {
                    return array();
                }
            }
            if($device === 'Tablet')
            {
                if($tablet === true)
                {
                    return array();
                }
            }
            if($device === 'Desktop')
            {
                if($tablet === false && $mobile === false && $bot === false)
                {
                    return array();
                }
            }
        }
    }
    if (isset($silencer_Main_Settings['hide_authors']) && !empty($silencer_Main_Settings['hide_authors']))
    {
        $id = get_the_author_meta( 'ID' );
        if($id != '')
        {
            if(in_array($id, $silencer_Main_Settings['hide_authors']))
            {
                return array();
            }
        }
    }
    if (isset($silencer_Main_Settings['hide_login']) && !empty($silencer_Main_Settings['hide_login']))
    {
        $id = get_current_user_id();
        if($id != 0)
        {
            if(in_array($id, $silencer_Main_Settings['hide_login']))
            {
                return array();
            }
        }
    }
    if (isset($silencer_Main_Settings['hide_country']) && $silencer_Main_Settings['hide_country'] != '')
    {
        $country = $silencer_Main_Settings['hide_country'];
        if($country === 'ALL')
        {
            return array();
        }
        elseif($country !== 'NONE')
        {
            if (isset($_SERVER['HTTP_CLIENT_IP'])) {
                $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
            } else {
                if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                    $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                } else {
                    $real_ip_adress = $_SERVER['REMOTE_ADDR'];
                }
            }
            error_log($real_ip_adress);
            if($real_ip_adress != '::1')
            {
                $country_code = silencer_ip_info($real_ip_adress, "Country Code");
                if($country_code != NULL)
                {
                    error_log($country_code);
                    if(strcasecmp($country, $country_code) == 0)
                    {
                        return array();
                    }
                }
            }
        }
    }
    if (isset($silencer_Main_Settings['hide_language']) && $silencer_Main_Settings['hide_language'] != '')
    {
        $language = $silencer_Main_Settings['hide_language'];
        if($language == 'ALL')
        {
            return array();
        }
        elseif($language != 'NONE')          
        {
            $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
            if(strcasecmp($language, $lang) == 0)
            {
                return array();
            }
        }
    }
    $silencer_stored_meta = get_post_meta( $post_id );
    if ( isset ( $silencer_stored_meta["hide_comments"]) && $silencer_stored_meta["hide_comments"][0] == "on" ) 
    {
        return array();
    }
    return $comments;
}
function silencer_get_the_user_ip() {

    if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) 
    {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) 
    {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else 
    {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return apply_filters( 'wpb_get_ip', $ip );
}
function silencer_isSecure() {
  return
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || $_SERVER['SERVER_PORT'] == 443;
}
function silencer_comment_status($open, $post_id) {
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
	$post = get_post( $post_id );
    if(isset($silencer_Main_Settings['enabled_types']))
    {
        if(in_array($post->post_type, $silencer_Main_Settings['enabled_types']))
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_users']))
    {
        if($silencer_Main_Settings['comment_users'] == 'notloggedin' && !is_user_logged_in())
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_users']))
    {
        if($silencer_Main_Settings['comment_users'] == 'loggedin' && is_user_logged_in())
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_users']))
    {
        if($silencer_Main_Settings['comment_users'] == 'notadmin' && !current_user_can('administrator'))
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_users']))
    {
        if($silencer_Main_Settings['comment_users'] == 'admin' && current_user_can('administrator'))
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_cats']) && ! empty( $silencer_Main_Settings['comment_cats'] ))
    {
        $match = 0;
        $categories = get_the_category();
        if ( ! empty( $categories ) ) {
            foreach( $categories as $category ) {
                foreach ($silencer_Main_Settings['comment_cats'] as $cat) {
                    if($category->term_id == $cat)
                    {
                        $match = 1;
                    }
                }
            }
        }
        if($match == 1)
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_url']) && $silencer_Main_Settings['comment_url'] != '')
    {
        if (isset($silencer_Main_Settings['comment_url_wildcard']) && $silencer_Main_Settings['comment_url_wildcard'] == 'on')
        {
            $wildcard = '1';
        }
        else
        {
            $wildcard = '0';
        }
        $storedrequests = $silencer_Main_Settings['comment_url'];
        $storedrequests = explode(",", $storedrequests);
        foreach($storedrequests as $storedrequest)
        {
            $actual_link = 'http' . ((silencer_isSecure()) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
            $short_url = str_ireplace(get_home_url(),'',$actual_link);
            if ($wildcard === '1') {
                if (fnmatch($storedrequest, $short_url)) {
                    if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                    {
                        add_action('template_redirect', 'silencer_override_comment_template');
                    }
                    return false;
                }
            }
            else
            {
                if(rtrim($short_url,'/') === rtrim($storedrequest,'/'))
                {
                    if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                    {
                        add_action('template_redirect', 'silencer_override_comment_template');
                    }
                    return false;
                }
            }
        }
    }
    if (isset($silencer_Main_Settings['comment_tags']) && $silencer_Main_Settings['comment_tags'] != '')
    {
        $match = 0;
        $id = get_the_ID();
        if($id !== false)
        {
            $tags = wp_get_post_tags($id);
            if(!empty($tags))
            {
                foreach( $tags as $tag_id ) 
                {
                    $tag = get_tag($tag_id);
                    $def_tags = explode(',',$silencer_Main_Settings['comment_tags']);
                    foreach ($def_tags as $def_tag) 
                    {
                        if(trim($def_tag) == $tag->name)
                        {
                            $match = 1;
                        }
                    }
                }                
            }
        }
        if($match == 1)
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_refs']) && $silencer_Main_Settings['comment_refs'] != '')
    {
        $match = 0;
        if(isset($_SERVER['HTTP_REFERER'])) 
        {
            $referrer = $_SERVER['HTTP_REFERER'];
        }
        else
        {
            $referrer = '';
        }
        $def_refs = explode(',', $silencer_Main_Settings['comment_refs']);
        foreach ($def_refs as $def_ref) 
        {
            if(trim($def_ref) == $referrer)
            {
                $match = 1;
            }
        }
        if($match == 1)
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
    }
    if (isset($silencer_Main_Settings['comment_ips']) && $silencer_Main_Settings['comment_ips'] != '')
    {
        $ips = explode(",", $silencer_Main_Settings['comment_ips']);
        $userIp = silencer_get_the_user_ip();
        foreach($ips as $ip)
        {
            if($userIp == trim($ip))
            {
                if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['comment_browsers']) && $silencer_Main_Settings['comment_browsers'] != '' && $silencer_Main_Settings['comment_browsers'] != 'NONE')
    {
        if ($silencer_Main_Settings['comment_browsers'] == 'ALL')
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $browserName = $silencer_Main_Settings['comment_browsers'];
        $bd = new silencerBrowserDetection();
            $browser =  $bd->silencer_detect()->silencer_getBrowser();
            if(stripos($browser, 'explorer') !== false) {
	    		$browser = 'IE';
	    	} 
	    	elseif(stripos($browser, 'chrome') !== false) {
                if( stripos($user_agent,'edge/') !== false ) 
                {
                    $aresult = explode('/', stristr($user_agent, 'edge'));
                    if (isset($aresult[1])) 
                    {
                        $browser = 'Edge';
                    }
                    else
                    {
                        $browser = 'Chrome';
                    }
                }
                else
                {
                    $browser = 'Chrome';
                }
	    	}
            elseif(stripos($browser, 'edge') !== false) {
				$browser = 'Edge';
	    	} 
	    	elseif(stripos($browser, 'safari') !== false) {
				$browser = 'Safari';
			} 
			elseif(stripos($browser, 'opera') !== false) {
				$browser = 'Opera';
			} 
			elseif(stripos($browser, 'firefox') !== false) {
				$browser = 'Firefox';
			}
            else
            {
                $browser = 'Other';
            }
            if($browserName === $browser)
            {
                if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
            }
    }
    if (isset($silencer_Main_Settings['comment_oses']) && $silencer_Main_Settings['comment_oses'] != '' && $silencer_Main_Settings['comment_oses'] != 'NONE')
                {
                    if ($silencer_Main_Settings['comment_oses'] == 'ALL')
                    {
                        if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                        {
                            add_action('template_redirect', 'silencer_override_comment_template');
                        }
                        return false;
                    }
                    $os = $silencer_Main_Settings['comment_oses'];
                    $userOs = silencer_getOS();
                    if($os === "All Windows")
                    {
                        if (stripos($userOs, 'Windows') !== false) 
                        {
                            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
                        }
                    }
                    elseif($os === "All Apple")
                    {
                        if($userOs === "iOs" || $userOs === "iPhone" || $userOs === "iPod" || $userOs === "iPad")
                        {
                            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
                        }
                    }
                    elseif($os === "All Mac")
                    {
                        if($userOs === "Mac OS X" || $userOs === "Mac OS 9")
                        {
                            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
                        }
                    }
                    elseif($os === "All Linux")
                    {
                        if($userOs === "Linux" && $userOs === "Ubuntu")
                        {
                            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
                        }
                    }
                    else
                    {
                        if($os === $userOs)
                        {
                            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
                        }
                    }
                }
    if (isset($silencer_Main_Settings['comment_devices']) && $silencer_Main_Settings['comment_devices'] != '')
    {
        $device = $silencer_Main_Settings['comment_devices'];
        if($device == 'ALL')
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
        elseif($device != 'NONE')
        {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
            $mobile = false;
            $tablet = false;
            $bot = false;
            preg_match( '/Altavista|ia_archiver|facebookexternalhit|googlebot|adsbot|Yahoo!|Baiduspider|Yandex|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/i', $user_agent, $goodbot);
            preg_match( '#bot|SiteLockSpider|crawler|archiver|transcoder|spider|uptime|validator|fetcher|MJ12bot|Ezooms|AhrefsBot|FHscan|Acunetix|Zyborg|ZmEu|Zeus|Xenu|Xaldon|WWW-Collector-E|WWWOFFLE|WISENutbot|Widow|Whacker|WebZIP|WebWhacker|WebStripper|Webster|Website\ Quester|Website\ eXtractor|WebSauger|WebReaper|WebmasterWorldForumBot|WebLeacher|Web.Image.Collector|WebGo\ IS|WebFetch|WebEnhancer|WebEMailExtrac|WebCopier|Webclipping.com|WebBandit|WebAuto|Web\ Sucker|Web\ Image\ Collector|VoidEYE|VCI|Vacuum|URLy.Warning|TurnitinBot|turingos|True_Robot|Titan|TightTwatBot|TheNomad|The.Intraformant|TurnitinBot/1.5|Telesoft|Teleport|tAkeOut|Szukacz/1.4|suzuran|Surfbot|SuperHTTP|SuperBot|Sucker|Stripper|Sqworm|spanner|SpankBot|SpaceBison|Snoopy|Snapbot|Snake|SmartDownload|SlySearch|SiteSnagger|Siphon|RMA|RepoMonkey|ReGet|Recorder|Reaper|RealDownload|QueryN.Metasearch|Pump|psbot|ProWebWalker|ProPowerBot/2.14|Pockey|PHP\ version\ tracker|pcBrowser|pavuk|Papa\ Foto|PageGrabber|OutfoxBot|Openfind|Offline\ Navigator|Offline\ Explorer|Octopus|NPbot|Ninja|NimbleCrawler|niki-bot|NICErsPRO|NG|NextGenSearchBot|NetZIP|Net\ Vampire|NetSpider|NetMechanic|Netcraft|NetAnts|NearSite|Navroad|NAMEPROTECT|Mozilla.*NEWT|Mozilla/3.Mozilla/2.01|moget|Mister\ PiX|Missigua\ Locator|Mirror|MIIxpc|MIDown\ tool|Microsoft\ URL\ Control|Microsoft.URL|Memo|Mata.Hari|Mass\ Downloader|MarkWatch|Mag-Net|Magnet|LWP::Simple|lwp-trivial|LinkWalker|LNSpiderguy|LinkScan/8.1a.Unix|LinkextractorPro|likse|libWeb/clsHTTP|lftp|LexiBot|larbin|Keyword.Density|Kenjin.Spider|Jyxobot|JustView|JOC|JetCar|JennyBot|Jakarta|Iria|Internet\ Ninja|InterGET|Intelliseek|InfoTekies|InfoNaviRobot|Indy\ Library|Image\ Sucker|Image\ Stripper|IlseBot|humanlinks|HTTrack|HMView|hloader|Harvest|Grafula|GrabNet|gotit|Go-Ahead-Got-It|FrontPage|flunky|Foobot|EyeNetIE|Extractor|Express\ WebPictures|Exabot|EroCrawler|EmailWolf|EmailSiphon|EmailCollector|EirGrabber|ebingbong|EasyDL|eCatch|Drip|dragonfly|Download\ Wonder|Download\ Devil|Download\ Demon|DittoSpyder|DIIbot|DISCo|AIBOT|Aboundex|Custo|Crescent|cosmos|CopyRightCheck|Copier|Collector|ChinaClaw|CherryPicker|CheeseBot|Cegbfeieh|BunnySlippers|Bullseye|BuiltBotTough|Buddy|BotALot|BlowFish|BlackWidow|Black.Hole|Bigfoot|BatchFTP|Bandit|BackWeb|BackDoorBot|80legs|360Spider|Java|Cogentbot|Alexibot|asterias|attach|eStyle|WebCrawler|Dumbot|CrocCrawler|ASPSeek|AcoiRobot|DuckDuckBot|BLEXBot|Ips Agent|bot|crawl|slurp|spider|outbrain|008|192.comAgent|2ip\.ru|404checker|^bluefish |^FDM |^git|^Goose|^HTTPClient|^Java|^Jetty|^Mget|^Microsoft URL Control|^NG\/[0-9\.]|^NING|^PHP\/[0-9]|^RMA|^Ruby|Ruby\/[0-9]|^scrutiny|^VSE\/[0-9]|^WordPress\.com|^XRL\/[0-9]|a3logics\.in|A6-Indexer|a\.pr-cy\.ru|Aboundex|aboutthedomain|Accoona|acoon|acrylicapps\.com\/pulp|adbeat|AddThis|ADmantX|adressendeutschland|Advanced Email Extractor v|agentslug|AHC|aihit|aiohttp|Airmail|akula|alertra|alexa site audit|Alibaba\.Security\.Heimdall|alyze\.info|amagit|AndroidDownloadManager|Anemone|Ant\.com|Anturis Agent|AnyEvent-HTTP|Apache-HttpClient|AportWorm\/[0-9]|AppEngine-Google|Arachmo|arachnode|Arachnophilia|archive-com|aria2|asafaweb.com|AskQuickly|Astute|asynchttp|autocite|Autonomy|B-l-i-t-z-B-O-T|Backlink-Ceck\.de|Bad-Neighborhood|baidu\.com|baypup\/[0-9]|baypup\/colbert|BazQux|BCKLINKS|BDFetch|BegunAdvertising|bibnum\.bnf|BigBozz|biglotron|BingLocalSearch|BingPreview|binlar|biz_Directory|Blackboard Safeassign|Bloglovin|BlogPulseLive|BlogSearch|Blogtrottr|boitho\.com-dc|BPImageWalker|Braintree-Webhooks|Branch Metrics API|Branch-Passthrough|Browsershots|BUbiNG|Butterfly|BuzzSumo|CakePHP|CapsuleChecker|CaretNail|cb crawl|CC Metadata Scaper|Cerberian Drtrs|CERT\.at-Statistics-Survey|cg-eye|changedetection|Charlotte|CheckHost|chkme\.com|CirrusExplorer|CISPA Vulnerability Notification|CJNetworkQuality|clips\.ua\.ac\.be|Cloud mapping experiment|CloudFlare-AlwaysOnline|Cloudinary\/[0-9]|cmcm\.com|coccoc|CommaFeed|Commons-HttpClient|Comodo SSL Checker|contactbigdatafr|convera|copyright sheriff|cosmos\/[0-9]|Covario-IDS|CrawlForMe\/[0-9]|cron-job\.org|Crowsnest|curb|Curious George|curl|cuwhois\/[0-9]|CyberPatrol|cybo\.com|DareBoost|DataparkSearch|dataprovider|Daum(oa)?[ \/][0-9]|DeuSu|developers\.google\.com\/\+\/web\/snippet|Digg|Dispatch|dlvr|DNS-Tools Header-Analyzer|DNSPod-reporting|docoloc|DomainAppender|dotSemantic|downforeveryoneorjustme|downnotifier\.com|DowntimeDetector|Dragonfly File Reader|drupact|Drupal (\+http:\/\/drupal\.org\/)|dubaiindex|EARTHCOM|Easy-Thumb|ec2linkfinder|eCairn-Grabber|ECCP|ElectricMonk|elefent|EMail Exractor|EmailWolf|Embed PHP Library|Embedly|europarchive\.org|evc-batch\/[0-9]|EventMachine HttpClient|Evidon|Evrinid|ExactSearch|ExaleadCloudview|Excel|Exploratodo|ezooms|facebookexternalhit|facebookplatform|fairshare|Faraday v|Faveeo|Favicon downloader|FavOrg|Feed Wrangler|Feedbin|FeedBooster|FeedBucket|FeedBurner|FeedChecker|Feedly|Feedspot|feeltiptop|Fetch API|Fetch\/[0-9]|Fever\/[0-9]|findlink|findthatfile|Flamingo_SearchEngine|FlipboardBrowserProxy|FlipboardProxy|FlipboardRSS|fluffy|flynxapp|forensiq|FoundSeoTool\/[0-9]|free thumbnails|FreeWebMonitoring SiteChecker|Funnelback|g00g1e\.net|GAChecker|geek-tools|Genderanalyzer|Genieo|GentleSource|GetLinkInfo|getprismatic\.com|GetURLInfo\/[0-9]|GigablastOpenSource|Go [\d\.]* package http|Go-http-client|GomezAgent|gooblog|Goodzer\/[0-9]|Google favicon|Google Keyword Suggestion|Google Keyword Tool|Google Page Speed Insights|Google PP Default|Google Search Console|Google Web Preview|Google-Adwords|Google-Apps-Script|Google-Calendar-Importer|Google-HTTP-Java-Client|Google-Publisher-Plugin|Google-SearchByImage|Google-Site-Verification|Google-Structured-Data-Testing-Tool|google_partner_monitoring|GoogleDocs|GoogleHC|GoogleProducer|GoScraper|GoSpotCheck|GoSquared-Status-Checker|gosquared-thumbnailer|GotSiteMonitor|Grammarly|grouphigh|grub-client|GTmetrix|gvfs|HAA(A)?RTLAND http client|Hatena|hawkReader|HEADMasterSEO|HeartRails_Capture|heritrix|hledejLevne\.cz\/[0-9]|Holmes|HootSuite Image proxy|Hootsuite-WebFeed\/[0-9]|HostTracker|ht:\/\/check|htdig|HTMLParser|HTTP-Header-Abfrage|http-kit|HTTP-Tiny|HTTP_Compression_Test|http_request2|http_requester|HttpComponents|httphr|HTTPMon|httpscheck|httpssites_power|httpunit|HttpUrlConnection|httrack|hosterstats|huaweisymantec|HubPages.*crawlingpolicy|HubSpot Connect|HubSpot Marketing Grader|HyperZbozi.cz Feeder|ichiro|IdeelaborPlagiaat|IDG Twitter Links Resolver|IDwhois\/[0-9]|Iframely|igdeSpyder|IlTrovatore|ImageEngine|Imagga|InAGist|inbound\.li parser|InDesign|infegy|infohelfer|InfoWizards Reciprocal Link System PRO|inpwrd\.com|Integrity|integromedb|internet_archive|InternetSeer|internetVista monitor|IODC|IOI|ips-agent|iqdb|Irokez|isitup\.org|iskanie|iZSearch|janforman|Jigsaw|Jobboerse|jobo|Jobrapido|KeepRight OpenStreetMap Checker|KickFire|KimonoLabs|knows\.is|kouio|KrOWLer|kulturarw3|KumKie|L\.webis|Larbin|LayeredExtractor|LibVLC|libwww|Liferea|link checker|Link Valet|link_thumbnailer|linkCheck|linkdex|LinkExaminer|linkfluence|linkpeek|LinkTiger|LinkWalker|Lipperhey|livedoor ScreenShot|LoadImpactPageAnalyzer|LoadImpactRload|LongURL API|looksystems\.net|ltx71|lwp-trivial|lycos|LYT\.SR|mabontland|MagpieRSS|Mail.Ru|MailChimp\.com|Mandrill|marketinggrader|Mediapartners-Google|MegaIndex\.ru|Melvil Rawi|MergeFlow-PageReader|MetaInspector|Metaspinner|MetaURI|Microsearch|Microsoft Office |Microsoft Windows Network Diagnostics|Mindjet|Miniflux|Mnogosearch|mogimogi|Mojolicious (Perl)|monitis|Monitority\/[0-9]|montastic|MonTools|Moreover|Morning Paper|mowser|Mrcgiguy|mShots|MVAClient|nagios|Najdi\.si|NETCRAFT|NetLyzer FastProbe|netresearch|NetShelter ContentScan|NetTrack|Netvibes|Neustar WPM|NeutrinoAPI|NewsBlur .*Finder|NewsGator|newsme|newspaper|NG-Search|nineconnections\.com|NLNZ_IAHarvester|Nmap Scripting Engine|node-superagent|node\.io|nominet\.org\.uk|Norton-Safeweb|Notifixious|notifyninja|nuhk|nutch|Nuzzel|nWormFeedFinder|Nymesis|Ocelli\/[0-9]|oegp|okhttp|Omea Reader|omgili|Online Domain Tools|OpenCalaisSemanticProxy|Openstat|OpenVAS|Optimizer|Orbiter|OrgProbe\/[0-9]|ow\.ly|ownCloud News|Page Analyzer|Page Valet|page2rss|page_verifier|PagePeeker|Pagespeed\/[0-9]|Panopta|panscient|parsijoo|PayPal IPN|Pcore-HTTP|Pearltrees|peerindex|Peew|PhantomJS|Photon|phpcrawl|phpservermon|Pi-Monster|Pingdom\.com|Pingoscope|PingSpot|Pinterest|Pizilla|Ploetz \+ Zeller|Plukkie|PocketParser|Pompos|Porkbun|Port Monitor|postano|PostPost|postrank|PowerPoint|Priceonomics Analysis Engine|Prlog|probethenet|Project 25499|Promotion_Tools_www.searchenginepromotionhelp.com|prospectb2b|Protopage|proximic|PTST |PTST\/[0-9]+|Pulsepoint XT3 web scraper|Python-httplib2|python-requests|Python-urllib|Qirina Hurdler|Qseero|Qualidator.com SiteAnalyzer|Quora Link Preview|Qwantify|Radian6|RankSonicSiteAuditor|Readability|RealPlayer%20Downloader|RebelMouse|redback|Redirect Checker Tool|ReederForMac|request\.js|ResponseCodeTest\/[0-9]|RestSharp|RetrevoPageAnalyzer|Riddler|Rival IQ|Robosourcer|Robozilla\/[0-9]|ROI Hunter|SalesIntelligent|SauceNAO|SBIder|Scoop|scooter|ScoutJet|ScoutURLMonitor|Scrapy|Scrubby|SearchSight|semanticdiscovery|semanticjuice|SEO Browser|Seo Servis|seo-nastroj.cz|Seobility|SEOCentro|SeoCheck|SeopultContentAnalyzer|SEOstats|Server Density Service Monitoring|servernfo\.com|Seznam screenshot-generator|Shelob|Shoppimon Analyzer|ShoppimonAgent\/[0-9]|ShopWiki|ShortLinkTranslate|shrinktheweb|SilverReader|SimplePie|SimplyFast|Site-Shot|Site24x7|SiteBar|SiteCondor|siteexplorer\.info|SiteGuardian|Siteimprove\.com|Sitemap(s)? Generator|Siteshooter B0t|SiteTruth|sitexy\.com|SkypeUriPreview|slider\.com|slurp|SMRF URL Expander|SMUrlExpander|Snappy|SniffRSS|sniptracker|Snoopy|sogou|SortSite|spaziodati|Specificfeeds|speedy|SPEng|Spinn3r|spray-can|Sprinklr |spyonweb|Sqworm|SSL Labs|Rambler|Statastico|StatusCake|Stratagems Kumo|Stroke.cz|StudioFACA|suchen|summify|Super Monitoring|Surphace Scout|SwiteScraper|Symfony2 BrowserKit|SynHttpClient-Built|Sysomos|T0PHackTeam|Tarantula|teoma|terrainformatica\.com|The Expert HTML Source Viewer|theinternetrules|theoldreader\.com|Thumbshots|ThumbSniper|TinEye|Tiny Tiny RSS|topster|touche.com|Traackr.com|truwoGPS|tweetedtimes\.com|Tweetminster|Twikle|Twingly|Typhoeus|ubermetrics-technologies|uclassify|UdmSearch|UnwindFetchor|updated|Upflow|URLChecker|URLitor.com|urlresolver|Urlstat|UrlTrends Ranking Updater|Vagabondo|via ggpht\.com GoogleImageProxy|visionutils|vkShare|voltron|Vortex\/[0-9]|voyager|VSAgent\/[0-9]|VSB-TUO\/[0-9]|VYU2|w3af\.org|W3C-checklink|W3C-mobileOK|W3C_I18n-Checker|W3C_Unicorn|wangling|Wappalyzer|WatchMouse|WbSrch|web-capture\.net|Web-Monitoring|Web-sniffer|Webauskunft|WebCapture|webcollage|WebCookies|WebCorp|WebDoc|WebFetch|WebImages|WebIndex|webkit2png|webmastercoffee|webmon |webscreenie|Webshot|Website Analyzer|websitepulse[+ ]checker|Websnapr|Websquash\.com|Webthumb\/[0-9]|WebThumbnail|WeCrawlForThePeace|WeLikeLinks|WEPA|WeSEE|wf84|wget|WhatsApp|WhatsMyIP|WhatWeb|Whibse|Whynder Magnet|Windows-RSS-Platform|WinHttpRequest|wkhtmlto|wmtips|Woko|WomlpeFactory|Word|WordPress|wotbox|WP Engine Install Performance API|WPScan|wscheck|WWW-Mechanize|www\.monitor\.us|XaxisSemanticsClassifier|Xenu Link Sleuth|XING-contenttabreceiver\/[0-9]|XmlSitemapGenerator|xpymep([0-9]?)\.exe|Y!J-(ASR|BSC)|Yaanb|yacy|Yahoo Ad monitoring|Yahoo Link Preview|YahooCacheSystem|YahooSeeker|YahooYSMcm|YandeG|yandex|yanga|yeti|Yo-yo|Yoleo Consumer|yoogliFetchAgent|YottaaMonitor|yourls\.org|Zao|Zemanta Aggregator|Zend\\\\Http\\\\Client|Zend_Http_Client|zgrab|ZnajdzFoto|ZyBorg#i', $user_agent, $badbot);
            if($goodbot || $badbot)
            {
                $bot = true;
            }
            preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
            preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($user_agent,0,4), $matches2);
            if($matches || $matches2)
            {
                $mobile = true;
            }
            preg_match('/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle|NRD90M|SGP771|SHIELD|SM-T550|KFTHWI|LG-V410|nexus/i', $user_agent, $matches3);
            if($matches3)
            {
                $tablet = true;
            }
            if($device === 'Bot')
            {
                if($bot === true)
                {
                    if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                    {
                        add_action('template_redirect', 'silencer_override_comment_template');
                    }
                    return false;
                }
            }
            if($device === 'Mobile')
            {
                if($mobile === true)
                {
                    if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                    {
                        add_action('template_redirect', 'silencer_override_comment_template');
                    }
                    return false;
                }
            }
            if($device === 'Tablet')
            {
                if($tablet === true)
                {
                    if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                    {
                        add_action('template_redirect', 'silencer_override_comment_template');
                    }
                    return false;
                }
            }
            if($device === 'Desktop')
            {
                if($tablet === false && $mobile === false && $bot === false)
                {
                    if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                    {
                        add_action('template_redirect', 'silencer_override_comment_template');
                    }
                    return false;
                }
            }
        }
    }
    if (isset($silencer_Main_Settings['comment_authors']) && !empty($silencer_Main_Settings['comment_authors']))
    {
        $id = get_the_author_meta( 'ID' );
        if($id != '')
        {
            if(in_array($id, $silencer_Main_Settings['comment_authors']))
            {
                if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['comment_login']) && !empty($silencer_Main_Settings['comment_login']))
    {
        $id = get_current_user_id();
        if($id != 0)
        {
            if(in_array($id, $silencer_Main_Settings['comment_login']))
            {
                if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['comment_country']) && $silencer_Main_Settings['comment_country'] != '')
    {
        $country = $silencer_Main_Settings['comment_country'];
        if($country === 'ALL')
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
        elseif($country !== 'NONE')
        {
            if (isset($_SERVER['HTTP_CLIENT_IP'])) {
                $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
            } else {
                if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                    $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                } else {
                    $real_ip_adress = $_SERVER['REMOTE_ADDR'];
                }
            }
            $country_code = silencer_ip_info($real_ip_adress, "Country Code");
            if(strcasecmp($country, $country_code) == 0)
            {
                if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['comment_language']) && $silencer_Main_Settings['comment_language'] != '')
    {
        $language = $silencer_Main_Settings['comment_language'];
        if($language == 'ALL')
        {
            if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
            {
                add_action('template_redirect', 'silencer_override_comment_template');
            }
            return false;
        }
        elseif($language != 'NONE')          
        {
            $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
            if(strcasecmp($language, $lang) == 0)
            {
                if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
                {
                    add_action('template_redirect', 'silencer_override_comment_template');
                }
                return false;
            }
        }
    }
    $silencer_stored_meta = get_post_meta( $post_id );
    if ( isset ( $silencer_stored_meta["disable_comments"]) && $silencer_stored_meta["disable_comments"][0] == "on" ) 
    {
        if (isset($silencer_Main_Settings['force_comments_overwrite']) && $silencer_Main_Settings['force_comments_overwrite'] == 'on')
        {
            add_action('template_redirect', 'silencer_override_comment_template');
        }
        return false;
    }
    return $open;
}

function silencer_pingback_status($open, $post_id) {
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
	$post = get_post( $post_id );
    if(isset($silencer_Main_Settings['enabled_ping_types']))
    {
        if(in_array($post->post_type, $silencer_Main_Settings['enabled_ping_types']))
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_users']))
    {
        if($silencer_Main_Settings['pingback_users'] == 'notloggedin' && !is_user_logged_in())
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_users']))
    {
        if($silencer_Main_Settings['pingback_users'] == 'loggedin' && is_user_logged_in())
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_users']))
    {
        if($silencer_Main_Settings['pingback_users'] == 'notadmin' && !current_user_can('administrator'))
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_users']))
    {
        if($silencer_Main_Settings['pingback_users'] == 'admin' && current_user_can('administrator'))
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_cats']) && ! empty( $silencer_Main_Settings['pingback_cats'] ))
    {
        $match = 0;
        $categories = get_the_category();
        if ( ! empty( $categories ) ) {
            foreach( $categories as $category ) {
                foreach ($silencer_Main_Settings['pingback_cats'] as $cat) {
                    if($category->term_id == $cat)
                    {
                        $match = 1;
                    }
                }
            }
        }
        if($match == 1)
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_url']) && $silencer_Main_Settings['pingback_url'] != '')
    {
        if (isset($silencer_Main_Settings['pingback_url_wildcard']) && $silencer_Main_Settings['pingback_url_wildcard'] == 'on')
        {
            $wildcard = '1';
        }
        else
        {
            $wildcard = '0';
        }
        $storedrequests = $silencer_Main_Settings['pingback_url'];
        $storedrequests = explode(",", $storedrequests);
        foreach($storedrequests as $storedrequest)
        {
            $actual_link = 'http' . ((silencer_isSecure()) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
            $short_url = str_ireplace(get_home_url(),'',$actual_link);
            if ($wildcard === '1') {
                if (fnmatch($storedrequest, $short_url)) {
                    add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                    add_filter('pre_update_default_ping_status', '__return_false');
                    add_filter('pre_option_default_ping_status', '__return_zero');
                    add_filter('pre_update_default_pingback_flag', '__return_false');
                    add_filter('pre_option_default_pingback_flag', '__return_zero');
                    return false;
                }
            }
            else
            {
                if(rtrim($short_url,'/') === rtrim($storedrequest,'/'))
                {
                    add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                    add_filter('pre_update_default_ping_status', '__return_false');
                    add_filter('pre_option_default_ping_status', '__return_zero');
                    add_filter('pre_update_default_pingback_flag', '__return_false');
                    add_filter('pre_option_default_pingback_flag', '__return_zero');
                    return false;
                }
            }
        }
    }
    if (isset($silencer_Main_Settings['pingback_tags']) && $silencer_Main_Settings['pingback_tags'] != '')
    {
        $match = 0;
        $id = get_the_ID();
        if($id !== false)
        {
            $tags = wp_get_post_tags($id);
            if(!empty($tags))
            {
                foreach( $tags as $tag_id ) 
                {
                    $tag = get_tag($tag_id);
                    $def_tags = explode(',',$silencer_Main_Settings['pingback_tags']);
                    foreach ($def_tags as $def_tag) 
                    {
                        if(trim($def_tag) == $tag->name)
                        {
                            $match = 1;
                        }
                    }
                }                
            }
        }
        if($match == 1)
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_refs']) && $silencer_Main_Settings['pingback_refs'] != '')
    {
        $match = 0;
        if(isset($_SERVER['HTTP_REFERER'])) 
        {
            $referrer = $_SERVER['HTTP_REFERER'];
        }
        else
        {
            $referrer = '';
        }
        $def_refs = explode(',', $silencer_Main_Settings['pingback_refs']);
        foreach ($def_refs as $def_ref) 
        {
            if(trim($def_ref) == $referrer)
            {
                $match = 1;
            }
        }
        if($match == 1)
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
    }
    if (isset($silencer_Main_Settings['pingback_ips']) && $silencer_Main_Settings['pingback_ips'] != '')
    {
        $ips = explode(",", $silencer_Main_Settings['pingback_ips']);
        $userIp = silencer_get_the_user_ip();
        foreach($ips as $ip)
        {
            if($userIp == trim($ip))
            {
                add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['pingback_browsers']) && $silencer_Main_Settings['pingback_browsers'] != '' && $silencer_Main_Settings['pingback_browsers'] != 'NONE')
    {
        if ($silencer_Main_Settings['pingback_browsers'] == 'ALL')
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
        }
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $browserName = $silencer_Main_Settings['pingback_browsers'];
        $bd = new silencerBrowserDetection();
            $browser =  $bd->silencer_detect()->silencer_getBrowser();
            if(stripos($browser, 'explorer') !== false) {
	    		$browser = 'IE';
	    	} 
	    	elseif(stripos($browser, 'chrome') !== false) {
                if( stripos($user_agent,'edge/') !== false ) 
                {
                    $aresult = explode('/', stristr($user_agent, 'edge'));
                    if (isset($aresult[1])) 
                    {
                        $browser = 'Edge';
                    }
                    else
                    {
                        $browser = 'Chrome';
                    }
                }
                else
                {
                    $browser = 'Chrome';
                }
	    	}
            elseif(stripos($browser, 'edge') !== false) {
				$browser = 'Edge';
	    	} 
	    	elseif(stripos($browser, 'safari') !== false) {
				$browser = 'Safari';
			} 
			elseif(stripos($browser, 'opera') !== false) {
				$browser = 'Opera';
			} 
			elseif(stripos($browser, 'firefox') !== false) {
				$browser = 'Firefox';
			}
            else
            {
                $browser = 'Other';
            }
            if($browserName === $browser)
            {
                add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
            }
    }
    if (isset($silencer_Main_Settings['pingback_oses']) && $silencer_Main_Settings['pingback_oses'] != '' && $silencer_Main_Settings['pingback_oses'] != 'NONE')
                {
                    if ($silencer_Main_Settings['pingback_oses'] == 'ALL')
                    {
                        add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                    }
                    $os = $silencer_Main_Settings['pingback_oses'];
                    $userOs = silencer_getOS();
                    if($os === "All Windows")
                    {
                        if (stripos($userOs, 'Windows') !== false) 
                        {
                            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                        }
                    }
                    elseif($os === "All Apple")
                    {
                        if($userOs === "iOs" || $userOs === "iPhone" || $userOs === "iPod" || $userOs === "iPad")
                        {
                            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                        }
                    }
                    elseif($os === "All Mac")
                    {
                        if($userOs === "Mac OS X" || $userOs === "Mac OS 9")
                        {
                            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                        }
                    }
                    elseif($os === "All Linux")
                    {
                        if($userOs === "Linux" && $userOs === "Ubuntu")
                        {
                            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                        }
                    }
                    else
                    {
                        if($os === $userOs)
                        {
                            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                        }
                    }
                }
    if (isset($silencer_Main_Settings['pingback_devices']) && $silencer_Main_Settings['pingback_devices'] != '')
    {
        $device = $silencer_Main_Settings['pingback_devices'];
        if($device == 'ALL')
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
        }
        elseif($device != 'NONE')
        {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
            $mobile = false;
            $tablet = false;
            $bot = false;
            preg_match( '/Altavista|ia_archiver|facebookexternalhit|googlebot|adsbot|Yahoo!|Baiduspider|Yandex|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/i', $user_agent, $goodbot);
            preg_match( '#bot|SiteLockSpider|crawler|archiver|transcoder|spider|uptime|validator|fetcher|MJ12bot|Ezooms|AhrefsBot|FHscan|Acunetix|Zyborg|ZmEu|Zeus|Xenu|Xaldon|WWW-Collector-E|WWWOFFLE|WISENutbot|Widow|Whacker|WebZIP|WebWhacker|WebStripper|Webster|Website\ Quester|Website\ eXtractor|WebSauger|WebReaper|WebmasterWorldForumBot|WebLeacher|Web.Image.Collector|WebGo\ IS|WebFetch|WebEnhancer|WebEMailExtrac|WebCopier|Webclipping.com|WebBandit|WebAuto|Web\ Sucker|Web\ Image\ Collector|VoidEYE|VCI|Vacuum|URLy.Warning|TurnitinBot|turingos|True_Robot|Titan|TightTwatBot|TheNomad|The.Intraformant|TurnitinBot/1.5|Telesoft|Teleport|tAkeOut|Szukacz/1.4|suzuran|Surfbot|SuperHTTP|SuperBot|Sucker|Stripper|Sqworm|spanner|SpankBot|SpaceBison|Snoopy|Snapbot|Snake|SmartDownload|SlySearch|SiteSnagger|Siphon|RMA|RepoMonkey|ReGet|Recorder|Reaper|RealDownload|QueryN.Metasearch|Pump|psbot|ProWebWalker|ProPowerBot/2.14|Pockey|PHP\ version\ tracker|pcBrowser|pavuk|Papa\ Foto|PageGrabber|OutfoxBot|Openfind|Offline\ Navigator|Offline\ Explorer|Octopus|NPbot|Ninja|NimbleCrawler|niki-bot|NICErsPRO|NG|NextGenSearchBot|NetZIP|Net\ Vampire|NetSpider|NetMechanic|Netcraft|NetAnts|NearSite|Navroad|NAMEPROTECT|Mozilla.*NEWT|Mozilla/3.Mozilla/2.01|moget|Mister\ PiX|Missigua\ Locator|Mirror|MIIxpc|MIDown\ tool|Microsoft\ URL\ Control|Microsoft.URL|Memo|Mata.Hari|Mass\ Downloader|MarkWatch|Mag-Net|Magnet|LWP::Simple|lwp-trivial|LinkWalker|LNSpiderguy|LinkScan/8.1a.Unix|LinkextractorPro|likse|libWeb/clsHTTP|lftp|LexiBot|larbin|Keyword.Density|Kenjin.Spider|Jyxobot|JustView|JOC|JetCar|JennyBot|Jakarta|Iria|Internet\ Ninja|InterGET|Intelliseek|InfoTekies|InfoNaviRobot|Indy\ Library|Image\ Sucker|Image\ Stripper|IlseBot|humanlinks|HTTrack|HMView|hloader|Harvest|Grafula|GrabNet|gotit|Go-Ahead-Got-It|FrontPage|flunky|Foobot|EyeNetIE|Extractor|Express\ WebPictures|Exabot|EroCrawler|EmailWolf|EmailSiphon|EmailCollector|EirGrabber|ebingbong|EasyDL|eCatch|Drip|dragonfly|Download\ Wonder|Download\ Devil|Download\ Demon|DittoSpyder|DIIbot|DISCo|AIBOT|Aboundex|Custo|Crescent|cosmos|CopyRightCheck|Copier|Collector|ChinaClaw|CherryPicker|CheeseBot|Cegbfeieh|BunnySlippers|Bullseye|BuiltBotTough|Buddy|BotALot|BlowFish|BlackWidow|Black.Hole|Bigfoot|BatchFTP|Bandit|BackWeb|BackDoorBot|80legs|360Spider|Java|Cogentbot|Alexibot|asterias|attach|eStyle|WebCrawler|Dumbot|CrocCrawler|ASPSeek|AcoiRobot|DuckDuckBot|BLEXBot|Ips Agent|bot|crawl|slurp|spider|outbrain|008|192.comAgent|2ip\.ru|404checker|^bluefish |^FDM |^git|^Goose|^HTTPClient|^Java|^Jetty|^Mget|^Microsoft URL Control|^NG\/[0-9\.]|^NING|^PHP\/[0-9]|^RMA|^Ruby|Ruby\/[0-9]|^scrutiny|^VSE\/[0-9]|^WordPress\.com|^XRL\/[0-9]|a3logics\.in|A6-Indexer|a\.pr-cy\.ru|Aboundex|aboutthedomain|Accoona|acoon|acrylicapps\.com\/pulp|adbeat|AddThis|ADmantX|adressendeutschland|Advanced Email Extractor v|agentslug|AHC|aihit|aiohttp|Airmail|akula|alertra|alexa site audit|Alibaba\.Security\.Heimdall|alyze\.info|amagit|AndroidDownloadManager|Anemone|Ant\.com|Anturis Agent|AnyEvent-HTTP|Apache-HttpClient|AportWorm\/[0-9]|AppEngine-Google|Arachmo|arachnode|Arachnophilia|archive-com|aria2|asafaweb.com|AskQuickly|Astute|asynchttp|autocite|Autonomy|B-l-i-t-z-B-O-T|Backlink-Ceck\.de|Bad-Neighborhood|baidu\.com|baypup\/[0-9]|baypup\/colbert|BazQux|BCKLINKS|BDFetch|BegunAdvertising|bibnum\.bnf|BigBozz|biglotron|BingLocalSearch|BingPreview|binlar|biz_Directory|Blackboard Safeassign|Bloglovin|BlogPulseLive|BlogSearch|Blogtrottr|boitho\.com-dc|BPImageWalker|Braintree-Webhooks|Branch Metrics API|Branch-Passthrough|Browsershots|BUbiNG|Butterfly|BuzzSumo|CakePHP|CapsuleChecker|CaretNail|cb crawl|CC Metadata Scaper|Cerberian Drtrs|CERT\.at-Statistics-Survey|cg-eye|changedetection|Charlotte|CheckHost|chkme\.com|CirrusExplorer|CISPA Vulnerability Notification|CJNetworkQuality|clips\.ua\.ac\.be|Cloud mapping experiment|CloudFlare-AlwaysOnline|Cloudinary\/[0-9]|cmcm\.com|coccoc|CommaFeed|Commons-HttpClient|Comodo SSL Checker|contactbigdatafr|convera|copyright sheriff|cosmos\/[0-9]|Covario-IDS|CrawlForMe\/[0-9]|cron-job\.org|Crowsnest|curb|Curious George|curl|cuwhois\/[0-9]|CyberPatrol|cybo\.com|DareBoost|DataparkSearch|dataprovider|Daum(oa)?[ \/][0-9]|DeuSu|developers\.google\.com\/\+\/web\/snippet|Digg|Dispatch|dlvr|DNS-Tools Header-Analyzer|DNSPod-reporting|docoloc|DomainAppender|dotSemantic|downforeveryoneorjustme|downnotifier\.com|DowntimeDetector|Dragonfly File Reader|drupact|Drupal (\+http:\/\/drupal\.org\/)|dubaiindex|EARTHCOM|Easy-Thumb|ec2linkfinder|eCairn-Grabber|ECCP|ElectricMonk|elefent|EMail Exractor|EmailWolf|Embed PHP Library|Embedly|europarchive\.org|evc-batch\/[0-9]|EventMachine HttpClient|Evidon|Evrinid|ExactSearch|ExaleadCloudview|Excel|Exploratodo|ezooms|facebookexternalhit|facebookplatform|fairshare|Faraday v|Faveeo|Favicon downloader|FavOrg|Feed Wrangler|Feedbin|FeedBooster|FeedBucket|FeedBurner|FeedChecker|Feedly|Feedspot|feeltiptop|Fetch API|Fetch\/[0-9]|Fever\/[0-9]|findlink|findthatfile|Flamingo_SearchEngine|FlipboardBrowserProxy|FlipboardProxy|FlipboardRSS|fluffy|flynxapp|forensiq|FoundSeoTool\/[0-9]|free thumbnails|FreeWebMonitoring SiteChecker|Funnelback|g00g1e\.net|GAChecker|geek-tools|Genderanalyzer|Genieo|GentleSource|GetLinkInfo|getprismatic\.com|GetURLInfo\/[0-9]|GigablastOpenSource|Go [\d\.]* package http|Go-http-client|GomezAgent|gooblog|Goodzer\/[0-9]|Google favicon|Google Keyword Suggestion|Google Keyword Tool|Google Page Speed Insights|Google PP Default|Google Search Console|Google Web Preview|Google-Adwords|Google-Apps-Script|Google-Calendar-Importer|Google-HTTP-Java-Client|Google-Publisher-Plugin|Google-SearchByImage|Google-Site-Verification|Google-Structured-Data-Testing-Tool|google_partner_monitoring|GoogleDocs|GoogleHC|GoogleProducer|GoScraper|GoSpotCheck|GoSquared-Status-Checker|gosquared-thumbnailer|GotSiteMonitor|Grammarly|grouphigh|grub-client|GTmetrix|gvfs|HAA(A)?RTLAND http client|Hatena|hawkReader|HEADMasterSEO|HeartRails_Capture|heritrix|hledejLevne\.cz\/[0-9]|Holmes|HootSuite Image proxy|Hootsuite-WebFeed\/[0-9]|HostTracker|ht:\/\/check|htdig|HTMLParser|HTTP-Header-Abfrage|http-kit|HTTP-Tiny|HTTP_Compression_Test|http_request2|http_requester|HttpComponents|httphr|HTTPMon|httpscheck|httpssites_power|httpunit|HttpUrlConnection|httrack|hosterstats|huaweisymantec|HubPages.*crawlingpolicy|HubSpot Connect|HubSpot Marketing Grader|HyperZbozi.cz Feeder|ichiro|IdeelaborPlagiaat|IDG Twitter Links Resolver|IDwhois\/[0-9]|Iframely|igdeSpyder|IlTrovatore|ImageEngine|Imagga|InAGist|inbound\.li parser|InDesign|infegy|infohelfer|InfoWizards Reciprocal Link System PRO|inpwrd\.com|Integrity|integromedb|internet_archive|InternetSeer|internetVista monitor|IODC|IOI|ips-agent|iqdb|Irokez|isitup\.org|iskanie|iZSearch|janforman|Jigsaw|Jobboerse|jobo|Jobrapido|KeepRight OpenStreetMap Checker|KickFire|KimonoLabs|knows\.is|kouio|KrOWLer|kulturarw3|KumKie|L\.webis|Larbin|LayeredExtractor|LibVLC|libwww|Liferea|link checker|Link Valet|link_thumbnailer|linkCheck|linkdex|LinkExaminer|linkfluence|linkpeek|LinkTiger|LinkWalker|Lipperhey|livedoor ScreenShot|LoadImpactPageAnalyzer|LoadImpactRload|LongURL API|looksystems\.net|ltx71|lwp-trivial|lycos|LYT\.SR|mabontland|MagpieRSS|Mail.Ru|MailChimp\.com|Mandrill|marketinggrader|Mediapartners-Google|MegaIndex\.ru|Melvil Rawi|MergeFlow-PageReader|MetaInspector|Metaspinner|MetaURI|Microsearch|Microsoft Office |Microsoft Windows Network Diagnostics|Mindjet|Miniflux|Mnogosearch|mogimogi|Mojolicious (Perl)|monitis|Monitority\/[0-9]|montastic|MonTools|Moreover|Morning Paper|mowser|Mrcgiguy|mShots|MVAClient|nagios|Najdi\.si|NETCRAFT|NetLyzer FastProbe|netresearch|NetShelter ContentScan|NetTrack|Netvibes|Neustar WPM|NeutrinoAPI|NewsBlur .*Finder|NewsGator|newsme|newspaper|NG-Search|nineconnections\.com|NLNZ_IAHarvester|Nmap Scripting Engine|node-superagent|node\.io|nominet\.org\.uk|Norton-Safeweb|Notifixious|notifyninja|nuhk|nutch|Nuzzel|nWormFeedFinder|Nymesis|Ocelli\/[0-9]|oegp|okhttp|Omea Reader|omgili|Online Domain Tools|OpenCalaisSemanticProxy|Openstat|OpenVAS|Optimizer|Orbiter|OrgProbe\/[0-9]|ow\.ly|ownCloud News|Page Analyzer|Page Valet|page2rss|page_verifier|PagePeeker|Pagespeed\/[0-9]|Panopta|panscient|parsijoo|PayPal IPN|Pcore-HTTP|Pearltrees|peerindex|Peew|PhantomJS|Photon|phpcrawl|phpservermon|Pi-Monster|Pingdom\.com|Pingoscope|PingSpot|Pinterest|Pizilla|Ploetz \+ Zeller|Plukkie|PocketParser|Pompos|Porkbun|Port Monitor|postano|PostPost|postrank|PowerPoint|Priceonomics Analysis Engine|Prlog|probethenet|Project 25499|Promotion_Tools_www.searchenginepromotionhelp.com|prospectb2b|Protopage|proximic|PTST |PTST\/[0-9]+|Pulsepoint XT3 web scraper|Python-httplib2|python-requests|Python-urllib|Qirina Hurdler|Qseero|Qualidator.com SiteAnalyzer|Quora Link Preview|Qwantify|Radian6|RankSonicSiteAuditor|Readability|RealPlayer%20Downloader|RebelMouse|redback|Redirect Checker Tool|ReederForMac|request\.js|ResponseCodeTest\/[0-9]|RestSharp|RetrevoPageAnalyzer|Riddler|Rival IQ|Robosourcer|Robozilla\/[0-9]|ROI Hunter|SalesIntelligent|SauceNAO|SBIder|Scoop|scooter|ScoutJet|ScoutURLMonitor|Scrapy|Scrubby|SearchSight|semanticdiscovery|semanticjuice|SEO Browser|Seo Servis|seo-nastroj.cz|Seobility|SEOCentro|SeoCheck|SeopultContentAnalyzer|SEOstats|Server Density Service Monitoring|servernfo\.com|Seznam screenshot-generator|Shelob|Shoppimon Analyzer|ShoppimonAgent\/[0-9]|ShopWiki|ShortLinkTranslate|shrinktheweb|SilverReader|SimplePie|SimplyFast|Site-Shot|Site24x7|SiteBar|SiteCondor|siteexplorer\.info|SiteGuardian|Siteimprove\.com|Sitemap(s)? Generator|Siteshooter B0t|SiteTruth|sitexy\.com|SkypeUriPreview|slider\.com|slurp|SMRF URL Expander|SMUrlExpander|Snappy|SniffRSS|sniptracker|Snoopy|sogou|SortSite|spaziodati|Specificfeeds|speedy|SPEng|Spinn3r|spray-can|Sprinklr |spyonweb|Sqworm|SSL Labs|Rambler|Statastico|StatusCake|Stratagems Kumo|Stroke.cz|StudioFACA|suchen|summify|Super Monitoring|Surphace Scout|SwiteScraper|Symfony2 BrowserKit|SynHttpClient-Built|Sysomos|T0PHackTeam|Tarantula|teoma|terrainformatica\.com|The Expert HTML Source Viewer|theinternetrules|theoldreader\.com|Thumbshots|ThumbSniper|TinEye|Tiny Tiny RSS|topster|touche.com|Traackr.com|truwoGPS|tweetedtimes\.com|Tweetminster|Twikle|Twingly|Typhoeus|ubermetrics-technologies|uclassify|UdmSearch|UnwindFetchor|updated|Upflow|URLChecker|URLitor.com|urlresolver|Urlstat|UrlTrends Ranking Updater|Vagabondo|via ggpht\.com GoogleImageProxy|visionutils|vkShare|voltron|Vortex\/[0-9]|voyager|VSAgent\/[0-9]|VSB-TUO\/[0-9]|VYU2|w3af\.org|W3C-checklink|W3C-mobileOK|W3C_I18n-Checker|W3C_Unicorn|wangling|Wappalyzer|WatchMouse|WbSrch|web-capture\.net|Web-Monitoring|Web-sniffer|Webauskunft|WebCapture|webcollage|WebCookies|WebCorp|WebDoc|WebFetch|WebImages|WebIndex|webkit2png|webmastercoffee|webmon |webscreenie|Webshot|Website Analyzer|websitepulse[+ ]checker|Websnapr|Websquash\.com|Webthumb\/[0-9]|WebThumbnail|WeCrawlForThePeace|WeLikeLinks|WEPA|WeSEE|wf84|wget|WhatsApp|WhatsMyIP|WhatWeb|Whibse|Whynder Magnet|Windows-RSS-Platform|WinHttpRequest|wkhtmlto|wmtips|Woko|WomlpeFactory|Word|WordPress|wotbox|WP Engine Install Performance API|WPScan|wscheck|WWW-Mechanize|www\.monitor\.us|XaxisSemanticsClassifier|Xenu Link Sleuth|XING-contenttabreceiver\/[0-9]|XmlSitemapGenerator|xpymep([0-9]?)\.exe|Y!J-(ASR|BSC)|Yaanb|yacy|Yahoo Ad monitoring|Yahoo Link Preview|YahooCacheSystem|YahooSeeker|YahooYSMcm|YandeG|yandex|yanga|yeti|Yo-yo|Yoleo Consumer|yoogliFetchAgent|YottaaMonitor|yourls\.org|Zao|Zemanta Aggregator|Zend\\\\Http\\\\Client|Zend_Http_Client|zgrab|ZnajdzFoto|ZyBorg#i', $user_agent, $badbot);
            if($goodbot || $badbot)
            {
                $bot = true;
            }
            preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
            preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($user_agent,0,4), $matches2);
            if($matches || $matches2)
            {
                $mobile = true;
            }
            preg_match('/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle|NRD90M|SGP771|SHIELD|SM-T550|KFTHWI|LG-V410|nexus/i', $user_agent, $matches3);
            if($matches3)
            {
                $tablet = true;
            }
            if($device === 'Bot')
            {
                if($bot === true)
                {
                    add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                }
            }
            if($device === 'Mobile')
            {
                if($mobile === true)
                {
                    add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                }
            }
            if($device === 'Tablet')
            {
                if($tablet === true)
                {
                    add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                }
            }
            if($device === 'Desktop')
            {
                if($tablet === false && $mobile === false && $bot === false)
                {
                    add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
                }
            }
        }
    }
    if (isset($silencer_Main_Settings['pingback_authors']) && !empty($silencer_Main_Settings['pingback_authors']))
    {
        $id = get_the_author_meta( 'ID' );
        if($id != '')
        {
            if(in_array($id, $silencer_Main_Settings['pingback_authors']))
            {
                add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['pingback_login']) && !empty($silencer_Main_Settings['pingback_login']))
    {
        $id = get_current_user_id();
        if($id != 0)
        {
            if(in_array($id, $silencer_Main_Settings['pingback_login']))
            {
                add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['pingback_country']) && $silencer_Main_Settings['pingback_country'] != '')
    {
        $country = $silencer_Main_Settings['pingback_country'];
        if($country === 'ALL')
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
        elseif($country !== 'NONE')
        {
            if (isset($_SERVER['HTTP_CLIENT_IP'])) {
                $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
            } else {
                if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                    $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                } else {
                    $real_ip_adress = $_SERVER['REMOTE_ADDR'];
                }
            }
            $country_code = silencer_ip_info($real_ip_adress, "Country Code");
            if(strcasecmp($country, $country_code) == 0)
            {
                add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
            }
        }
    }
    if (isset($silencer_Main_Settings['pingback_language']) && $silencer_Main_Settings['pingback_language'] != '')
    {
        $language = $silencer_Main_Settings['pingback_language'];
        if($language == 'ALL')
        {
            add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
            add_filter('pre_update_default_ping_status', '__return_false');
            add_filter('pre_option_default_ping_status', '__return_zero');
            add_filter('pre_update_default_pingback_flag', '__return_false');
            add_filter('pre_option_default_pingback_flag', '__return_zero');
            return false;
        }
        elseif($language != 'NONE')          
        {
            $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
            if(strcasecmp($language, $lang) == 0)
            {
                add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
                add_filter('pre_update_default_ping_status', '__return_false');
                add_filter('pre_option_default_ping_status', '__return_zero');
                add_filter('pre_update_default_pingback_flag', '__return_false');
                add_filter('pre_option_default_pingback_flag', '__return_zero');
                return false;
            }
        }
    }
    $silencer_stored_meta = get_post_meta( $post_id );
    if ( isset ( $silencer_stored_meta["disable_pingbacks"]) && $silencer_stored_meta["disable_pingbacks"][0] == "on" ) 
    {
        add_filter('bloginfo_url', 'silencer_filter_pingback_url', 10, 2);
        add_filter('pre_update_default_ping_status', '__return_false');
        add_filter('pre_option_default_ping_status', '__return_zero');
        add_filter('pre_update_default_pingback_flag', '__return_false');
        add_filter('pre_option_default_pingback_flag', '__return_zero');
        return false;
    }
    return $open;
}

function silencer_disable_comments_admin_menu() {
    remove_menu_page('edit-comments.php');
    remove_submenu_page( 'options-general.php', 'options-discussion.php' );
}

function silencer_disable_comments_admin_menu_redirect() {
    global $pagenow;
    if ($pagenow === 'edit-comments.php' || $pagenow === 'comment.php' || $pagenow == 'options-discussion.php') {
        wp_redirect(admin_url()); exit;
    }
}
function silencer_remove_network_comment_links( $wp_admin_bar ) {
	if( $this->networkactive && is_user_logged_in() ) {
		foreach( (array) $wp_admin_bar->user->blogs as $blog ) {
			$wp_admin_bar->remove_menu( 'blog-' . $blog->userblog_id . '-c' );
		}
	}
	else 
    {
        $wp_admin_bar->remove_menu( 'blog-' . get_current_blog_id() . '-c' );	
    }
}

function silencer_disable_comments_admin_bar() {
    if( is_admin_bar_showing() ) {
        global $wp_admin_bar;
        $wp_admin_bar->remove_menu('comments');
        if( is_multisite() ) {
			add_action( 'admin_bar_menu', 'silencer_remove_network_comment_links', 500 );
		}
    }
}

register_activation_hook(__FILE__, 'silencer_check_version');
function silencer_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.0';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
}

add_action('admin_init', 'silencer_register_mysettings');
function silencer_register_mysettings()
{
    register_setting('silencer_option_group', 'silencer_Main_Settings');
    if(is_multisite())
    {
        if (!get_option('silencer_Main_Settings'))
        {
            silencer_activation_callback(TRUE);
        }
    }
}

function silencer_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function silencer_get_file_url($url)
{
    return silencer_get_plugin_url() . '/' . $url;
}

function silencer_add_meta_box()
{
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    if (isset($silencer_Main_Settings['silencer_enabled']) && $silencer_Main_Settings['silencer_enabled'] == 'on')
    {
        if (isset($silencer_Main_Settings['enable_metabox']) && $silencer_Main_Settings['enable_metabox'] == 'on')
        {
            add_meta_box('silencer_comment_management', 'Silencer Comment Management System', 'silencer_meta_box_function', 'post', 'side', 'default');
            add_meta_box('silencer_comment_management', 'Silencer Comment Management System', 'silencer_meta_box_function', 'page', 'side', 'default');
        }
    }        
}
add_action('add_meta_boxes', 'silencer_add_meta_box');
function silencer_meta_box_function($post)
{
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    $silencer_stored_meta = get_post_meta( $post->ID );
    $ech = '<p>';
    $ech .= wp_nonce_field( basename( __FILE__ ), 'silencer_nonce', false, false);
    $ech .= '<table><tr><td><p><b>Post Specific Commenting Options:</b></p></td></tr>';
    if (isset($silencer_Main_Settings['enable_box_comments']) && $silencer_Main_Settings['enable_box_comments'] == 'on')
    {
        $ech .= '<tr><td><label for="meta-text">Disable Comment Submission&nbsp;</label></td><td><input type="checkbox" name="disable_comments" id="disable_comments" ';
        if ( isset ( $silencer_stored_meta["disable_comments"]) && $silencer_stored_meta["disable_comments"][0] == "on" ) 
        {
            $ech .= " checked";
        }
        $ech .= '/></td></tr>';
    }
    if (isset($silencer_Main_Settings['enable_box_hiding']) && $silencer_Main_Settings['enable_box_hiding'] == 'on')
    {
        $ech .= '<tr><td><label for="meta-text">Hide Existing Comments&nbsp;</label></td><td><input type="checkbox" name="hide_comments" id="hide_comments" ';
        if ( isset ( $silencer_stored_meta["hide_comments"]) && $silencer_stored_meta["hide_comments"][0] == "on" ) 
        {
            $ech .= " checked";
        }
        $ech .= '/></td></tr>';
    }
    if (isset($silencer_Main_Settings['enable_box_pingback']) && $silencer_Main_Settings['enable_box_pingback'] == 'on')
    {
        $ech .= '<tr><td><label for="meta-text">Disable Pingbacks&nbsp;</label></td><td><input type="checkbox" name="disable_pingbacks" id="disable_pingbacks" ';
        if ( isset ( $silencer_stored_meta["disable_pingbacks"]) && $silencer_stored_meta["disable_pingbacks"][0] == "on" ) 
        {
            $ech .= " checked";
        }
        $ech .= '/></td></tr>';
    }
    if (isset($silencer_Main_Settings['enable_box_trackback']) && $silencer_Main_Settings['enable_box_trackback'] == 'on')
    {
        $ech .= '<tr><td><label for="meta-text">Disable Trackbacks&nbsp;</label></td><td><input type="checkbox" name="disable_trackbacks" id="disable_trackbacks" ';
        if ( isset ( $silencer_stored_meta["disable_trackbacks"]) && $silencer_stored_meta["disable_trackbacks"][0] == "on" ) 
        {
            $ech .= " checked";
        }
        $ech .= '/></td></tr>';
    }
    $ech .= '</table>';
    if (isset($silencer_Main_Settings['enable_box_button']) && $silencer_Main_Settings['enable_box_button'] == 'on')
    {
        $ech .= '<center><br/><input type="submit" onclick="return confirm(\'Are you sure you want to delete ALL COMMENTS for this post?\')" class="button button-primary button-large" name="deleteAllComments" value="Delete All Comments For This Post"/></center>';
    }
    $ech .= '</p>';
    echo $ech;
}
function silencer_meta_save( $post_id ) {
    global $wpdb;
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    if (isset($silencer_Main_Settings['silencer_enabled']) && $silencer_Main_Settings['silencer_enabled'] == 'on')
    {
        $is_autosave = wp_is_post_autosave( $post_id );
        $is_revision = wp_is_post_revision( $post_id );
        $is_valid_nonce = ( isset( $_POST[ 'silencer_nonce' ] ) && wp_verify_nonce( $_POST[ 'silencer_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
        
        if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
            return;
        }
        if( isset( $_POST[ 'disable_comments' ] ) && $_POST[ 'disable_comments' ] == 'on') {
            update_post_meta( $post_id, 'disable_comments', 'on' );
        }
        else
        {
            update_post_meta( $post_id, 'disable_comments', 'off' );
        }
        if( isset( $_POST[ 'hide_comments' ] ) && $_POST[ 'hide_comments' ] == 'on') {
            update_post_meta( $post_id, 'hide_comments', 'on' );
        }
        else
        {
            update_post_meta( $post_id, 'hide_comments', 'off' );
        }
        if( isset( $_POST[ 'disable_pingbacks' ] ) && $_POST[ 'disable_pingbacks' ] == 'on') {
            update_post_meta( $post_id, 'disable_pingbacks', 'on' );
        }
        else
        {
            update_post_meta( $post_id, 'disable_pingbacks', 'off' );
        }
        if( isset( $_POST[ 'disable_trackbacks' ] ) && $_POST[ 'disable_trackbacks' ] == 'on') {
            update_post_meta( $post_id, 'disable_trackbacks', 'on' );
        }
        else
        {
            update_post_meta( $post_id, 'disable_trackbacks', 'off' );
        }
        if( isset($_POST['deleteAllComments']))
        {
            if(isset($wpdb))
            {
                $wpdb->query( "UPDATE wp_comments SET comment_approved='trash' WHERE comment_post_ID=" . $post_id);
            }
        }
    }
}
add_action( 'save_post', 'silencer_meta_save' );

add_action('admin_enqueue_scripts', 'silencer_admin_load_files');
function silencer_admin_load_files()
{
    wp_register_style('silencer-browser-style', plugins_url('styles/silencer-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('silencer-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('silencer-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('silencer-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('silencer-settings-app', plugins_url('res/silencer-angular.js', __FILE__), array(), '1.0.0', true);
}

require(dirname(__FILE__) . "/res/silencer-main.php");
require(dirname(__FILE__) . "/res/silencer-delete-comments.php");
require(dirname(__FILE__) . "/res/silencer-browser-detector.php");
?>