<?php
function silencer_delete_comments()
{
    global $wpdb;
    if( isset($_POST['deletePages'])) {
        $wpdb->query( "DELETE cmeta FROM $wpdb->commentmeta cmeta INNER JOIN $wpdb->comments comments ON cmeta.comment_id=comments.comment_ID INNER JOIN $wpdb->posts posts ON comments.comment_post_ID=posts.ID WHERE posts.post_type = 'page'" );
        $wpdb->query( "DELETE comments FROM $wpdb->comments comments INNER JOIN $wpdb->posts posts ON comments.comment_post_ID=posts.ID WHERE posts.post_type = 'page'" );
        $wpdb->query( "UPDATE $wpdb->posts SET comment_count = 0 WHERE post_author != 0 AND post_type = 'page'" );
        $wpdb->query( "OPTIMIZE TABLE $wpdb->commentmeta" );
        $wpdb->query( "OPTIMIZE TABLE $wpdb->comments" );
        echo "<div style='color:green'><strong>All page comments deleted!</strong></div>";
	} elseif( isset($_POST['deletePosts'])) {
		$wpdb->query( "DELETE cmeta FROM $wpdb->commentmeta cmeta INNER JOIN $wpdb->comments comments ON cmeta.comment_id=comments.comment_ID INNER JOIN $wpdb->posts posts ON comments.comment_post_ID=posts.ID WHERE posts.post_type = 'post'" );
        $wpdb->query( "DELETE comments FROM $wpdb->comments comments INNER JOIN $wpdb->posts posts ON comments.comment_post_ID=posts.ID WHERE posts.post_type = 'post'" );
        $wpdb->query( "UPDATE $wpdb->posts SET comment_count = 0 WHERE post_author != 0 AND post_type = 'post'" );
        $wpdb->query( "OPTIMIZE TABLE $wpdb->commentmeta" );
        $wpdb->query( "OPTIMIZE TABLE $wpdb->comments" );
        echo "<div style='color:green'><strong>All post comments deleted!</strong></div>";

	} elseif( isset($_POST['deleteAttachments'])) {
		$wpdb->query( "DELETE cmeta FROM $wpdb->commentmeta cmeta INNER JOIN $wpdb->comments comments ON cmeta.comment_id=comments.comment_ID INNER JOIN $wpdb->posts posts ON comments.comment_post_ID=posts.ID WHERE posts.post_type = 'attachment'" );
        $wpdb->query( "DELETE comments FROM $wpdb->comments comments INNER JOIN $wpdb->posts posts ON comments.comment_post_ID=posts.ID WHERE posts.post_type = 'attachment'" );
        $wpdb->query( "UPDATE $wpdb->posts SET comment_count = 0 WHERE post_author != 0 AND post_type = 'attachment'" );
        $wpdb->query( "OPTIMIZE TABLE $wpdb->commentmeta" );
        $wpdb->query( "OPTIMIZE TABLE $wpdb->comments" );
        echo "<div style='color:green'><strong>All attachment comments deleted!</strong></div>";
	}
    $comments_count = $wpdb->get_var("SELECT count(comment_id) from $wpdb->comments");
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form  onsubmit="return confirm('Are you sure you want to delete all comments for the respective page type?');" id="myForm" method="post" action="admin.php?page=silencer_delete_comments">

<script>
                var silencer_admin_json = {
}
</script>
<h3>Bulk Delete Comments:</h3>
<div><b>Warning! These buttons will delete ALL EXISTING COMMENTS for the corresponding page types! Click them only if you know what you are doing!</b></div>
<div>
<?php
echo '<br/>There are ' .$comments_count . ' comments on the entire website!';
?>
</div>       
<div><p class="submit"><input type="submit" name="deletePages" id="deletePages" class="button button-primary" value="Delete Comments for Pages"/>&nbsp;&nbsp;<input type="submit" name="deletePosts" id="deletePosts" class="button button-primary" value="Delete Comments for Posts"/>&nbsp;&nbsp;<input type="submit" name="deleteAttachments" id="deleteAttachments" class="button button-primary" value="Delete Comments for Attachments"/></p></div>
    </form>
</div>
</div>
<?php
}
?>