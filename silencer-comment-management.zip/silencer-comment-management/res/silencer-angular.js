angular.module('silsettingsApp', ['ngSanitize'])
.controller('silsettingsController', function($scope) {
    $scope.settings = silencer_admin_json;
});