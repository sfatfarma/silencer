<?php
function silencer_list_authors() 
{
    $authors = array();
    $contributor_ids = get_users( array(
        'fields'  => 'ID',
        'orderby' => 'post_count',
        'order'   => 'DESC'
    ) );

    foreach ( $contributor_ids as $contributor_id )
    {
        $post_count = count_user_posts( $contributor_id );
        if ( ! $post_count ) {
            continue;
        }
        $authors[] = $contributor_id;
    }
    return $authors;
}
function silencer_list_users() 
{
    $user_ids = get_users( array(
        'fields'  => 'ID',
        'orderby' => 'display_name',
        'order'   => 'DESC'
    ) );

    return $user_ids;
}
function list_countries($country)
{
    $output = '<option value="NONE" ';
                            if($country === 'NONE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>NONE</option><option value="ALL" ';
                            if($country === 'ALL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>ALL</option>
                            <option value="AF" ';
                            if($country === 'AF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Afghanistan</option>
                            <option value="AX" ';
                            if($country === 'AX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Åland Islands</option>
                            <option value="AL" ';
                            if($country === 'AL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Albania</option>
                            <option value="DZ" ';
                            if($country === 'DZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Algeria</option>
                            <option value="AS" ';
                            if($country === 'AS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>American Samoa</option>
                            <option value="AD" ';
                            if($country === 'AD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Andorra</option>
                            <option value="AO" ';
                            if($country === 'AO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Angola</option>
                            <option value="AI" ';
                            if($country === 'AI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Anguilla</option>
                            <option value="AQ" ';
                            if($country === 'AQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Antarctica</option>
                            <option value="AG" ';
                            if($country === 'AG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Antigua and Barbuda</option>
                            <option value="AR" ';
                            if($country === 'AR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Argentina</option>
                            <option value="AM" ';
                            if($country === 'AM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Armenia</option>
                            <option value="AW" ';
                            if($country === 'AW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Aruba</option>
                            <option value="AU" ';
                            if($country === 'AU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Australia</option>
                            <option value="AT" ';
                            if($country === 'AT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Austria</option>
                            <option value="AZ" ';
                            if($country === 'AZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Azerbaijan</option>
                            <option value="BS" ';
                            if($country === 'BS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bahamas</option>
                            <option value="BH" ';
                            if($country === 'BH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bahrain</option>
                            <option value="BD" ';
                            if($country === 'BD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bangladesh</option>
                            <option value="BB" ';
                            if($country === 'BB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Barbados</option>
                            <option value="BB" ';
                            if($country === 'BB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Belarus</option>
                            <option value="BE" ';
                            if($country === 'BE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Belgium</option>
                            <option value="BZ" ';
                            if($country === 'BZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Belize</option>
                            <option value="BJ" ';
                            if($country === 'BJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Benin</option>
                            <option value="BM" ';
                            if($country === 'BM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bermuda</option>
                            <option value="BT" ';
                            if($country === 'BT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bhutan</option>
                            <option value="BO" ';
                            if($country === 'BO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bolivia, Plurinational State of</option>
                            <option value="BQ" ';
                            if($country === 'BQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bonaire, Sint Eustatius and Saba</option>
                            <option value="BA" ';
                            if($country === 'BA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bosnia and Herzegovina</option>
                            <option value="BW" ';
                            if($country === 'BW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Botswana</option>
                            <option value="BV" ';
                            if($country === 'BV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bouvet Island</option>
                            <option value="BR" ';
                            if($country === 'BR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Brazil</option>
                            <option value="IO" ';
                            if($country === 'IO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>British Indian Ocean Territory</option>
                            <option value="BN" ';
                            if($country === 'BN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Brunei Darussalam</option>
                            <option value="BG" ';
                            if($country === 'BG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bulgaria</option>
                            <option value="BF" ';
                            if($country === 'BF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Burkina Faso</option>
                            <option value="BI" ';
                            if($country === 'BI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Burundi</option>
                            <option value="KH" ';
                            if($country === 'KH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cambodia</option>
                            <option value="CM" ';
                            if($country === 'CM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cameroon</option>
                            <option value="CA" ';
                            if($country === 'CA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Canada</option>
                            <option value="CV" ';
                            if($country === 'CV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cape Verde</option>
                            <option value="KY" ';
                            if($country === 'KY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cayman Islands</option>
                            <option value="CF" ';
                            if($country === 'CF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Central African Republic</option>
                            <option value="TD" ';
                            if($country === 'TD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Chad</option>
                            <option value="CL" ';
                            if($country === 'CL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Chile</option>
                            <option value="CN" ';
                            if($country === 'CN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>China</option>
                            <option value="CX" ';
                            if($country === 'CX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Christmas Island</option>
                            <option value="CC" ';
                            if($country === 'CC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cocos (Keeling) Islands</option>
                            <option value="CO" ';
                            if($country === 'CO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Colombia</option>
                            <option value="KM" ';
                            if($country === 'KM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Comoros</option>
                            <option value="CG" ';
                            if($country === 'CG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Congo</option>
                            <option value="CD" ';
                            if($country === 'CD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Congo, the Democratic Republic of the</option>
                            <option value="CK" ';
                            if($country === 'CK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cook Islands</option>
                            <option value="CR" ';
                            if($country === 'CR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Costa Rica</option>
                            <option value="CI" ';
                            if($country === 'CI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Côte d\'Ivoire</option>
                            <option value="HR" ';
                            if($country === 'HR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Croatia</option>
                            <option value="CU" ';
                            if($country === 'CU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cuba</option>
                            <option value="CW" ';
                            if($country === 'CW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Curaçao</option>
                            <option value="CY" ';
                            if($country === 'CY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cyprus</option>
                            <option value="CZ" ';
                            if($country === 'CZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Czech Republic</option>
                            <option value="DK" ';
                            if($country === 'DK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Denmark</option>
                            <option value="DJ" ';
                            if($country === 'DJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Djibouti</option>
                            <option value="DM" ';
                            if($country === 'DM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Dominica</option>
                            <option value="DO" ';
                            if($country === 'DO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Dominican Republic</option>
                            <option value="EC" ';
                            if($country === 'EC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ecuador</option>
                            <option value="EG" ';
                            if($country === 'EG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Egypt</option>
                            <option value="SV" ';
                            if($country === 'SV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>El Salvador</option>
                            <option value="GQ" ';
                            if($country === 'GQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Equatorial Guinea</option>
                            <option value="ER" ';
                            if($country === 'ER')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Eritrea</option>
                            <option value="EE" ';
                            if($country === 'EE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Estonia</option>
                            <option value="ET" ';
                            if($country === 'ET')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ethiopia</option>
                            <option value="FK" ';
                            if($country === 'FK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Falkland Islands (Malvinas)</option>
                            <option value="FO" ';
                            if($country === 'FO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Faroe Islands</option>
                            <option value="FJ" ';
                            if($country === 'FJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Fiji</option>
                            <option value="FI" ';
                            if($country === 'FI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Finland</option>
                            <option value="FR" ';
                            if($country === 'FR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>France</option>
                            <option value="GF" ';
                            if($country === 'GF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French Guiana</option>
                            <option value="PF" ';
                            if($country === 'PF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French Polynesia</option>
                            <option value="TF" ';
                            if($country === 'TF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French Southern Territories</option>
                            <option value="GA" ';
                            if($country === 'GA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gabon</option>
                            <option value="GM" ';
                            if($country === 'GM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gambia</option>
                            <option value="GE" ';
                            if($country === 'GE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Georgia</option>
                            <option value="DE" ';
                            if($country === 'DE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Germany</option>
                            <option value="GH" ';
                            if($country === 'GH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ghana</option>
                            <option value="GI" ';
                            if($country === 'GI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gibraltar</option>
                            <option value="GR" ';
                            if($country === 'GR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Greece</option>
                            <option value="GL" ';
                            if($country === 'GL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Greenland</option>
                            <option value="GD" ';
                            if($country === 'GD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Grenada</option>
                            <option value="GP" ';
                            if($country === 'GP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guadeloupe</option>
                            <option value="GU" ';
                            if($country === 'GU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guam</option>
                            <option value="GT" ';
                            if($country === 'GT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guatemala</option>
                            <option value="GG" ';
                            if($country === 'GG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guernsey</option>
                            <option value="GN" ';
                            if($country === 'GN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guinea</option>
                            <option value="GW" ';
                            if($country === 'GW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guinea-Bissau</option>
                            <option value="GY" ';
                            if($country === 'GY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guyana</option>
                            <option value="HT" ';
                            if($country === 'HT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Haiti</option>
                            <option value="HM" ';
                            if($country === 'HM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Heard Island and McDonald Islands</option>
                            <option value="VA" ';
                            if($country === 'VA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Holy See (Vatican City State)</option>
                            <option value="HN" ';
                            if($country === 'HN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Honduras</option>
                            <option value="HK" ';
                            if($country === 'HK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hong Kong</option>
                            <option value="HU" ';
                            if($country === 'HU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hungary</option>
                            <option value="IS" ';
                            if($country === 'IS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Iceland</option>
                            <option value="IN" ';
                            if($country === 'IN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>India</option>
                            <option value="ID" ';
                            if($country === 'ID')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Indonesia</option>
                            <option value="IR" ';
                            if($country === 'IR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Iran, Islamic Republic of</option>
                            <option value="IQ" ';
                            if($country === 'IQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Iraq</option>
                            <option value="IE" ';
                            if($country === 'IE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ireland</option>
                            <option value="IM" ';
                            if($country === 'IM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Isle of Man</option>
                            <option value="IL" ';
                            if($country === 'IL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Israel</option>
                            <option value="IT" ';
                            if($country === 'IT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Italy</option>
                            <option value="JM" ';
                            if($country === 'JM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Jamaica</option>
                            <option value="JP" ';
                            if($country === 'JP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Japan</option>
                            <option value="JE" ';
                            if($country === 'JE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Jersey</option>
                            <option value="JO" ';
                            if($country === 'JO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Jordan</option>
                            <option value="KZ" ';
                            if($country === 'KZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kazakhstan</option>
                            <option value="KE" ';
                            if($country === 'KE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kenya</option>
                            <option value="KI" ';
                            if($country === 'KI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kiribati</option>
                            <option value="KP" ';
                            if($country === 'KP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Korea, Democratic People\'s Republic of</option>
                            <option value="KR" ';
                            if($country === 'KR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Korea, Republic of</option>
                            <option value="KW" ';
                            if($country === 'KW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kuwait</option>
                            <option value="KG" ';
                            if($country === 'KG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kyrgyzstan</option>
                            <option value="LA" ';
                            if($country === 'LA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lao People\'s Democratic Republic</option>
                            <option value="LV" ';
                            if($country === 'LV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Latvia</option>
                            <option value="LB" ';
                            if($country === 'LB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lebanon</option>
                            <option value="LS" ';
                            if($country === 'LS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lesotho</option>
                            <option value="LR" ';
                            if($country === 'LR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Liberia</option>
                            <option value="LY" ';
                            if($country === 'LY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Libya</option>
                            <option value="LI" ';
                            if($country === 'LI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Liechtenstein</option>
                            <option value="LT" ';
                            if($country === 'LT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lithuania</option>
                            <option value="LU" ';
                            if($country === 'LU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Luxembourg</option>
                            <option value="MO" ';
                            if($country === 'MO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Macao</option>
                            <option value="MK" ';
                            if($country === 'MK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Macedonia, the former Yugoslav Republic of</option>
                            <option value="MG" ';
                            if($country === 'MG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Madagascar</option>
                            <option value="MW" ';
                            if($country === 'MW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malawi</option>
                            <option value="MY" ';
                            if($country === 'MY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malaysia</option>
                            <option value="MV" ';
                            if($country === 'MV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Maldives</option>
                            <option value="ML" ';
                            if($country === 'ML')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mali</option>
                            <option value="MT" ';
                            if($country === 'MT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malta</option>
                            <option value="MH" ';
                            if($country === 'MH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Marshall Islands</option>
                            <option value="MQ" ';
                            if($country === 'MQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Martinique</option>
                            <option value="MR" ';
                            if($country === 'MR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mauritania</option>
                            <option value="MU" ';
                            if($country === 'MU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mauritius</option>
                            <option value="YT" ';
                            if($country === 'YT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mayotte</option>
                            <option value="MX" ';
                            if($country === 'MX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mexico</option>
                            <option value="FM" ';
                            if($country === 'FM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Micronesia, Federated States of</option>
                            <option value="MD" ';
                            if($country === 'MD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Moldova, Republic of</option>
                            <option value="MC" ';
                            if($country === 'MC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Monaco</option>
                            <option value="MN" ';
                            if($country === 'MN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mongolia</option>
                            <option value="ME" ';
                            if($country === 'ME')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Montenegro</option>
                            <option value="MS" ';
                            if($country === 'MS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Montserrat</option>
                            <option value="MA" ';
                            if($country === 'MA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Morocco</option>
                            <option value="MZ" ';
                            if($country === 'MZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mozambique</option>
                            <option value="MM" ';
                            if($country === 'MM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Myanmar</option>
                            <option value="NA" ';
                            if($country === 'NA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Namibia</option>
                            <option value="NR" ';
                            if($country === 'NR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nauru</option>
                            <option value="NP" ';
                            if($country === 'NP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nepal</option>
                            <option value="NL" ';
                            if($country === 'NL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Netherlands</option>
                            <option value="NC" ';
                            if($country === 'NC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>New Caledonia</option>
                            <option value="NZ" ';
                            if($country === 'NZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>New Zealand</option>
                            <option value="NI" ';
                            if($country === 'NI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nicaragua</option>
                            <option value="NE" ';
                            if($country === 'NE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Niger</option>
                            <option value="NG" ';
                            if($country === 'NG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nigeria</option>
                            <option value="NU" ';
                            if($country === 'NU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Niue</option>
                            <option value="NF" ';
                            if($country === 'NF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Norfolk Island</option>
                            <option value="MP" ';
                            if($country === 'MP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Northern Mariana Islands</option>
                            <option value="NO" ';
                            if($country === 'NO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Norway</option>
                            <option value="OM" ';
                            if($country === 'OM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Oman</option>
                            <option value="PK" ';
                            if($country === 'PK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Pakistan</option>
                            <option value="PW" ';
                            if($country === 'PW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Palau</option>
                            <option value="PS" ';
                            if($country === 'PS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Palestinian Territory, Occupied</option>
                            <option value="PA" ';
                            if($country === 'PA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Panama</option>
                            <option value="PG" ';
                            if($country === 'PG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Papua New Guinea</option>
                            <option value="PY" ';
                            if($country === 'PY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Paraguay</option>
                            <option value="PE" ';
                            if($country === 'PE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Peru</option>
                            <option value="PH" ';
                            if($country === 'PH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Philippines</option>
                            <option value="PN" ';
                            if($country === 'PN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Pitcairn</option>
                            <option value="PL" ';
                            if($country === 'PL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Poland</option>
                            <option value="PT" ';
                            if($country === 'PT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Portugal</option>
                            <option value="PR" ';
                            if($country === 'PR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Puerto Rico</option>
                            <option value="QA" ';
                            if($country === 'QA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Qatar</option>
                            <option value="RE" ';
                            if($country === 'RE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Réunion</option>
                            <option value="RO" ';
                            if($country === 'RO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Romania</option>
                            <option value="RU" ';
                            if($country === 'RU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Russian Federation</option>
                            <option value="RW" ';
                            if($country === 'RW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Rwanda</option>
                            <option value="BL" ';
                            if($country === 'BL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Barthélemy</option>
                            <option value="SH" ';
                            if($country === 'SH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Helena, Ascension and Tristan da Cunha</option>
                            <option value="KN" ';
                            if($country === 'KN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Kitts and Nevis</option>
                            <option value="LC" ';
                            if($country === 'LC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Lucia</option>
                            <option value="MF" ';
                            if($country === 'MF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Martin (French part)</option>
                            <option value="PM" ';
                            if($country === 'PM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Pierre and Miquelon</option>
                            <option value="VC" ';
                            if($country === 'VC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Vincent and the Grenadines</option>
                            <option value="WS" ';
                            if($country === 'WS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Samoa</option>
                            <option value="SM" ';
                            if($country === 'SM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>San Marino</option>
                            <option value="ST" ';
                            if($country === 'ST')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sao Tome and Principe</option>
                            <option value="SA" ';
                            if($country === 'SA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saudi Arabia</option>
                            <option value="SN" ';
                            if($country === 'SN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Senegal</option>
                            <option value="RS" ';
                            if($country === 'RS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Serbia</option>
                            <option value="SC" ';
                            if($country === 'SC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Seychelles</option>
                            <option value="SL" ';
                            if($country === 'SL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sierra Leone</option>
                            <option value="SG" ';
                            if($country === 'SG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Singapore</option>
                            <option value="SX" ';
                            if($country === 'SX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sint Maarten (Dutch part)</option>
                            <option value="SK" ';
                            if($country === 'SK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovakia</option>
                            <option value="SI" ';
                            if($country === 'SI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovenia</option>
                            <option value="SB" ';
                            if($country === 'SB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Solomon Islands</option>
                            <option value="SO" ';
                            if($country === 'SO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Somalia</option>
                            <option value="ZA" ';
                            if($country === 'ZA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>South Africa</option>
                            <option value="GS" ';
                            if($country === 'GS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>South Georgia and the South Sandwich Islands</option>
                            <option value="SS" ';
                            if($country === 'SS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>South Sudan</option>
                            <option value="ES" ';
                            if($country === 'ES')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Spain</option>
                            <option value="LK" ';
                            if($country === 'LK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sri Lanka</option>
                            <option value="SD" ';
                            if($country === 'SD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sudan</option>
                            <option value="SR" ';
                            if($country === 'SR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Suriname</option>
                            <option value="SJ" ';
                            if($country === 'SJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Svalbard and Jan Mayen</option>
                            <option value="SZ" ';
                            if($country === 'SZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Swaziland</option>
                            <option value="SE" ';
                            if($country === 'SE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sweden</option>
                            <option value="CH" ';
                            if($country === 'CH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Switzerland</option>
                            <option value="SY" ';
                            if($country === 'SY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Syrian Arab Republic</option>
                            <option value="TW" ';
                            if($country === 'TW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Taiwan, Province of China</option>
                            <option value="TJ" ';
                            if($country === 'TJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tajikistan</option>
                            <option value="TZ" ';
                            if($country === 'TZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tanzania, United Republic of</option>
                            <option value="TH" ';
                            if($country === 'TH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Thailand</option>
                            <option value="TL" ';
                            if($country === 'TL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Timor-Leste</option>
                            <option value="TG" ';
                            if($country === 'TG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Togo</option>
                            <option value="TK" ';
                            if($country === 'TK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tokelau</option>
                            <option value="TO" ';
                            if($country === 'TO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tonga</option>
                            <option value="TT" ';
                            if($country === 'TT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Trinidad and Tobago</option>
                            <option value="TN" ';
                            if($country === 'TN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tunisia</option>
                            <option value="TR" ';
                            if($country === 'TR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turkey</option>
                            <option value="TM" ';
                            if($country === 'TM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turkmenistan</option>
                            <option value="TC" ';
                            if($country === 'TC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turks and Caicos Islands</option>
                            <option value="TV" ';
                            if($country === 'TV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tuvalu</option>
                            <option value="UG" ';
                            if($country === 'UG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uganda</option>
                            <option value="UA" ';
                            if($country === 'UA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ukraine</option>
                            <option value="AE" ';
                            if($country === 'AE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United Arab Emirates</option>
                            <option value="GB" ';
                            if($country === 'GB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United Kingdom</option>
                            <option value="US" ';
                            if($country === 'US')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United States of America</option>
                            <option value="UM" ';
                            if($country === 'UM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United States Minor Outlying Islands</option>
                            <option value="UY" ';
                            if($country === 'UY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uruguay</option>
                            <option value="UZ" ';
                            if($country === 'UZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uzbekistan</option>
                            <option value="VU" ';
                            if($country === 'VU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Vanuatu</option>
                            <option value="VE" ';
                            if($country === 'VE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Venezuela, Bolivarian Republic of</option>
                            <option value="VN" ';
                            if($country === 'VN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Viet Nam</option>
                            <option value="VG" ';
                            if($country === 'VG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Virgin Islands, British</option>
                            <option value="VI" ';
                            if($country === 'VI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Virgin Islands, U.S.</option>
                            <option value="WF" ';
                            if($country === 'WF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Wallis and Futuna</option>
                            <option value="EH" ';
                            if($country === 'EH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Western Sahara</option>
                            <option value="YE" ';
                            if($country === 'YE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Yemen</option>
                            <option value="ZM" ';
                            if($country === 'ZM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Zambia</option>
                            <option value="ZW" ';
                            if($country === 'ZW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Zimbabwe</option>';
                            return $output;
}

function list_languages($language)
{
    $output = '<option value="NONE" ';
                            if($language === 'NONE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>NONE</option><option value="ALL" ';
                            if($language === 'ALL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>ALL</option>
                            <option value="AF" ';
                            if($language === 'AF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Afrikanns</option>
                            <option value="SQ" ';
                            if($language === 'SQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Albanian</option>
                            <option value="AR" ';
                            if($language === 'AR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Arabic</option>
                            <option value="HY" ';
                            if($language === 'HY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Armenian</option>
                            <option value="EU" ';
                            if($language === 'EU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Basque</option>
                            <option value="BN" ';
                            if($language === 'BN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bengali</option>
                            <option value="BG" ';
                            if($language === 'BG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bulgarian</option>
                            <option value="CA" ';
                            if($language === 'CA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Catalan</option>
                            <option value="KM" ';
                            if($language === 'KM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cambodian</option>
                            <option value="ZH" ';
                            if($language === 'ZH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Chinese (Mandarin)</option>
                            <option value="HR" ';
                            if($language === 'HR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Croation</option>
                            <option value="CS" ';
                            if($language === 'CS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Czech</option>
                            <option value="DA" ';
                            if($language === 'DA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Danish</option>
                            <option value="NL" ';
                            if($language === 'NL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Dutch</option>
                            <option value="EN" ';
                            if($language === 'EN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>English</option>
                            <option value="ET" ';
                            if($language === 'ET')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Estonian</option>
                            <option value="FJ" ';
                            if($language === 'FJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Fiji</option>
                            <option value="FI" ';
                            if($language === 'FI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Finnish</option>
                            <option value="FR" ';
                            if($language === 'FR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French</option>
                            <option value="KA" ';
                            if($language === 'KA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Georgian</option>
                            <option value="DE" ';
                            if($language === 'DE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>German</option>
                            <option value="EL" ';
                            if($language === 'EL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Greek</option>
                            <option value="GU" ';
                            if($language === 'GU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gujarati</option>
                            <option value="HE" ';
                            if($language === 'HE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hebrew</option>
                            <option value="HI" ';
                            if($language === 'HI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hindi</option>
                            <option value="HU" ';
                            if($language === 'HU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hungarian</option>
                            <option value="IS" ';
                            if($language === 'IS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Icelandic</option>
                            <option value="ID" ';
                            if($language === 'ID')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Indonesian</option>
                            <option value="GA" ';
                            if($language === 'GA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Irish</option>
                            <option value="IT" ';
                            if($language === 'IT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Italian</option>
                            <option value="JA" ';
                            if($language === 'JA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Japanese</option>
                            <option value="JW" ';
                            if($language === 'JW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Javanese</option>
                            <option value="KO" ';
                            if($language === 'KO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Korean</option>
                            <option value="LA" ';
                            if($language === 'LA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Latin</option>
                            <option value="LV" ';
                            if($language === 'LV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Latvian</option>
                            <option value="LT" ';
                            if($language === 'LT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lithuanian</option>
                            <option value="MK" ';
                            if($language === 'MK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Macedonian</option>
                            <option value="MS" ';
                            if($language === 'MS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malay</option>
                            <option value="ML" ';
                            if($language === 'ML')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malayalam</option>
                            <option value="MT" ';
                            if($language === 'MT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Maltese</option>
                            <option value="MI" ';
                            if($language === 'MI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Maori</option>
                            <option value="MR" ';
                            if($language === 'MR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Marathi</option>
                            <option value="MN" ';
                            if($language === 'MN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mongolian</option>
                            <option value="NE" ';
                            if($language === 'NE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nepali</option>
                            <option value="NO" ';
                            if($language === 'NO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Norwegian</option>
                            <option value="FA" ';
                            if($language === 'FA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Persian</option>
                            <option value="PL" ';
                            if($language === 'PL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Polish</option>
                            <option value="PT" ';
                            if($language === 'PT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Portuguese</option>
                            <option value="PA" ';
                            if($language === 'PA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Punjabi</option>
                            <option value="QU" ';
                            if($language === 'QU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Quechua</option>
                            <option value="RO" ';
                            if($language === 'RO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Romanian</option>
                            <option value="RU" ';
                            if($language === 'RU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Russian</option>
                            <option value="SM" ';
                            if($language === 'SM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Samoan</option>
                            <option value="SR" ';
                            if($language === 'SR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Serbian</option>
                            <option value="SK" ';
                            if($language === 'SK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovak</option>
                            <option value="SL" ';
                            if($language === 'SL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovenian</option>
                            <option value="ES" ';
                            if($language === 'ES')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Spanish</option>
                            <option value="SW" ';
                            if($language === 'SW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Swahili</option>
                            <option value="SV" ';
                            if($language === 'SV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Swedish </option>
                            <option value="TA" ';
                            if($language === 'TA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tamil</option>
                            <option value="TT" ';
                            if($language === 'TT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tatar</option>
                            <option value="TE" ';
                            if($language === 'TE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Telugu</option>
                            <option value="TH" ';
                            if($language === 'TH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Thai</option>
                            <option value="BO" ';
                            if($language === 'BO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tibetan</option>
                            <option value="TO" ';
                            if($language === 'TO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tonga</option>
                            <option value="TR" ';
                            if($language === 'TR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turkish</option>
                            <option value="UK" ';
                            if($language === 'UK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ukranian</option>
                            <option value="UR" ';
                            if($language === 'UR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Urdu</option>
                            <option value="UZ" ';
                            if($language === 'UZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uzbek</option>
                            <option value="VI" ';
                            if($language === 'VI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Vietnamese</option>
                            <option value="CY" ';
                            if($language === 'CY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Welsh</option>
                            <option value="XH" ';
                            if($language === 'XH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Xhosa</option>';
                            return $output;
}

function silencer_admin_settings()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('silencer_option_group');
    do_settings_sections('silencer_option_group');
    $silencer_Main_Settings = get_option('silencer_Main_Settings', false);
    if (isset($silencer_Main_Settings['silencer_enabled'])) {
        $silencer_enabled = $silencer_Main_Settings['silencer_enabled'];
    } else {
        $silencer_enabled = '';
    }
    if (isset($silencer_Main_Settings['admin_disable_comments'])) {
        $admin_disable_comments = $silencer_Main_Settings['admin_disable_comments'];
    } else {
        $admin_disable_comments = '';
    }
    if (isset($silencer_Main_Settings['admin_redirect'])) {
        $admin_redirect = $silencer_Main_Settings['admin_redirect'];
    } else {
        $admin_redirect = '';
    }
    if (isset($silencer_Main_Settings['admin_remove_metabox'])) {
        $admin_remove_metabox = $silencer_Main_Settings['admin_remove_metabox'];
    } else {
        $admin_remove_metabox = '';
    }
    if (isset($silencer_Main_Settings['disable_admin_bar'])) {
        $disable_admin_bar = $silencer_Main_Settings['disable_admin_bar'];
    } else {
        $disable_admin_bar = '';
    }
    if (isset($silencer_Main_Settings['disable_comments_sidebar'])) {
        $disable_comments_sidebar = $silencer_Main_Settings['disable_comments_sidebar'];
    } else {
        $disable_comments_sidebar = '';
    }
    if (isset($silencer_Main_Settings['remove_url'])) {
        $remove_url = $silencer_Main_Settings['remove_url'];
    } else {
        $remove_url = '';
    }
    if (isset($silencer_Main_Settings['disable_xmlrpc'])) {
        $disable_xmlrpc = $silencer_Main_Settings['disable_xmlrpc'];
    } else {
        $disable_xmlrpc = '';
    }
    if (isset($silencer_Main_Settings['disable_comment_feed'])) {
        $disable_comment_feed = $silencer_Main_Settings['disable_comment_feed'];
    } else {
        $disable_comment_feed = '';
    }
    if (isset($silencer_Main_Settings['google_plus'])) {
        $google_plus = $silencer_Main_Settings['google_plus'];
    } else {
        $google_plus = '';
    }
    if (isset($silencer_Main_Settings['rsd_link'])) {
        $rsd_link = $silencer_Main_Settings['rsd_link'];
    } else {
        $rsd_link = '';
    }
    if (isset($silencer_Main_Settings['force_comments_overwrite'])) {
        $force_comments_overwrite = $silencer_Main_Settings['force_comments_overwrite'];
    } else {
        $force_comments_overwrite = '';
    }
    if (isset($silencer_Main_Settings['hide_feed_link'])) {
        $hide_feed_link = $silencer_Main_Settings['hide_feed_link'];
    } else {
        $hide_feed_link = '';
    }
    if (isset($silencer_Main_Settings['enable_metabox'])) {
        $enable_metabox = $silencer_Main_Settings['enable_metabox'];
    } else {
        $enable_metabox = '';
    }
    if (isset($silencer_Main_Settings['enable_box_comments'])) {
        $enable_box_comments = $silencer_Main_Settings['enable_box_comments'];
    } else {
        $enable_box_comments = '';
    }
    if (isset($silencer_Main_Settings['enable_box_hiding'])) {
        $enable_box_hiding = $silencer_Main_Settings['enable_box_hiding'];
    } else {
        $enable_box_hiding = '';
    }
    if (isset($silencer_Main_Settings['enable_box_pingback'])) {
        $enable_box_pingback = $silencer_Main_Settings['enable_box_pingback'];
    } else {
        $enable_box_pingback = '';
    }
    if (isset($silencer_Main_Settings['enable_box_trackback'])) {
        $enable_box_trackback = $silencer_Main_Settings['enable_box_trackback'];
    } else {
        $enable_box_trackback = '';
    }
    if (isset($silencer_Main_Settings['enable_box_button'])) {
        $enable_box_button = $silencer_Main_Settings['enable_box_button'];
    } else {
        $enable_box_button = '';
    }
    if (isset($silencer_Main_Settings['trackback_users'])) {
        $trackback_users = $silencer_Main_Settings['trackback_users'];
    } else {
        $trackback_users = '';
    }
    if (isset($silencer_Main_Settings['pingback_users'])) {
        $pingback_users = $silencer_Main_Settings['pingback_users'];
    } else {
        $pingback_users = '';
    }
    if (isset($silencer_Main_Settings['hide_users'])) {
        $hide_users = $silencer_Main_Settings['hide_users'];
    } else {
        $hide_users = '';
    }
    if (isset($silencer_Main_Settings['comment_users'])) {
        $comment_users = $silencer_Main_Settings['comment_users'];
    } else {
        $comment_users = '';
    }
    if (isset($silencer_Main_Settings['trackback_tags'])) {
        $trackback_tags = $silencer_Main_Settings['trackback_tags'];
    } else {
        $trackback_tags = '';
    }
    if (isset($silencer_Main_Settings['pingback_tags'])) {
        $pingback_tags = $silencer_Main_Settings['pingback_tags'];
    } else {
        $pingback_tags = '';
    }
    if (isset($silencer_Main_Settings['hide_tags'])) {
        $hide_tags = $silencer_Main_Settings['hide_tags'];
    } else {
        $hide_tags = '';
    }
    if (isset($silencer_Main_Settings['comment_tags'])) {
        $comment_tags = $silencer_Main_Settings['comment_tags'];
    } else {
        $comment_tags = '';
    }
    if (isset($silencer_Main_Settings['trackback_country'])) {
        $trackback_country = $silencer_Main_Settings['trackback_country'];
    } else {
        $trackback_country = '';
    }
    if (isset($silencer_Main_Settings['pingback_country'])) {
        $pingback_country = $silencer_Main_Settings['pingback_country'];
    } else {
        $pingback_country = '';
    }
    if (isset($silencer_Main_Settings['hide_country'])) {
        $hide_country = $silencer_Main_Settings['hide_country'];
    } else {
        $hide_country = '';
    }
    if (isset($silencer_Main_Settings['comment_country'])) {
        $comment_country = $silencer_Main_Settings['comment_country'];
    } else {
        $comment_country = '';
    }
    if (isset($silencer_Main_Settings['comment_language'])) {
        $comment_language = $silencer_Main_Settings['comment_language'];
    } else {
        $comment_language = '';
    }
    if (isset($silencer_Main_Settings['hide_language'])) {
        $hide_language = $silencer_Main_Settings['hide_language'];
    } else {
        $hide_language = '';
    }
    if (isset($silencer_Main_Settings['pingback_language'])) {
        $pingback_language = $silencer_Main_Settings['pingback_language'];
    } else {
        $pingback_language = '';
    }
    if (isset($silencer_Main_Settings['trackback_language'])) {
        $trackback_language = $silencer_Main_Settings['trackback_language'];
    } else {
        $trackback_language = '';
    }
    if (isset($silencer_Main_Settings['trackback_refs'])) {
        $trackback_refs = $silencer_Main_Settings['trackback_refs'];
    } else {
        $trackback_refs = '';
    }
    if (isset($silencer_Main_Settings['pingback_refs'])) {
        $pingback_refs = $silencer_Main_Settings['pingback_refs'];
    } else {
        $pingback_refs = '';
    }
    if (isset($silencer_Main_Settings['hide_refs'])) {
        $hide_refs = $silencer_Main_Settings['hide_refs'];
    } else {
        $hide_refs = '';
    }
    if (isset($silencer_Main_Settings['comment_refs'])) {
        $comment_refs = $silencer_Main_Settings['comment_refs'];
    } else {
        $comment_refs = '';
    }
    if (isset($silencer_Main_Settings['trackback_ips'])) {
        $trackback_ips = $silencer_Main_Settings['trackback_ips'];
    } else {
        $trackback_ips = '';
    }
    if (isset($silencer_Main_Settings['pingback_ips'])) {
        $pingback_ips = $silencer_Main_Settings['pingback_ips'];
    } else {
        $pingback_ips = '';
    }
    if (isset($silencer_Main_Settings['hide_ips'])) {
        $hide_ips = $silencer_Main_Settings['hide_ips'];
    } else {
        $hide_ips = '';
    }
    if (isset($silencer_Main_Settings['comment_ips'])) {
        $comment_ips = $silencer_Main_Settings['comment_ips'];
    } else {
        $comment_ips = '';
    }
    if (isset($silencer_Main_Settings['trackback_devices'])) {
        $trackback_devices = $silencer_Main_Settings['trackback_devices'];
    } else {
        $trackback_devices = '';
    }
    if (isset($silencer_Main_Settings['pingback_devices'])) {
        $pingback_devices = $silencer_Main_Settings['pingback_devices'];
    } else {
        $pingback_devices = '';
    }
    if (isset($silencer_Main_Settings['hide_devices'])) {
        $hide_devices = $silencer_Main_Settings['hide_devices'];
    } else {
        $hide_devices = '';
    }
    if (isset($silencer_Main_Settings['comment_devices'])) {
        $comment_devices = $silencer_Main_Settings['comment_devices'];
    } else {
        $comment_devices = '';
    }
    if (isset($silencer_Main_Settings['comment_oses'])) {
        $comment_oses = $silencer_Main_Settings['comment_oses'];
    } else {
        $comment_oses = '';
    }
    if (isset($silencer_Main_Settings['hide_oses'])) {
        $hide_oses = $silencer_Main_Settings['hide_oses'];
    } else {
        $hide_oses = '';
    }
    if (isset($silencer_Main_Settings['pingback_oses'])) {
        $pingback_oses = $silencer_Main_Settings['pingback_oses'];
    } else {
        $pingback_oses = '';
    }
    if (isset($silencer_Main_Settings['trackback_oses'])) {
        $trackback_oses = $silencer_Main_Settings['trackback_oses'];
    } else {
        $trackback_oses = '';
    }
    if (isset($silencer_Main_Settings['comment_browsers'])) {
        $comment_browsers = $silencer_Main_Settings['comment_browsers'];
    } else {
        $comment_browsers = '';
    }
    if (isset($silencer_Main_Settings['hide_browsers'])) {
        $hide_browsers = $silencer_Main_Settings['hide_browsers'];
    } else {
        $hide_browsers = '';
    }
    if (isset($silencer_Main_Settings['pingback_browsers'])) {
        $pingback_browsers = $silencer_Main_Settings['pingback_browsers'];
    } else {
        $pingback_browsers = '';
    }
    if (isset($silencer_Main_Settings['trackback_browsers'])) {
        $trackback_browsers = $silencer_Main_Settings['trackback_browsers'];
    } else {
        $trackback_browsers = '';
    }
    if (isset($silencer_Main_Settings['trackback_url'])) {
        $trackback_url = $silencer_Main_Settings['trackback_url'];
    } else {
        $trackback_url = '';
    }
    if (isset($silencer_Main_Settings['pingback_url'])) {
        $pingback_url = $silencer_Main_Settings['pingback_url'];
    } else {
        $pingback_url = '';
    }
    if (isset($silencer_Main_Settings['hide_url'])) {
        $hide_url = $silencer_Main_Settings['hide_url'];
    } else {
        $hide_url = '';
    }
    if (isset($silencer_Main_Settings['comment_url'])) {
        $comment_url = $silencer_Main_Settings['comment_url'];
    } else {
        $comment_url = '';
    }
    if (isset($silencer_Main_Settings['comment_url_wildcard'])) {
        $comment_url_wildcard = $silencer_Main_Settings['comment_url_wildcard'];
    } else {
        $comment_url_wildcard = '';
    }
    if (isset($silencer_Main_Settings['hide_url_wildcard'])) {
        $hide_url_wildcard = $silencer_Main_Settings['hide_url_wildcard'];
    } else {
        $hide_url_wildcard = '';
    }
    if (isset($silencer_Main_Settings['pingback_url_wildcard'])) {
        $pingback_url_wildcard = $silencer_Main_Settings['pingback_url_wildcard'];
    } else {
        $pingback_url_wildcard = '';
    }
    if (isset($silencer_Main_Settings['trackback_url_wildcard'])) {
        $trackback_url_wildcard = $silencer_Main_Settings['trackback_url_wildcard'];
    } else {
        $trackback_url_wildcard = '';
    }
    if (isset($silencer_Main_Settings['comments_maximum_length'])) {
        $comments_maximum_length = $silencer_Main_Settings['comments_maximum_length'];
    } else {
        $comments_maximum_length = '';
    }
    if (isset($silencer_Main_Settings['comments_maximum_length_value'])) {
        $comments_maximum_length_value = $silencer_Main_Settings['comments_maximum_length_value'];
    } else {
        $comments_maximum_length_value = '';
    }
    if (isset($silencer_Main_Settings['comments_minimum_length_value'])) {
        $comments_minimum_length_value = $silencer_Main_Settings['comments_minimum_length_value'];
    } else {
        $comments_minimum_length_value = '';
    }
    if (isset($silencer_Main_Settings['disable_html'])) {
        $disable_html = $silencer_Main_Settings['disable_html'];
    } else {
        $disable_html = '';
    }
?>
<script>
                var silencer_admin_json = {
                    silencer_enabled: '<?php
    echo $silencer_enabled;
?>',
                    admin_disable_comments: '<?php
    echo $admin_disable_comments;
?>',
                    admin_redirect: '<?php
    echo $admin_redirect;
?>',
                    admin_remove_metabox: '<?php
    echo $admin_remove_metabox;
?>',
                    disable_admin_bar: '<?php
    echo $disable_admin_bar;
?>',
                    disable_comments_sidebar: '<?php
    echo $disable_comments_sidebar;
?>',
                    remove_url: '<?php
    echo $remove_url;
?>',
                    disable_xmlrpc: '<?php
    echo $disable_xmlrpc;
?>',
                    disable_comment_feed: '<?php
    echo $disable_comment_feed;
?>',
                    google_plus: '<?php
    echo $google_plus;
?>',
                    rsd_link: '<?php
    echo $rsd_link;
?>',
                    force_comments_overwrite: '<?php
    echo $force_comments_overwrite;
?>',
                    hide_feed_link: '<?php
    echo $hide_feed_link;
?>',
                    enable_metabox: '<?php
    echo $enable_metabox;
?>',
                    enable_box_button: '<?php
    echo $enable_box_button;
?>',
                    enable_box_trackback: '<?php
    echo $enable_box_trackback;
?>',
                    enable_box_pingback: '<?php
    echo $enable_box_pingback;
?>',
                    enable_box_hiding: '<?php
    echo $enable_box_hiding;
?>',
                    enable_box_comments: '<?php
    echo $enable_box_comments;
?>',
                    comment_users: '<?php
    echo $comment_users;
?>',
                    hide_users: '<?php
    echo $hide_users;
?>',
                    pingback_users: '<?php
    echo $pingback_users;
?>',
                    trackback_users: '<?php
    echo $trackback_users;
?>',
                    comment_tags: '<?php
    echo $comment_tags;
?>',
                    hide_tags: '<?php
    echo $hide_tags;
?>',
                    pingback_tags: '<?php
    echo $pingback_tags;
?>',
                    trackback_tags: '<?php
    echo $trackback_tags;
?>',
                    trackback_country: '<?php
    echo $trackback_country;
?>',
                    pingback_country: '<?php
    echo $pingback_country;
?>',
                    hide_country: '<?php
    echo $hide_country;
?>',
                    comment_country: '<?php
    echo $comment_country;
?>',
                    trackback_language: '<?php
    echo $trackback_language;
?>',
                    pingback_language: '<?php
    echo $pingback_language;
?>',
                    hide_language: '<?php
    echo $hide_language;
?>',
                    comment_language: '<?php
    echo $comment_language;
?>',
                    comment_refs: '<?php
    echo $comment_refs;
?>',
                    hide_refs: '<?php
    echo $hide_refs;
?>',
                    pingback_refs: '<?php
    echo $pingback_refs;
?>',
                    trackback_refs: '<?php
    echo $trackback_refs;
?>',
                    comment_ips: '<?php
    echo $comment_ips;
?>',
                    hide_ips: '<?php
    echo $hide_ips;
?>',
                    pingback_ips: '<?php
    echo $pingback_ips;
?>',
                    trackback_ips: '<?php
    echo $trackback_ips;
?>',
                    comment_devices: '<?php
    echo $comment_devices;
?>',
                    hide_devices: '<?php
    echo $hide_devices;
?>',
                    pingback_devices: '<?php
    echo $pingback_devices;
?>',
                    trackback_devices: '<?php
    echo $trackback_devices;
?>',
                    trackback_oses: '<?php
    echo $trackback_oses;
?>',
                    pingback_oses: '<?php
    echo $pingback_oses;
?>',
                    hide_oses: '<?php
    echo $hide_oses;
?>',
                    comment_oses: '<?php
    echo $comment_oses;
?>',
                    comment_browsers: '<?php
    echo $comment_browsers;
?>',
                    hide_browsers: '<?php
    echo $hide_browsers;
?>',
                    pingback_browsers: '<?php
    echo $pingback_browsers;
?>',
                    trackback_browsers: '<?php
    echo $trackback_browsers;
?>',
                    comment_url: '<?php
    echo $comment_url;
?>',
                    hide_url: '<?php
    echo $hide_url;
?>',
                    pingback_url: '<?php
    echo $pingback_url;
?>',
                    trackback_url: '<?php
    echo $trackback_url;
?>',
                    trackback_url_wildcard: '<?php
    echo $trackback_url_wildcard;
?>',
                    pingback_url_wildcard: '<?php
    echo $pingback_url_wildcard;
?>',
                    hide_url_wildcard: '<?php
    echo $hide_url_wildcard;
?>',
                    comment_url_wildcard: '<?php
    echo $comment_url_wildcard;
?>'
}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('#enable_metabox').is(":checked"))
        {            
            jQuery(".hideMeta").show();
        }
        else
        {
            jQuery(".hideMeta").hide();
        }
        toggleCats();
        toggleCats2();
        toggleCats3();
        toggleCats4();
    }
    function toggleCats()
    {
        if(jQuery('#hideCats').is(":visible"))
        {            
            jQuery(".hideCats").hide();
        }
        else
        {
            jQuery(".hideCats").show();
        }
    }
    function toggleCats2()
    {
        if(jQuery('#hideCats2').is(":visible"))
        {            
            jQuery(".hideCats2").hide();
        }
        else
        {
            jQuery(".hideCats2").show();
        }
    }
    function toggleCats4()
    {
        if(jQuery('#hideCats4').is(":visible"))
        {            
            jQuery(".hideCats4").hide();
        }
        else
        {
            jQuery(".hideCats4").show();
        }
    }
    function toggleCats3()
    {
        if(jQuery('#hideCats3').is(":visible"))
        {            
            jQuery(".hideCats3").hide();
        }
        else
        {
            jQuery(".hideCats3").show();
        }
    }
    window.onload = mainChanged;
</script>
<div ng-app="silsettingsApp" ng-controller="silsettingsController" ng-cloak ng-init="initialized()">
<div class="silencer_class">
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Silencer Comment Management System Plugin Main Switch:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Silencer Comment Management System Plugin. This acts like a main switch.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="silencer_enabled" name="silencer_Main_Settings[silencer_enabled]" onChange="mainChanged()" <?php
    if ($silencer_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="silencer_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <table><tr><td>
                    <h3>Comment Page Type Options:</h3></td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
                    <h4>Post Type Options </td><td><a href="" onclick="toggleCats()">Show/Hide List</a></h4></td></tr><tr><td>
        <div id="hideCats" class="hideCats">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable new comment posting on your website or only on specific post types.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting On These Page Types:&nbsp;</b>
                    </div>
                    </td><td> 
<div class="hideCats">                    
<?php
    $post_types = get_post_types();
    foreach ($post_types as $post_type) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['enabled_types']) && !empty($silencer_Main_Settings['enabled_types'])) {
            checked(true, in_array($post_type, $silencer_Main_Settings['enabled_types']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[enabled_types][]" value="<?php
        echo $post_type;
?>" /> 
														<span><?php
        echo sanitize_text_field($post_type);
?></span>
													</label>
												</div>
<?php
    }
?> 
</div>
</td></tr><tr><td>
        <div class="hideCats">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing on your website or only on specific post types.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments On These Page Types:&nbsp;</b>
                    </div>
                    </td><td>
                    <div class="hideCats">
<br/>                    
<?php
    $post_types = get_post_types();
    foreach ($post_types as $post_type) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['enabled_existing_types']) && !empty($silencer_Main_Settings['enabled_existing_types'])) {
            checked(true, in_array($post_type, $silencer_Main_Settings['enabled_existing_types']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[enabled_existing_types][]" value="<?php
        echo $post_type;
?>" /> 
														<span><?php
        echo sanitize_text_field($post_type);
?></span>
													</label>
												</div>
<?php
    }
?> 
</div>
        </td></tr><tr><td>
        <div class="hideCats">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks on your website or only on specific post types.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks On These Page Types:&nbsp;</b>
                    </div>
                    </td><td> 
<div class="hideCats">                    
<br/>                    
<?php
    $post_types = get_post_types();
    foreach ($post_types as $post_type) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['enabled_ping_types']) && !empty($silencer_Main_Settings['enabled_ping_types'])) {
            checked(true, in_array($post_type, $silencer_Main_Settings['enabled_ping_types']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[enabled_ping_types][]" value="<?php
        echo $post_type;
?>" /> 
														<span><?php
        echo sanitize_text_field($post_type);
?></span>
													</label>
												</div>
<?php
    }
?>
</div>
</td></tr><tr><td>
        <div class="hideCats">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks on your website or only on specific post types.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks On These Page Types:&nbsp;</b>
                    </div>
                    </td><td>  
<div class="hideCats">                    
<br/>                    
<?php
    $post_types = get_post_types();
    foreach ($post_types as $post_type) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['enabled_track_types']) && !empty($silencer_Main_Settings['enabled_track_types'])) {
            checked(true, in_array($post_type, $silencer_Main_Settings['enabled_track_types']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[enabled_track_types][]" value="<?php
        echo $post_type;
?>" /> 
														<span><?php
        echo sanitize_text_field($post_type);
?></span>
													</label>
												</div>
<?php
    }
?> 
<br/>
</div>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
<h4>Category Options </td><td><a href="" onclick="toggleCats2()">Show/Hide List</a></h4></td></tr><tr><td>
        <div id="hideCats2" class="hideCats2">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable new comment posting for these category types.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting On These Category Types:&nbsp;</b>
                    </div>
                    </td><td>
<div class="hideCats2">                    
<?php
    $categories = get_categories( array(
    'hide_empty' => 0,
    'orderby' => 'name',
    'order'   => 'ASC'
) );
    foreach ($categories as $category) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['comment_cats']) && !empty($silencer_Main_Settings['comment_cats'])) {
            checked(true, in_array($category->term_id, $silencer_Main_Settings['comment_cats']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[comment_cats][]" value="<?php
        echo $category->term_id;
?>" /> 
														<span><?php
        echo sanitize_text_field($category->name);
?></span>
													</label>
												</div>
<?php
    }
?> 
</div>
</td></tr><tr><td>
        <div class="hideCats2"> 
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing on these catgory types.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments On These Category Types:&nbsp;</b>
                    </div>
                    </td><td>
                    <div class="hideCats2"> 
<br/>                    
<?php
    $categories = get_categories( array(
    'hide_empty' => 0,
    'orderby' => 'name',
    'order'   => 'ASC'
) );
    foreach ($categories as $category) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['hide_cats']) && !empty($silencer_Main_Settings['hide_cats'])) {
            checked(true, in_array($category->term_id, $silencer_Main_Settings['hide_cats']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[hide_cats][]" value="<?php
        echo $category->term_id;
?>" /> 
														<span><?php
        echo sanitize_text_field($category->name);
?></span>
													</label>
												</div>
<?php
    }
?> 
</div>
        </td></tr><tr><td>
        <div class="hideCats2"> 
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for these categories.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks On These Categories:&nbsp;</b>
                    </div>
                    </td><td> 
<div class="hideCats2">                     
<br/>                    
<?php
    $categories = get_categories( array(
    'hide_empty' => 0,
    'orderby' => 'name',
    'order'   => 'ASC'
) );
    foreach ($categories as $category) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['pingback_cats']) && !empty($silencer_Main_Settings['pingback_cats'])) {
            checked(true, in_array($category->term_id, $silencer_Main_Settings['pingback_cats']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[pingback_cats][]" value="<?php
        echo $category->term_id;
?>" /> 
														<span><?php
        echo sanitize_text_field($category->name);
?></span>
													</label>
												</div>
<?php
    }
?> 
</div>
</td></tr><tr><td>
        <div class="hideCats2"> 
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for these categories.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks for These Categories:&nbsp;</b>
                    </div>
                    </td><td>  
<div class="hideCats2">                     
<br/>                    
<?php
    $categories = get_categories( array(
    'hide_empty' => 0,
    'orderby' => 'name',
    'order'   => 'ASC'
) );
    foreach ($categories as $category) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($silencer_Main_Settings['trackback_cats']) && !empty($silencer_Main_Settings['trackback_cats'])) {
            checked(true, in_array($category->term_id, $silencer_Main_Settings['trackback_cats']));
        }
?>
 type="checkbox" name="silencer_Main_Settings[trackback_cats][]" value="<?php
        echo $category->term_id;
?>" /> 
														<span><?php
        echo sanitize_text_field($category->name);
?></span>
													</label>
												</div>
<?php
    }
?> 
<br/>
</div>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
<h4>Author Options </td><td><a href="" onclick="toggleCats3()">Show/Hide List</a></h4></td></tr><tr><td>
        <div id="hideCats3" class="hideCats3">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable new comment posting for the posts of these authors.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For the Posts of These Authors:&nbsp;</b>
                    </div>
                    </td><td>  
<div class="hideCats3">                    
<?php
    $user_ids = silencer_list_authors();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) 
        {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['comment_authors']) && !empty($silencer_Main_Settings['comment_authors'])) {
                checked(true, in_array($author, $silencer_Main_Settings['comment_authors']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[comment_authors][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
</div>
</td></tr><tr><td>
        <div class="hideCats3"> 
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for the posts of these authors.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For the Posts of These Authors:&nbsp;</b>
                    </div>
                    </td><td>
                    <div class="hideCats3"> 
<br/>                    
<?php
    $user_ids = silencer_list_authors();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['hide_authors']) && !empty($silencer_Main_Settings['hide_authors'])) {
                checked(true, in_array($author, $silencer_Main_Settings['hide_authors']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[hide_authors][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
</div>
        </td></tr><tr><td>
        <div class="hideCats3"> 
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for for the posts of these authors.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For the Posts of These Authors:&nbsp;</b>
                    </div>
                    </td><td> 
<div class="hideCats3">                     
<br/>                    
<?php
    $user_ids = silencer_list_authors();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['pingback_authors']) && !empty($silencer_Main_Settings['pingback_authors'])) {
                checked(true, in_array($author, $silencer_Main_Settings['pingback_authors']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[pingback_authors][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
</div>
</td></tr><tr><td>
        <div class="hideCats3"> 
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for the posts of these authors.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For the Posts of These Authors:&nbsp;</b>
                    </div>
                    </td><td>
<div class="hideCats3">                     
<br/>                    
<?php
    $user_ids = silencer_list_authors();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['trackback_authors']) && !empty($silencer_Main_Settings['trackback_authors'])) {
                checked(true, in_array($author, $silencer_Main_Settings['trackback_authors']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[trackback_authors][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
<br/>
</div>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
<h4>User Options </td><td><a href="" onclick="toggleCats4()">Show/Hide List</a></h4></td></tr><tr><td>
        <div id="hideCats4" class="hideCats4"> 
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable new comment posting for these logged in users.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For these Logged In Users:&nbsp;</b>
                    </div>
                    </td><td>   
<div class="hideCats4">                     
<?php
    $user_ids = silencer_list_users();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) 
        {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['comment_login']) && !empty($silencer_Main_Settings['comment_login'])) {
                checked(true, in_array($author, $silencer_Main_Settings['comment_login']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[comment_login][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
</div>
</td></tr><tr><td>
        <div class="hideCats4">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for these logged in users.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For these Logged In Users:&nbsp;</b>
                    </div>
                    </td><td>
                    <div class="hideCats4">
<br/>                    
<?php
    $user_ids = silencer_list_users();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['hide_login']) && !empty($silencer_Main_Settings['hide_login'])) {
                checked(true, in_array($author, $silencer_Main_Settings['hide_login']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[hide_login][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
</div>
        </td></tr><tr><td>
        <div class="hideCats4">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for these logged in users.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For these Logged In Users:&nbsp;</b>
                    </div>
                    </td><td>   
                    <div class="hideCats4">
<br/>                    
<?php
    $user_ids = silencer_list_users();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['pingback_login']) && !empty($silencer_Main_Settings['pingback_login'])) {
                checked(true, in_array($author, $silencer_Main_Settings['pingback_login']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[pingback_login][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
</div>
</td></tr><tr><td>
        <div class="hideCats4">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for these logged in users.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For these Logged In Users:&nbsp;</b>
                    </div>
                    </td><td>
<div class="hideCats4">                    
<br/>                    
<?php
    $user_ids = silencer_list_users();
    if(!empty($user_ids))
    {
        foreach ($user_ids as $author) {
    ?>
                                                    <div>
                                                        <label>
                                                            <input
    <?php
            if (isset($silencer_Main_Settings['trackback_login']) && !empty($silencer_Main_Settings['trackback_login'])) {
                checked(true, in_array($author, $silencer_Main_Settings['trackback_login']));
            }
    ?>
     type="checkbox" name="silencer_Main_Settings[trackback_login][]" value="<?php
            echo $author;
    ?>" /> 
                                                            <span><?php
            $user_info = get_userdata($author);
            echo sanitize_text_field($user_info->user_login);
    ?></span>
                                                        </label>
                                                    </div>
    <?php
        }
    }
    else
    {
        echo '<div>No Post Authors Detected!</div>';
    }
?> 
<br/>
</div>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific URL. Note that you can use wildcards in the URL definition. You can specify more URLs, each separated by comma. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For URL:&nbsp;</b>
                    </div>
                    </td><td>                 
                    <input type="text" name="silencer_Main_Settings[comment_url]" ng-model="settings.comment_url" pattern="[/][^/].*" placeholder="/yourlink.html">    
                    &nbsp;-&nbsp;<input type="checkbox" id="comment_url_wildcard" name="silencer_Main_Settings[comment_url_wildcard]" <?php
    if ($comment_url_wildcard == 'on')
        echo ' checked ';
?>>*?<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to enable or disable wildcards for this URL field.";
?>
                        </div>
                    </div> 
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific URL. Note that you can use wildcards in the URL definition. You can specify more URLs, each separated by comma. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For URL:&nbsp;</b>
                    </div>
                    </td><td>
<input type="text" name="silencer_Main_Settings[hide_url]" ng-model="settings.hide_url" pattern="[/][^/].*" placeholder="/yourlink.html"> 
&nbsp;-&nbsp;<input type="checkbox" id="hide_url_wildcard" name="silencer_Main_Settings[hide_url_wildcard]" <?php
    if ($hide_url_wildcard == 'on')
        echo ' checked ';
?>>*?<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to enable or disable wildcards for this URL field.";
?>
                        </div>
                    </div> 
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific URL. Note that you can use wildcards in the URL definition. You can specify more URLs, each separated by comma. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For URL:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[pingback_url]" ng-model="settings.pingback_url" pattern="[/][^/].*" placeholder="/yourlink.html">
&nbsp;-&nbsp;<input type="checkbox" id="pingback_url_wildcard" name="silencer_Main_Settings[pingback_url_wildcard]" <?php
    if ($pingback_url_wildcard == 'on')
        echo ' checked ';
?>>*?<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to enable or disable wildcards for this URL field.";
?>
                        </div>
                    </div>
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific URL. Note that you can use wildcards in the URL definition. You can specify more URLs, each separated by comma. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For URL:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[trackback_url]" ng-model="settings.trackback_url" pattern="[/][^/].*" placeholder="/yourlink.html">
&nbsp;-&nbsp;<input type="checkbox" id="trackback_url_wildcard" name="silencer_Main_Settings[trackback_url_wildcard]" <?php
    if ($trackback_url_wildcard == 'on')
        echo ' checked ';
?>>*?<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to enable or disable wildcards for this URL field.";
?>
                        </div>
                    </div>
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific post tags. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For These Post Tags:&nbsp;</b>
                    </div>
                    </td><td>                 
                    <input type="text" name="silencer_Main_Settings[comment_tags]" ng-model="settings.comment_tags">    
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific post tags. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For These Post Tags:&nbsp;</b>
                    </div>
                    </td><td>
<input type="text" name="silencer_Main_Settings[hide_tags]" ng-model="settings.hide_tags">     
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific post tags. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For These Post Tags:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[pingback_tags]" ng-model="settings.pingback_tags">  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific post tags. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For These Post Tags:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[trackback_tags]" ng-model="settings.trackback_tags">  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific IP adresses. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For These IP Adresses:&nbsp;</b>
                    </div>
                    </td><td>                 
                    <input type="text" name="silencer_Main_Settings[comment_ips]" ng-model="settings.comment_ips">    
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific IP adresses. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For These IP Adresses:&nbsp;</b>
                    </div>
                    </td><td>
<input type="text" name="silencer_Main_Settings[hide_ips]" ng-model="settings.hide_ips">     
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific IP adresses. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For These IP Adresses:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[pingback_ips]" ng-model="settings.pingback_ips">  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific IP adresses. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For These IP Adresses:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[trackback_ips]" ng-model="settings.trackback_ips">  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific referrers. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For These Referrers:&nbsp;</b>
                    </div>
                    </td><td>                 
                    <input type="text" name="silencer_Main_Settings[comment_refs]" ng-model="settings.comment_refs">    
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific referrers. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For These Referrers:&nbsp;</b>
                    </div>
                    </td><td>
<input type="text" name="silencer_Main_Settings[hide_refs]" ng-model="settings.hide_refs">     
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific referrers. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For These Referrers:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[pingback_refs]" ng-model="settings.pingback_refs">  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific referrers. Leave blank to disable.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For These Referrers:&nbsp;</b>
                    </div>
                    </td><td>   
<input type="text" name="silencer_Main_Settings[trackback_refs]" ng-model="settings.trackback_refs">  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific user types.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For These User Types:&nbsp;</b>
                    </div>
                    </td><td>                 
<select id="comment_users" name="silencer_Main_Settings[comment_users]" >
                                <option value="no"<?php
    if ($comment_users == "no") {
        echo " selected";
    }
?>>Do not disable</option>
                                  <option value="notloggedin"<?php
    if ($comment_users == "notloggedin") {
        echo " selected";
    }
?>>Not Logged In</option>
                                  <option value="loggedin"<?php
    if ($comment_users == "loggedin") {
        echo " selected";
    }
?>>Logged In</option>
                                  <option value="notadmin"<?php
    if ($comment_users == "notadmin") {
        echo " selected";
    }
?>>Not Administrator</option>
                                  <option value="admin"<?php
    if ($comment_users == "admin") {
        echo " selected";
    }
?>>Administrator</option>
                    </select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific user types.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For These User Types:&nbsp;</b>
                    </div>
                    </td><td>
<select id="hide_users" name="silencer_Main_Settings[hide_users]" >
                                <option value="no"<?php
    if ($hide_users == "no") {
        echo " selected";
    }
?>>Do not disable</option>
                                  <option value="notloggedin"<?php
    if ($hide_users == "notloggedin") {
        echo " selected";
    }
?>>Not Logged In</option>
                                  <option value="loggedin"<?php
    if ($hide_users == "loggedin") {
        echo " selected";
    }
?>>Logged In</option>
                                  <option value="notadmin"<?php
    if ($hide_users == "notadmin") {
        echo " selected";
    }
?>>Not Administrator</option>
                                  <option value="admin"<?php
    if ($hide_users == "admin") {
        echo " selected";
    }
?>>Administrator</option>
                    </select>  
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific user types.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For These User Types:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="pingback_users" name="silencer_Main_Settings[pingback_users]" >
                                <option value="no"<?php
    if ($pingback_users == "no") {
        echo " selected";
    }
?>>Do not disable</option>
                                  <option value="notloggedin"<?php
    if ($pingback_users == "notloggedin") {
        echo " selected";
    }
?>>Not Logged In</option>
                                  <option value="loggedin"<?php
    if ($pingback_users == "loggedin") {
        echo " selected";
    }
?>>Logged In</option>
                                  <option value="notadmin"<?php
    if ($pingback_users == "notadmin") {
        echo " selected";
    }
?>>Not Administrator</option>
                                  <option value="admin"<?php
    if ($pingback_users == "admin") {
        echo " selected";
    }
?>>Administrator</option>
</select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific user types.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For These User Types:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="trackback_users" name="silencer_Main_Settings[trackback_users]" >
                                <option value="no"<?php
    if ($trackback_users == "no") {
        echo " selected";
    }
?>>Do not disable</option>
                                  <option value="notloggedin"<?php
    if ($trackback_users == "notloggedin") {
        echo " selected";
    }
?>>Not Logged In</option>
                                  <option value="loggedin"<?php
    if ($trackback_users == "loggedin") {
        echo " selected";
    }
?>>Logged In</option>
                                  <option value="notadmin"<?php
    if ($trackback_users == "notadmin") {
        echo " selected";
    }
?>>Not Administrator</option>
                                  <option value="admin"<?php
    if ($trackback_users == "admin") {
        echo " selected";
    }
?>>Administrator</option>
</select>  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific user browsers.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For These Browsers:&nbsp;</b>
                    </div>
                    </td><td>                 
<select id="comment_browsers" name="silencer_Main_Settings[comment_browsers]" >
                                <option value="NONE"<?php
    if ($comment_browsers == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($comment_browsers == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="IE"<?php
    if ($comment_browsers == "IE") {
        echo " selected";
    }
?>>IE</option>
                                  <option value="Edge"<?php
    if ($comment_browsers == "Edge") {
        echo " selected";
    }
?>>Edge</option>
                                  <option value="Chrome"<?php
    if ($comment_browsers == "Chrome") {
        echo " selected";
    }
?>>Chrome</option>
                                  <option value="Firefox"<?php
    if ($comment_browsers == "Firefox") {
        echo " selected";
    }
?>>Firefox</option>
                                  <option value="Opera"<?php
    if ($comment_browsers == "Opera") {
        echo " selected";
    }
?>>Opera</option>
                                  <option value="Safari"<?php
    if ($comment_browsers == "Safari") {
        echo " selected";
    }
?>>Safari</option>
                                  <option value="Other"<?php
    if ($comment_browsers == "Other") {
        echo " selected";
    }
?>>Other</option>
                    </select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific user browsers.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For These Browsers:&nbsp;</b>
                    </div>
                    </td><td>
<select id="hide_browsers" name="silencer_Main_Settings[hide_browsers]" >
                                <option value="NONE"<?php
    if ($hide_browsers == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($hide_browsers == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="IE"<?php
    if ($hide_browsers == "IE") {
        echo " selected";
    }
?>>IE</option>
                                  <option value="Edge"<?php
    if ($hide_browsers == "Edge") {
        echo " selected";
    }
?>>Edge</option>
                                  <option value="Chrome"<?php
    if ($hide_browsers == "Chrome") {
        echo " selected";
    }
?>>Chrome</option>
                                  <option value="Firefox"<?php
    if ($hide_browsers == "Firefox") {
        echo " selected";
    }
?>>Firefox</option>
                                  <option value="Opera"<?php
    if ($hide_browsers == "Opera") {
        echo " selected";
    }
?>>Opera</option>
                                  <option value="Safari"<?php
    if ($hide_browsers == "Safari") {
        echo " selected";
    }
?>>Safari</option>
                                  <option value="Other"<?php
    if ($hide_browsers == "Other") {
        echo " selected";
    }
?>>Other</option>
                    </select>  
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific user browsers.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For These Browsers:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="pingback_browsers" name="silencer_Main_Settings[pingback_browsers]" >
                                <option value="NONE"<?php
    if ($pingback_browsers == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($pingback_browsers == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="IE"<?php
    if ($pingback_browsers == "IE") {
        echo " selected";
    }
?>>IE</option>
                                  <option value="Edge"<?php
    if ($pingback_browsers == "Edge") {
        echo " selected";
    }
?>>Edge</option>
                                  <option value="Chrome"<?php
    if ($pingback_browsers == "Chrome") {
        echo " selected";
    }
?>>Chrome</option>
                                  <option value="Firefox"<?php
    if ($pingback_browsers == "Firefox") {
        echo " selected";
    }
?>>Firefox</option>
                                  <option value="Opera"<?php
    if ($pingback_browsers == "Opera") {
        echo " selected";
    }
?>>Opera</option>
                                  <option value="Safari"<?php
    if ($pingback_browsers == "Safari") {
        echo " selected";
    }
?>>Safari</option>
                                  <option value="Other"<?php
    if ($pingback_browsers == "Other") {
        echo " selected";
    }
?>>Other</option>
</select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific user browsers.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For These Browsers:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="trackback_browsers" name="silencer_Main_Settings[trackback_browsers]" >
                                <option value="NONE"<?php
    if ($trackback_browsers == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($trackback_browsers == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="IE"<?php
    if ($trackback_browsers == "IE") {
        echo " selected";
    }
?>>IE</option>
                                  <option value="Edge"<?php
    if ($trackback_browsers == "Edge") {
        echo " selected";
    }
?>>Edge</option>
                                  <option value="Chrome"<?php
    if ($trackback_browsers == "Chrome") {
        echo " selected";
    }
?>>Chrome</option>
                                  <option value="Firefox"<?php
    if ($trackback_browsers == "Firefox") {
        echo " selected";
    }
?>>Firefox</option>
                                  <option value="Opera"<?php
    if ($trackback_browsers == "Opera") {
        echo " selected";
    }
?>>Opera</option>
                                  <option value="Safari"<?php
    if ($trackback_browsers == "Safari") {
        echo " selected";
    }
?>>Safari</option>
                                  <option value="Other"<?php
    if ($trackback_browsers == "Other") {
        echo " selected";
    }
?>>Other</option>
</select>  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific user devices.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For These User Devices:&nbsp;</b>
                    </div>
                    </td><td>                 
<select id="comment_devices" name="silencer_Main_Settings[comment_devices]" >
                                <option value="NONE"<?php
    if ($comment_devices == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($comment_devices == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="Mobile"<?php
    if ($comment_devices == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
                                  <option value="Tablet"<?php
    if ($comment_devices == "Tablet") {
        echo " selected";
    }
?>>Tablet</option>
                                  <option value="Desktop"<?php
    if ($comment_devices == "Desktop") {
        echo " selected";
    }
?>>Desktop</option>
                                  <option value="Bot"<?php
    if ($comment_devices == "Bot") {
        echo " selected";
    }
?>>Bot</option>
                    </select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific user devices.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For These User Devices:&nbsp;</b>
                    </div>
                    </td><td>
<select id="hide_devices" name="silencer_Main_Settings[hide_devices]" >
                                <option value="NONE"<?php
    if ($hide_devices == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($hide_devices == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="Mobile"<?php
    if ($hide_devices == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
                                  <option value="Tablet"<?php
    if ($hide_devices == "Tablet") {
        echo " selected";
    }
?>>Tablet</option>
                                  <option value="Desktop"<?php
    if ($hide_devices == "Desktop") {
        echo " selected";
    }
?>>Desktop</option>
                                  <option value="Bot"<?php
    if ($hide_devices == "Bot") {
        echo " selected";
    }
?>>Bot</option>
                    </select>  
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific user devices.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For These User Devices:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="pingback_devices" name="silencer_Main_Settings[pingback_devices]" >
                                <option value="NONE"<?php
    if ($pingback_devices == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($pingback_devices == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="Mobile"<?php
    if ($pingback_devices == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
                                  <option value="Tablet"<?php
    if ($pingback_devices == "Tablet") {
        echo " selected";
    }
?>>Tablet</option>
                                  <option value="Desktop"<?php
    if ($pingback_devices == "Desktop") {
        echo " selected";
    }
?>>Desktop</option>
                                  <option value="Bot"<?php
    if ($pingback_devices == "Bot") {
        echo " selected";
    }
?>>Bot</option>
</select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific user devices.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For These User Devices:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="trackback_devices" name="silencer_Main_Settings[trackback_devices]" >
                                <option value="NONE"<?php
    if ($trackback_devices == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($trackback_devices == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="Mobile"<?php
    if ($trackback_devices == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
                                  <option value="Tablet"<?php
    if ($trackback_devices == "Tablet") {
        echo " selected";
    }
?>>Tablet</option>
                                  <option value="Desktop"<?php
    if ($trackback_devices == "Desktop") {
        echo " selected";
    }
?>>Desktop</option>
                                  <option value="Bot"<?php
    if ($trackback_devices == "Bot") {
        echo " selected";
    }
?>>Bot</option>
</select>  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for specific Operating Systems.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For These Operating Systems:&nbsp;</b>
                    </div>
                    </td><td>                 
<select id="comment_oses" name="silencer_Main_Settings[comment_oses]" >
                                <option value="NONE"<?php
    if ($comment_oses == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($comment_oses == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="All Windows"<?php
    if ($comment_oses == "All Windows") {
        echo " selected";
    }
?>>All Windows</option>
                                  <option value="All Mac"<?php
    if ($comment_oses == "All Mac") {
        echo " selected";
    }
?>>All Mac</option>
                                  <option value="All Apple"<?php
    if ($comment_oses == "All Apple") {
        echo " selected";
    }
?>>All Apple</option>
                                  <option value="All Linux"<?php
    if ($comment_oses == "All Linux") {
        echo " selected";
    }
?>>All Linux</option>
                                  <option value="iOs"<?php
    if ($comment_oses == "iOs") {
        echo " selected";
    }
?>>iOs</option>
                                  <option value="Android"<?php
    if ($comment_oses == "Android") {
        echo " selected";
    }
?>>Android</option>
                                  <option value="Linux"<?php
    if ($comment_oses == "Linux") {
        echo " selected";
    }
?>>Linux</option>
                                  <option value="Windows 10"<?php
    if ($comment_oses == "Windows 10") {
        echo " selected";
    }
?>>Windows 10</option>
                                  <option value="Windows 8.1"<?php
    if ($comment_oses == "Windows 8.1") {
        echo " selected";
    }
?>>Windows 8.1</option>
                                  <option value="Windows 8"<?php
    if ($comment_oses == "Windows 8") {
        echo " selected";
    }
?>>Windows 8</option>
                                  <option value="Windows 7"<?php
    if ($comment_oses == "Windows 7") {
        echo " selected";
    }
?>>Windows 7</option>
                                  <option value="Windows Vista"<?php
    if ($comment_oses == "Windows Vista") {
        echo " selected";
    }
?>>Windows Vista</option>
                                  <option value="Windows Server 2003/XP x64"<?php
    if ($comment_oses == "Windows Server 2003/XP x64") {
        echo " selected";
    }
?>>Windows Server 2003/XP x64</option>
                                  <option value="Windows XP"<?php
    if ($comment_oses == "Windows XP") {
        echo " selected";
    }
?>>Windows XP</option>
                                  <option value="Windows 2000"<?php
    if ($comment_oses == "Windows 2000") {
        echo " selected";
    }
?>>Windows 2000</option>
                                  <option value="Windows ME"<?php
    if ($comment_oses == "Windows ME") {
        echo " selected";
    }
?>>Windows ME</option>
                                  <option value="Windows 98"<?php
    if ($comment_oses == "Windows 98") {
        echo " selected";
    }
?>>Windows 98</option>
                                  <option value="Windows 95"<?php
    if ($comment_oses == "Windows 95") {
        echo " selected";
    }
?>>Windows 95</option>
                                  <option value="Windows 3.11"<?php
    if ($comment_oses == "Windows 3.11") {
        echo " selected";
    }
?>>Windows 3.11</option>
                                  <option value="Mac OS X"<?php
    if ($comment_oses == "Mac OS X") {
        echo " selected";
    }
?>>Mac OS X</option>
                                  <option value="Mac OS 9"<?php
    if ($comment_oses == "Mac OS 9") {
        echo " selected";
    }
?>>Mac OS 9</option>
                                  <option value="Ubuntu"<?php
    if ($comment_oses == "Ubuntu") {
        echo " selected";
    }
?>>Ubuntu</option>
                                  <option value="iPhone"<?php
    if ($comment_oses == "iPhone") {
        echo " selected";
    }
?>>iPhone</option>
                                  <option value="iPod"<?php
    if ($comment_oses == "iPod") {
        echo " selected";
    }
?>>iPod</option>
                                  <option value="iPad"<?php
    if ($comment_oses == "iPad") {
        echo " selected";
    }
?>>iPad</option>
                                  <option value="BlackBerry"<?php
    if ($comment_oses == "BlackBerry") {
        echo " selected";
    }
?>>BlackBerry</option>
                                  <option value="Mobile"<?php
    if ($comment_oses == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
                    </select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for specific Operating Systems.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For These Operating Systems:&nbsp;</b>
                    </div>
                    </td><td>
<select id="hide_oses" name="silencer_Main_Settings[hide_oses]" >
                                <option value="NONE"<?php
    if ($hide_oses == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($hide_oses == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="All Windows"<?php
    if ($hide_oses == "All Windows") {
        echo " selected";
    }
?>>All Windows</option>
                                  <option value="All Mac"<?php
    if ($hide_oses == "All Mac") {
        echo " selected";
    }
?>>All Mac</option>
                                  <option value="All Apple"<?php
    if ($hide_oses == "All Apple") {
        echo " selected";
    }
?>>All Apple</option>
                                  <option value="All Linux"<?php
    if ($hide_oses == "All Linux") {
        echo " selected";
    }
?>>All Linux</option>
                                  <option value="iOs"<?php
    if ($hide_oses == "iOs") {
        echo " selected";
    }
?>>iOs</option>
                                  <option value="Android"<?php
    if ($hide_oses == "Android") {
        echo " selected";
    }
?>>Android</option>
                                  <option value="Linux"<?php
    if ($hide_oses == "Linux") {
        echo " selected";
    }
?>>Linux</option>
                                  <option value="Windows 10"<?php
    if ($hide_oses == "Windows 10") {
        echo " selected";
    }
?>>Windows 10</option>
                                  <option value="Windows 8.1"<?php
    if ($hide_oses == "Windows 8.1") {
        echo " selected";
    }
?>>Windows 8.1</option>
                                  <option value="Windows 8"<?php
    if ($hide_oses == "Windows 8") {
        echo " selected";
    }
?>>Windows 8</option>
                                  <option value="Windows 7"<?php
    if ($hide_oses == "Windows 7") {
        echo " selected";
    }
?>>Windows 7</option>
                                  <option value="Windows Vista"<?php
    if ($hide_oses == "Windows Vista") {
        echo " selected";
    }
?>>Windows Vista</option>
                                  <option value="Windows Server 2003/XP x64"<?php
    if ($hide_oses == "Windows Server 2003/XP x64") {
        echo " selected";
    }
?>>Windows Server 2003/XP x64</option>
                                  <option value="Windows XP"<?php
    if ($hide_oses == "Windows XP") {
        echo " selected";
    }
?>>Windows XP</option>
                                  <option value="Windows 2000"<?php
    if ($hide_oses == "Windows 2000") {
        echo " selected";
    }
?>>Windows 2000</option>
                                  <option value="Windows ME"<?php
    if ($hide_oses == "Windows ME") {
        echo " selected";
    }
?>>Windows ME</option>
                                  <option value="Windows 98"<?php
    if ($hide_oses == "Windows 98") {
        echo " selected";
    }
?>>Windows 98</option>
                                  <option value="Windows 95"<?php
    if ($hide_oses == "Windows 95") {
        echo " selected";
    }
?>>Windows 95</option>
                                  <option value="Windows 3.11"<?php
    if ($hide_oses == "Windows 3.11") {
        echo " selected";
    }
?>>Windows 3.11</option>
                                  <option value="Mac OS X"<?php
    if ($hide_oses == "Mac OS X") {
        echo " selected";
    }
?>>Mac OS X</option>
                                  <option value="Mac OS 9"<?php
    if ($hide_oses == "Mac OS 9") {
        echo " selected";
    }
?>>Mac OS 9</option>
                                  <option value="Ubuntu"<?php
    if ($hide_oses == "Ubuntu") {
        echo " selected";
    }
?>>Ubuntu</option>
                                  <option value="iPhone"<?php
    if ($hide_oses == "iPhone") {
        echo " selected";
    }
?>>iPhone</option>
                                  <option value="iPod"<?php
    if ($hide_oses == "iPod") {
        echo " selected";
    }
?>>iPod</option>
                                  <option value="iPad"<?php
    if ($hide_oses == "iPad") {
        echo " selected";
    }
?>>iPad</option>
                                  <option value="BlackBerry"<?php
    if ($hide_oses == "BlackBerry") {
        echo " selected";
    }
?>>BlackBerry</option>
                                  <option value="Mobile"<?php
    if ($hide_oses == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
                    </select>  
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for specific Operating Systems.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For These Operating Systems:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="pingback_oses" name="silencer_Main_Settings[pingback_oses]" >
                                <option value="NONE"<?php
    if ($pingback_oses == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($pingback_oses == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="All Windows"<?php
    if ($pingback_oses == "All Windows") {
        echo " selected";
    }
?>>All Windows</option>
                                  <option value="All Mac"<?php
    if ($pingback_oses == "All Mac") {
        echo " selected";
    }
?>>All Mac</option>
                                  <option value="All Apple"<?php
    if ($pingback_oses == "All Apple") {
        echo " selected";
    }
?>>All Apple</option>
                                  <option value="All Linux"<?php
    if ($pingback_oses == "All Linux") {
        echo " selected";
    }
?>>All Linux</option>
                                  <option value="iOs"<?php
    if ($pingback_oses == "iOs") {
        echo " selected";
    }
?>>iOs</option>
                                  <option value="Android"<?php
    if ($pingback_oses == "Android") {
        echo " selected";
    }
?>>Android</option>
                                  <option value="Linux"<?php
    if ($pingback_oses == "Linux") {
        echo " selected";
    }
?>>Linux</option>
                                  <option value="Windows 10"<?php
    if ($pingback_oses == "Windows 10") {
        echo " selected";
    }
?>>Windows 10</option>
                                  <option value="Windows 8.1"<?php
    if ($pingback_oses == "Windows 8.1") {
        echo " selected";
    }
?>>Windows 8.1</option>
                                  <option value="Windows 8"<?php
    if ($pingback_oses == "Windows 8") {
        echo " selected";
    }
?>>Windows 8</option>
                                  <option value="Windows 7"<?php
    if ($pingback_oses == "Windows 7") {
        echo " selected";
    }
?>>Windows 7</option>
                                  <option value="Windows Vista"<?php
    if ($pingback_oses == "Windows Vista") {
        echo " selected";
    }
?>>Windows Vista</option>
                                  <option value="Windows Server 2003/XP x64"<?php
    if ($pingback_oses == "Windows Server 2003/XP x64") {
        echo " selected";
    }
?>>Windows Server 2003/XP x64</option>
                                  <option value="Windows XP"<?php
    if ($pingback_oses == "Windows XP") {
        echo " selected";
    }
?>>Windows XP</option>
                                  <option value="Windows 2000"<?php
    if ($pingback_oses == "Windows 2000") {
        echo " selected";
    }
?>>Windows 2000</option>
                                  <option value="Windows ME"<?php
    if ($pingback_oses == "Windows ME") {
        echo " selected";
    }
?>>Windows ME</option>
                                  <option value="Windows 98"<?php
    if ($pingback_oses == "Windows 98") {
        echo " selected";
    }
?>>Windows 98</option>
                                  <option value="Windows 95"<?php
    if ($pingback_oses == "Windows 95") {
        echo " selected";
    }
?>>Windows 95</option>
                                  <option value="Windows 3.11"<?php
    if ($pingback_oses == "Windows 3.11") {
        echo " selected";
    }
?>>Windows 3.11</option>
                                  <option value="Mac OS X"<?php
    if ($pingback_oses == "Mac OS X") {
        echo " selected";
    }
?>>Mac OS X</option>
                                  <option value="Mac OS 9"<?php
    if ($pingback_oses == "Mac OS 9") {
        echo " selected";
    }
?>>Mac OS 9</option>
                                  <option value="Ubuntu"<?php
    if ($pingback_oses == "Ubuntu") {
        echo " selected";
    }
?>>Ubuntu</option>
                                  <option value="iPhone"<?php
    if ($pingback_oses == "iPhone") {
        echo " selected";
    }
?>>iPhone</option>
                                  <option value="iPod"<?php
    if ($pingback_oses == "iPod") {
        echo " selected";
    }
?>>iPod</option>
                                  <option value="iPad"<?php
    if ($pingback_oses == "iPad") {
        echo " selected";
    }
?>>iPad</option>
                                  <option value="BlackBerry"<?php
    if ($pingback_oses == "BlackBerry") {
        echo " selected";
    }
?>>BlackBerry</option>
                                  <option value="Mobile"<?php
    if ($pingback_oses == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
</select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for specific Operating Systems.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For These Operating Systems:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="trackback_oses" name="silencer_Main_Settings[trackback_oses]" >
                                <option value="NONE"<?php
    if ($trackback_oses == "NONE") {
        echo " selected";
    }
?>>NONE</option>
                                  <option value="ALL"<?php
    if ($trackback_oses == "ALL") {
        echo " selected";
    }
?>>ALL</option>
                                  <option value="All Windows"<?php
    if ($trackback_oses == "All Windows") {
        echo " selected";
    }
?>>All Windows</option>
                                  <option value="All Mac"<?php
    if ($trackback_oses == "All Mac") {
        echo " selected";
    }
?>>All Mac</option>
                                  <option value="All Apple"<?php
    if ($trackback_oses == "All Apple") {
        echo " selected";
    }
?>>All Apple</option>
                                  <option value="All Linux"<?php
    if ($trackback_oses == "All Linux") {
        echo " selected";
    }
?>>All Linux</option>
                                  <option value="iOs"<?php
    if ($trackback_oses == "iOs") {
        echo " selected";
    }
?>>iOs</option>
                                  <option value="Android"<?php
    if ($trackback_oses == "Android") {
        echo " selected";
    }
?>>Android</option>
                                  <option value="Linux"<?php
    if ($trackback_oses == "Linux") {
        echo " selected";
    }
?>>Linux</option>
                                  <option value="Windows 10"<?php
    if ($trackback_oses == "Windows 10") {
        echo " selected";
    }
?>>Windows 10</option>
                                  <option value="Windows 8.1"<?php
    if ($trackback_oses == "Windows 8.1") {
        echo " selected";
    }
?>>Windows 8.1</option>
                                  <option value="Windows 8"<?php
    if ($trackback_oses == "Windows 8") {
        echo " selected";
    }
?>>Windows 8</option>
                                  <option value="Windows 7"<?php
    if ($trackback_oses == "Windows 7") {
        echo " selected";
    }
?>>Windows 7</option>
                                  <option value="Windows Vista"<?php
    if ($trackback_oses == "Windows Vista") {
        echo " selected";
    }
?>>Windows Vista</option>
                                  <option value="Windows Server 2003/XP x64"<?php
    if ($trackback_oses == "Windows Server 2003/XP x64") {
        echo " selected";
    }
?>>Windows Server 2003/XP x64</option>
                                  <option value="Windows XP"<?php
    if ($trackback_oses == "Windows XP") {
        echo " selected";
    }
?>>Windows XP</option>
                                  <option value="Windows 2000"<?php
    if ($trackback_oses == "Windows 2000") {
        echo " selected";
    }
?>>Windows 2000</option>
                                  <option value="Windows ME"<?php
    if ($trackback_oses == "Windows ME") {
        echo " selected";
    }
?>>Windows ME</option>
                                  <option value="Windows 98"<?php
    if ($trackback_oses == "Windows 98") {
        echo " selected";
    }
?>>Windows 98</option>
                                  <option value="Windows 95"<?php
    if ($trackback_oses == "Windows 95") {
        echo " selected";
    }
?>>Windows 95</option>
                                  <option value="Windows 3.11"<?php
    if ($trackback_oses == "Windows 3.11") {
        echo " selected";
    }
?>>Windows 3.11</option>
                                  <option value="Mac OS X"<?php
    if ($trackback_oses == "Mac OS X") {
        echo " selected";
    }
?>>Mac OS X</option>
                                  <option value="Mac OS 9"<?php
    if ($trackback_oses == "Mac OS 9") {
        echo " selected";
    }
?>>Mac OS 9</option>
                                  <option value="Ubuntu"<?php
    if ($trackback_oses == "Ubuntu") {
        echo " selected";
    }
?>>Ubuntu</option>
                                  <option value="iPhone"<?php
    if ($trackback_oses == "iPhone") {
        echo " selected";
    }
?>>iPhone</option>
                                  <option value="iPod"<?php
    if ($trackback_oses == "iPod") {
        echo " selected";
    }
?>>iPod</option>
                                  <option value="iPad"<?php
    if ($trackback_oses == "iPad") {
        echo " selected";
    }
?>>iPad</option>
                                  <option value="BlackBerry"<?php
    if ($trackback_oses == "BlackBerry") {
        echo " selected";
    }
?>>BlackBerry</option>
                                  <option value="Mobile"<?php
    if ($trackback_oses == "Mobile") {
        echo " selected";
    }
?>>Mobile</option>
</select>  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for users from specific countries.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For Users From Specific Country:&nbsp;</b>
                    </div>
                    </td><td>                 
<select id="comment_country" name="silencer_Main_Settings[comment_country]" >
<?php
echo list_countries($comment_country);
?>            
                    </select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for users from specific countries.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For Users From Specific Country:&nbsp;</b>
                    </div>
                    </td><td>
<select id="hide_country" name="silencer_Main_Settings[hide_country]" >
<?php
echo list_countries($hide_country);
?>                                    
                    </select>  
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for users from specific countries.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For  Users From Specific Country:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="pingback_country" name="silencer_Main_Settings[pingback_country]" >
<?php
echo list_countries($pingback_country);
?>                             
</select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for users from specific countries.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For Users From Specific Country:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="trackback_country" name="silencer_Main_Settings[trackback_country]" >
<?php
echo list_countries($trackback_country);
?>            
</select>  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable comment posting for users with specific language.";
?>
                        </div>
                    </div>
                    <b>Disable Comment Posting For Users With Specific Language:&nbsp;</b>
                    </div>
                    </td><td>                 
<select id="comment_language" name="silencer_Main_Settings[comment_language]" >
<?php
echo list_languages($comment_language);
?>            
                    </select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable existing comment showing for users with specific language.";
?>
                        </div>
                    </div>
                    <b>Hide Existing Comments For Users With Specific Language:&nbsp;</b>
                    </div>
                    </td><td>
<select id="hide_language" name="silencer_Main_Settings[hide_language]" >
<?php
echo list_languages($hide_language);
?>                                    
                    </select>  
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable pingbacks for users with specific language.";
?>
                        </div>
                    </div>
                    <b>Disable Pingbacks For  Users With Specific Language:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="pingback_language" name="silencer_Main_Settings[pingback_language]" >
<?php
echo list_languages($pingback_language);
?>                             
</select>  
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select wheather you want to disable trackbacks for users with specific language.";
?>
                        </div>
                    </div>
                    <b>Disable Trackbacks For Users With Specific Language:&nbsp;</b>
                    </div>
                    </td><td>   
<select id="trackback_language" name="silencer_Main_Settings[trackback_language]" >
<?php
echo list_languages($trackback_language);
?>            
</select>  
<br/>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
</td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
<h3>Comments Settings:</h3>
</td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to allow disable comments page in admin menu?";
?>
                        </div>
                    </div>
                    <b>Disable 'Comments Page' in Admin Menu:</b>
                    </td><td>
                    <input type="checkbox" id="admin_disable_comments" name="silencer_Main_Settings[admin_disable_comments]" <?php
    if ($admin_disable_comments == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically redirect users who try to access the admin page?";
?>
                        </div>
                    </div>
                    <b>Redirect Users Who Try to Access the Admin Page:</b>
                    </td><td>
                    <input type="checkbox" id="admin_redirect" name="silencer_Main_Settings[admin_redirect]" <?php
    if ($admin_redirect == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to remove comments metabox from the admin page?";
?>
                        </div>
                    </div>
                    <b>Remove Comments Metabox from Admin Page:</b>
                    </td><td>
                    <input type="checkbox" id="admin_remove_metabox" name="silencer_Main_Settings[admin_remove_metabox]" <?php
    if ($admin_remove_metabox == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to remove comments admin bar?";
?>
                        </div>
                    </div>
                    <b>Remove Comments Admin Bar:</b>
                    </td><td>
                    <input type="checkbox" id="disable_admin_bar" name="silencer_Main_Settings[disable_admin_bar]" <?php
    if ($disable_admin_bar == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to remove comments side bar?";
?>
                        </div>
                    </div>
                    <b>Remove Comments Side Bar:</b>
                    </td><td>
                    <input type="checkbox" id="disable_comments_sidebar" name="silencer_Main_Settings[disable_comments_sidebar]" <?php
    if ($disable_comments_sidebar == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to remove URL field from comments form?";
?>
                        </div>
                    </div>
                    <b>Remove Comments Form URL Field:</b>
                    </td><td>
                    <input type="checkbox" id="remove_url" name="silencer_Main_Settings[remove_url]" <?php
    if ($remove_url == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to disable XMLRPC from WordPress?";
?>
                        </div>
                    </div>
                    <b>Disable XMLRPC WordPress Functionality:</b>
                    </td><td>
                    <input type="checkbox" id="disable_xmlrpc" name="silencer_Main_Settings[disable_xmlrpc]" <?php
    if ($disable_xmlrpc == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to return a 403 HTTP status code every time a comment feed request is issued?";
?>
                        </div>
                    </div>
                    <b>Return 403 HTTP Status for Comment Feed Requests:</b>
                    </td><td>
                    <input type="checkbox" id="disable_comment_feed" name="silencer_Main_Settings[disable_comment_feed]" <?php
    if ($disable_comment_feed == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to prevent Google Plus account ownership of the posted comments?";
?>
                        </div>
                    </div>
                    <b>Prevent Google Plus Comment Ownership:</b>
                    </td><td>
                    <input type="checkbox" id="google_plus" name="silencer_Main_Settings[google_plus]" <?php
    if ($google_plus == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to disable RSD-Link?";
?>
                        </div>
                    </div>
                    <b>Disable RSD-Link:</b>
                    </td><td>
                    <input type="checkbox" id="rsd_link" name="silencer_Main_Settings[rsd_link]" <?php
    if ($rsd_link == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to force overwrite the comments form in your template with a blank one?";
?>
                        </div>
                    </div>
                    <b>Force Overwrite Comments Form in Template:</b>
                    </td><td>
                    <input type="checkbox" id="force_comments_overwrite" name="silencer_Main_Settings[force_comments_overwrite]" <?php
    if ($force_comments_overwrite == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to hide the comments feed link from WordPress?";
?>
                        </div>
                    </div>
                    <b>Hide the Comments Feed Link:</b>
                    </td><td>
                    <input type="checkbox" id="hide_feed_link" name="silencer_Main_Settings[hide_feed_link]" <?php
    if ($hide_feed_link == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to limit your comments lenght in WordPress?";
?>
                        </div>
                    </div>
                    <b>Enable Comments Length Limitations:</b>
                    </td><td>
                    <input type="checkbox" id="comments_maximum_length" name="silencer_Main_Settings[comments_maximum_length]" <?php
    if ($comments_maximum_length == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div class="hideLength">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to limit your comments maximum lenght in WordPress?";
?>
                        </div>
                    </div>
                    <b>Limit Comments Maximum Length:</b>
                    </div>
                    </td><td>
                    <div class="hideLength">
                    <input type="number" step="1" min="0" id="comments_maximum_length_value" name="silencer_Main_Settings[comments_maximum_length_value]" value="<?php echo $comments_maximum_length_value;?>">
                    </div>
        </td></tr><tr><td>
        <div class="hideLength">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to limit your comments minimum lenght in WordPress?";
?>
                        </div>
                    </div>
                    <b>Limit Comments Minimum Length:</b>
                    </div>
                    </td><td>
                    <div class="hideLength">
                    <input type="number" step="1" min="0" id="comments_minimum_length_value" name="silencer_Main_Settings[comments_minimum_length_value]" value="<?php echo $comments_minimum_length_value;?>">
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to disable HTML in WordPress comments?";
?>
                        </div>
                    </div>
                    <b>Disable HTML in WordPress Comments (allows only plain text):</b>
                    </td><td>
                    <input type="checkbox" id="disable_html" name="silencer_Main_Settings[disable_html]" <?php
    if ($disable_html == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <h3>Post Side Metabox Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable the 'Post Meta Sidebar' for comment management?";
?>
                        </div>
                    </div>
                    <b>Enable 'Post Meta Sidebar' Box:</b>
                    </td><td>
                    <input type="checkbox" id="enable_metabox" name="silencer_Main_Settings[enable_metabox]" onChange="mainChanged()"<?php
    if ($enable_metabox == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideMeta">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable the 'Comment Posting' enable/disable checkbox in the post comment side metabox?";
?>
                        </div>
                    </div>
                    <b>Enable 'Comment Posting' Checkbox:</b>
                    </div>
                    </td><td>
                    <div class="hideMeta">
                    <input type="checkbox" id="enable_box_comments" name="silencer_Main_Settings[enable_box_comments]" <?php
    if ($enable_box_comments == 'on')
        echo ' checked ';
?>>      
</div>                
        </div>
        </td></tr><tr><td>
        <div class="hideMeta">
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable the 'Existing Comment Hiding' enable/disable checkbox in the post comment side metabox?";
?>
                        </div>
                    </div>
                    <b>Enable 'Existing Comment Hiding' Checkbox:</b>
                    </div>
                    </td><td>
                    <div class="hideMeta">
                    <input type="checkbox" id="enable_box_hiding" name="silencer_Main_Settings[enable_box_hiding]" <?php
    if ($enable_box_hiding == 'on')
        echo ' checked ';
?>>          
</div>            
        </div>
        </td></tr><tr><td>
        <div class="hideMeta">
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable the 'Pingback' enable/disable checkbox in the post comment side metabox?";
?>
                        </div>
                    </div>
                    <b>Enable 'Pingback' Checkbox:</b>
                    </div>
                    </td><td>
                    <div class="hideMeta">
                    <input type="checkbox" id="enable_box_pingback" name="silencer_Main_Settings[enable_box_pingback]" <?php
    if ($enable_box_pingback == 'on')
        echo ' checked ';
?>>        
</div>              
        </div>
        </td></tr><tr><td>
        <div class="hideMeta">
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable the 'Trackback' enable/disable checkbox in the post comment side metabox?";
?>
                        </div>
                    </div>
                    <b>Enable 'Trackback' Checkbox:</b>
                    </div>
                    </td><td>
                    <div class="hideMeta">
                    <input type="checkbox" id="enable_box_trackback" name="silencer_Main_Settings[enable_box_trackback]" <?php
    if ($enable_box_trackback == 'on')
        echo ' checked ';
?>>            
</div>          
        </div>
        </td></tr><tr><td>
        <div class="hideMeta">
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable the 'Delete All Comments' (for this post) button in the post comment side metabox?";
?>
                        </div>
                    </div>
                    <b>Enable 'Delete All Comments' Button:</b>
                    </div>
                    </td><td>
                    <div class="hideMeta">
                    <input type="checkbox" id="enable_box_button" name="silencer_Main_Settings[enable_box_button]" <?php
    if ($enable_box_button == 'on')
        echo ' checked ';
?>>             
</div>         
        </div>
        </td></tr>
        </table>
        </div>
        </div>
        
<div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
?>